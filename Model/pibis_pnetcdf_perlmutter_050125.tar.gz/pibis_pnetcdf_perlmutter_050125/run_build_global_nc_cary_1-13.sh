#!/bin/bash
sleep_time1=1s
block=1
while [ $block -le 13 ]; do
  echo
  echo current block: ibis$block
  cd ../xibis$block
  rm -rf global*.nc
  pibis_p000_cray
  let block=block+1
  echo
  sleep $sleep_time1
done

exit



#!/bin/bash
sleep_time1=1s
block=1
while [ $block -le 13 ]; do
  echo
  echo current block: ibis$block

  cp -p ./Dat2NC_x_perlmutter ../xibis$block/
  cp -p ./run_Dat2NC_x_local.40_perlmutter.sh ../xibis$block/
  let block=block+1
  echo
  sleep $sleep_time1
done

block=1
while [ $block -le 13 ]; do
  echo
  echo current block: ibis$block

  cd ../xibis$block
  run_Dat2NC_x_local.40_perlmutter.sh > /dev/null &
  let block=block+1
  echo
  sleep $sleep_time1
done

exit



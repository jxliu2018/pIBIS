#!/bin/bash
#SBATCH --qos=regular
#SBATCH --nodes=19
#SBATCH --time=2:02:00
#SBATCH --constraint=haswell
#SBATCH --license=SCRATCH
#SBATCH --jobname=myjob
export OMP_NUM_THREADS=1
srun -n 1167 -c 2 --cpu-bind=cores ./pibis_p_cray

Parallel IBIS simulation with Fractional LCC
Machine         NERSC PerlMutter
codebase        pibis_pnetcdf_perlmutter_072524 

sim start date  050125
sim end date    050125
run date id     perlmutter2025 050125 32x

run key feature All_Inclusive
geo scope       CONUS 1-2960, 1-4677
sampling        1x (1km, 990m) 

key updates     fixed luccdist.f: error rlcclc0 > 1 error
                output totlai and impactd using ecoreg and fpis

C code last     072024

Fortran last    090924 (added dic_bio, dic_geo)
                120324 (modified dic_bio, dic_geo)
                       (output dic_bio, dic_geo, totlai, impactd)
                042325 (modified ibislib.f vegetation.f for woody crop C removal)
                042425 (modified vegetation.f, minimum plai threshold, plai(i, ) = max(1.0*exist..., plai))
                042925 (modified vegetation.f, woody crop biomass clearing reset to 0.00001 instead of 0.01)
                050125 (modified luccdist.f, biomrem(), set rlcclc0(x) = min(1.0,...))

ibis.infile (all-inclusive)
                Climate      Yes, 1976
                CO2          Yes, (isimco2 = 1)
                NDep         Yes, (cluster = 1)
                LUCC         Yes, 1985
                Fire         Yes, 1985
                Warm Start   Yes, isimveg=1
                Age Reset    Yes, idiag=1970
                iyear0            1906
                ayCH4        Yes, (cluster = 1) 
                erosion      Yes, isimed=1

ibis.infile (calibrations)
                Climate      Yes, 1976
                CO2          Yes, (isimco2 = 1)
                NDep         Yes, (cluster = 1)
                LUCC         No,  2100
                Fire         No,  2100
                Warm Start   No,  isimveg=2
                Age Reset    No,  idiag=0
                iyear0            1906
                ayCH4        Yes, (cluster = 1)
                erosion      Yes, isimed=1

paramsx.scl
                county level scalers

issues          edc was not active in the first four runs, fixed for the 5th run on 072724 

outputs         may only keep dic_geo, dic_bio, fips(=totlaiu+totlail), and ecoreg(=impactd).
                other varialbes are same as the 20x_091024 simulation
-------------------------------------------------------------------------------------

Build step-by-step
                ssh -Y jxliu@cori.nersc.gov
 
		(module swap PrgEnv-gnu PrgEnv-cray) !use gnu, not cray?
		module load cray-parallel-netcdf
		module load cray-fftw

                cd ibis
                mk2.rc

                cd ..
                make_all_perlmutter.rc

Blocks and Run
                !there are three block setup:
                !sub_region_list_original.txt for block 1~11, 200 npoi
                !sub_region_list_original.txt for block 12, 200 npoi
                !sub_region_list_original.txt for block 13, 77 npoi
                !block 1~11, 12 are done in "pibis_pnetcdf_perlmutter"
                !block 13 is done in "pibis_pnetcdf_perlmutter_tail"

                run_build_sub_region_1-12.sh      (in the perlmutter folder)
                run_copy_tools_1-12_perlmutter.sh (in the perlmutter folder)
                run_build_sub_region_13.sh        (in the perlmutter_tail folder)
                run_copy_tools_13_perlmutter.sh   (in the perlmutter_tail folder)
                run_build_global_nc_cary_1-13.sh  (in the perlmutter folder)

                sbatch batch_parallel_1_perlmutter
                sbatch batch_parallel_2_perlmutter

                run_invert_40_perlmutter_1x_1-13.sh
                run_Dat2NC_x_40_perlmutter_1x_1-13.sh
                run_merge_40_perlmutter_x.sh
                run_tar_m_nc_x.sh                        (optional, save netcdf files, big merged)

                !go_perlmutter fips_m.nc fips fips.dat
                !go_perlmutter ecoreg_m.nc ecoreg ecoreg.dat
                go_perlmutter xcovmax_m.nc xcovmax xcovmax.dat
                go_perlmutter fu_m.nc fu fu.dat

                (Calibration Loop of county level)
                cp -p paramsx.scl.conus3111.base paramsx.scl.fips      (for 1st calibration run)
                cp -p paramsx.scl.conus3111.base paramsx.scl           (for 1st calibration run)
                cp -p paramsx.scl.conus3111.base ../xibis1/paramsx.scl (for 1st calibration run)

                cp -p ../xibis1/paramsx.scl paramsx.scl.fips (copy scaler from previous run) 
                run_calib_conus_990m_fips.sh                 (generate new scaler)
                cp -p scaler_temp.txt paramsx.scl.fips       (keep a copy of new scaler)
                cp -p scaler_temp.txt paramsx.scl            (keep a copy of new scaler)
                cp -p scaler_temp.txt ../xibis1/paramsx.scl  (use this new scaler in next run)

                run_clean_global_1-13.sh
                run_update_global0_1-13.sh
                run_fipssum_1x_fu0010_115yr_CONUS_perlmutter.sh

                (Calibration Loop of ecoregion level)
                cp -p paramsx.scl.conus84.base paramsx.scl.ecoreg  (for 1st calibration run)
                run_calib_conus_990m_ecoreg.sh                     (generate new scaler)
                cp -p scaler_temp.txt paramsx.scl.ecoreg           (keep a copy of new scaler)
                run_ecosum_1x_fu0010_115yr_CONUS_perlmutter.sh

Calibration loop (county level as example)

                (Note, p_list_scalers_*.asc changed to 3112 counties due to extra bad pixels)
                (Note, crop_pct data needs float type -> nlcd_2006_agr_pct_990m.flt)

                run x1 (inital run, with base scalers)
                  cp -p p_list_scalers_all_fips.asc.npp p_list_scalers_all_fips.asc  --x1
                run x2
                  cp -p p_list_scalers_all_fips.asc.npp p_list_scalers_all_fips.asc  --x2
                run x3
                  cp -p p_list_scalers_all_fips.asc.biom p_list_scalers_all_fips.asc --x3
                run x4
                  cp -p p_list_scalers_all_fips.asc.biom p_list_scalers_all_fips.asc --x4
                run x5
                  cp -p p_list_scalers_all_fips.asc.dead p_list_scalers_all_fips.asc --x5
                run x6
                  cp -p p_list_scalers_all_fips.asc.dead p_list_scalers_all_fips.asc --x6

                run x7 (use for validation run, with x6 scaler)
                run x8 (use for all-inclusive run, with x6 scaler)

Other


rm -rf ../xibis*
sub_region_N_blocks_segment_comp_dyn_nersc p_list_tmp.asc.perlmutter.end 2:02:00
mv sub_region_list_original.txt sub_region_list_original.txt.12
sleep 2s
sub_region_N_blocks_segment_comp_dyn_nersc p_list_tmp.asc.perlmutter 2:02:00
mv sub_region_list_original.txt sub_region_list_original.txt.1-11



#!/bin/bash
sleep_time1=1s
block=1
while [ $block -le 13 ]; do
  echo
  echo current block: ibis$block

  cp -p ./invert.40.sh ../xibis$block/
  cp -p ./pIO_invert_perlmutter ../xibis$block/
  let block=block+1
  echo
  sleep $sleep_time1
done

block=1
while [ $block -le 13 ]; do
  echo
  echo current block: ibis$block

  cd ../xibis$block
  invert.40.sh > /dev/null &
  let block=block+1
  echo
  sleep $sleep_time1
done

exit



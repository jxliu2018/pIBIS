echo 1 fips_m.nc.tar.gz
tar czf fips_m.nc.tar.gz fips_m.nc
echo 2 ecoreg_m.nc.tar.gz
tar czf ecoreg_m.nc.tar.gz ecoreg_m.nc
echo 3 xcovmax_m.nc.tar.gz
tar czf xcovmax_m.nc.tar.gz xcovmax_m.nc
echo 4 fu_m.nc.tar.gz
tar czf fu_m.nc.tar.gz fu_m.nc
echo 5 vegtype0_m.nc.tar.gz
tar czf vegtype0_m.nc.tar.gz vegtype0_m.nc
echo 6 cbiotot_m.nc.tar.gz
tar czf cbiotot_m.nc.tar.gz cbiotot_m.nc
echo 7 totbiou_m.nc.tar.gz
tar czf totbiou_m.nc.tar.gz totbiou_m.nc
echo 8 totcsoi_m.nc.tar.gz
tar czf totcsoi_m.nc.tar.gz totcsoi_m.nc
echo 9 stddown_m.nc.tar.gz
tar czf stddown_m.nc.tar.gz stddown_m.nc
echo 10 cgrain_m.nc.tar.gz
tar czf cgrain_m.nc.tar.gz cgrain_m.nc
echo 11 aynpptot_m.nc.tar.gz
tar czf aynpptot_m.nc.tar.gz aynpptot_m.nc
echo 12 totlit_m.nc.tar.gz
tar czf totlit_m.nc.tar.gz totlit_m.nc
echo 13 ayneetot_m.nc.tar.gz
tar czf ayneetot_m.nc.tar.gz ayneetot_m.nc
echo 14 aynbp_m.nc.tar.gz
tar czf aynbp_m.nc.tar.gz aynbp_m.nc
echo 15 ayCH4_m.nc.tar.gz
tar czf ayCH4_m.nc.tar.gz ayCH4_m.nc
echo 16 dic_geo_m.nc.tar.gz
tar czf dic_geo_m.nc.tar.gz dic_geo_m.nc
echo 17 dic_bio_m.nc.tar.gz
tar czf dic_bio_m.nc.tar.gz dic_bio_m.nc
echo 18 ayprcp_m.nc.tar.gz
tar czf ayprcp_m.nc.tar.gz ayprcp_m.nc
echo 19 totceco_m.nc.tar.gz
tar czf totceco_m.nc.tar.gz totceco_m.nc
echo 20 yrleach_m.nc.tar.gz
tar czf yrleach_m.nc.tar.gz yrleach_m.nc
echo 21 edc_m.nc.tar.gz
tar czf edc_m.nc.tar.gz edc_m.nc
echo 22 edc_tidal_m.nc.tar.gz
tar czf edc_tidal_m.nc.tar.gz edc_tidal_m.nc
echo 23 soilcomb_m.nc.tar.gz 
tar czf soilcomb_m.nc.tar.gz soilcomb_m.nc
echo 24 vegcomb_m.nc.tar.gz
tar czf vegcomb_m.nc.tar.gz vegcomb_m.nc
echo 25 strawc_m.nc.tar.gz
tar czf strawc_m.nc.tar.gz strawc_m.nc
echo 26 deadcrem_m.nc.tar.gz
tar czf deadcrem_m.nc.tar.gz deadcrem_m.nc
echo 27 livecrem_m.nc.tar.gz
tar czf livecrem_m.nc.tar.gz livecrem_m.nc
echo 28 cdisturb_m.nc.tar.gz
tar czf cdisturb_m.nc.tar.gz cdisturb_m.nc
echo 29 totwdl_m.nc.tar.gz
tar czf totwdl_m.nc.tar.gz totwdl_m.nc
echo 30 stdwdc_m.nc.tar.gz
tar czf stdwdc_m.nc.tar.gz stdwdc_m.nc
echo 31 rawlitc_m.nc.tar.gz
tar czf rawlitc_m.nc.tar.gz rawlitc_m.nc
echo 32 fallw_m.nc.tar.gz
tar czf fallw_m.nc.tar.gz fallw_m.nc
echo 33 livc2std_m.nc.tar.gz
tar czf livc2std_m.nc.tar.gz livc2std_m.nc
echo 34 livc2down_m.nc.tar.gz
tar czf livc2down_m.nc.tar.gz livc2down_m.nc
echo 35 stdwcloss_m.nc.tar.gz
tar czf stdwcloss_m.nc.tar.gz stdwcloss_m.nc
echo 36 down2lit_m.nc.tar.gz
tar czf down2lit_m.nc.tar.gz down2lit_m.nc
echo 37 lit2co2_m.nc.tar.gz
tar czf lit2co2_m.nc.tar.gz lit2co2_m.nc
echo 38 lit2soc_m.nc.tar.gz
tar czf lit2soc_m.nc.tar.gz lit2soc_m.nc
echo 39 soc2co2_m.nc.tar.gz
tar czf soc2co2_m.nc.tar.gz soc2co2_m.nc
echo 40 raw2lit_m.nc.tar.gz
tar czf raw2lit_m.nc.tar.gz raw2lit_m.nc

mkdir m_nc
mv *_m.nc.tar.gz m_nc


#!/bin/bash
sleep_time1=1s
block=1
while [ $block -le 12 ]; do
  echo
  echo current block: ibis$block

  cp -p ./pIO_invert_perlmutter ../xibis$block/
  cp -p ./Dat2NC_x_perlmutter ../xibis$block/
  cp -p ./invert.40.sh ../xibis$block/
  cp -p ./run_Dat2NC_x_local.40_perlmutter.sh ../xibis$block/
  cp -p ./pibis_p001_cray ../xibis$block/
  cp -p ./pibis_p000_cray ../xibis$block/
  cp -p ./pibis_p_cray ../xibis$block/
  cp -p ./pibis_p001_valid_seg_cray ../xibis$block/
  let block=block+1
  echo
  sleep $sleep_time1
done

exit



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "netcdf.h"

#pragma hdrstop
//---------------------------------------------------------------------------

#pragma argsused

#define maxblocks 1024
#define max_len 500

int** Make2DIntArray(int, int);

struct sort_subregion {
  int id;
  int pixels;
  int line1;
  int line2;
  int col1;
  int col2;
  int segments;
  int nodes;
  int blocksize;
};

int main(int argc, char* argv[])
{
  FILE *fpx;
  char msg[max_len], S[100], p_list[max_len]; //use x[], not *x

  char inputpath[100], maskfile[100], run_t[10];

  FILE *fp1, *fp01, *fp02, *fp03;
  char buffer[100], buffer1[100];
  int RegionID, StartRegionID;
  int Interval;
  int StartLineTmp, EndLineTmp, StartColTmp, EndColTmp;
  int Brow, Bcol, Erow, Ecol, BlockWideth, BlockColumns;
  int col1,col2;
  int i, j, k, l, m, npoi, points[maxblocks],Sort;
  signed char tmp_char;
  int tmp_int, tmp_i, tmp_i0, tmp_i00;

  int max_row, TotalBlocks, BlockID, BlockPoints[maxblocks];

  int nc_id, var_id;
  nc_type var_type;
  unsigned int array_length;
  int elementsize;
  size_t start[4];
  size_t count[4];
  int row, col;
  struct sort_subregion rand_loc[maxblocks];

  int segment_length, segment_npoi, segment_max, valid_segment[maxblocks];
  int run_time, used_nodes, ranks_per_node;
  int max_segment;

  if(argc < 3){
    printf("  This program creates subregions (blocks)\n");
    printf("  with new ibis# dirs, ibis.infile, compar.h and mpi jobscript\n");
    printf("  Source code: sub_region_N_blocks_segment_comp_dyn_cray.c\n");
    printf("  Build: gcc -g sub_region_N_blocks_segment_comp_dyn_cray.c -L/home/jxliu/netcdf363/lib -lnetcdf\n");
    printf("  Build: gcc -g sub_region_N_blocks_segment_comp_dyn_cray.c -I/home/jxliu/netcdf4211/include -L/home/jxliu/netcdf4211/lib -lnetcdf\n");
    printf("  Usage: a.out p_list_sub_region_N_blocks.asc run_time (hr:min:sec)\n");
    printf("  Usage: sub_region_N_blocks_segment_comp_dyn_cray p_list_tmp.asc 30\n");
    printf("  Note:  should keep max valid_segments <= 8192*16, nodes < 8192\n");
    return 0;
  }

  strcpy(p_list, argv[1]);
  if ((fpx = fopen(p_list, "rt")) == NULL){
    printf("Input paramater file p_list not opened .......\n");
    return 0;
  }

  fscanf(fpx,"%s",S);   //e.g. /data1/jxliu/data2/input_conus/
  fgets(msg,max_len,fpx);
  strcpy(inputpath, S);

  fscanf(fpx,"%s",S);   //e.g. conus_veg_soc_mask_960m_schar.nc
  fgets(msg,max_len,fpx);
  strcpy(maskfile, S);

  fscanf(fpx,"%s",S);   //e.g. 604, begining row
  fgets(msg,max_len,fpx);
  Brow = atoi(S);

  fscanf(fpx,"%s",S);   //e.g. 624, ending row
  fgets(msg,max_len,fpx);
  Erow = atoi(S);

  fscanf(fpx,"%s",S);   //e.g. 1165, begining column
  fgets(msg,max_len,fpx);
  Bcol = atoi(S);

  fscanf(fpx,"%s",S);   //e.g. 1185, ending column
  fgets(msg,max_len,fpx);
  Ecol = atoi(S);

  fscanf(fpx,"%s",S);   //e.g. 150 columns
  fgets(msg,max_len,fpx);
  BlockWideth = atoi(S);

  fscanf(fpx,"%s",S);   //e.g. 200, max block size (max row length)
  fgets(msg,max_len,fpx);
  max_row = atoi(S);

  fscanf(fpx,"%s",S);   //e.g. 2, sampling interval in a block
  fgets(msg,max_len,fpx);
  Interval = atoi(S);

  fscanf(fpx,"%s",S);   //e.g. 1 sort, 0 no sort
  fgets(msg,max_len,fpx);
  Sort = atoi(S);

  fscanf(fpx,"%s",S);   //e.g. starting block id (default from 1)
  fgets(msg,max_len,fpx);
  StartRegionID = atoi(S);

  fscanf(fpx,"%s",S);   //e.g. 4npoi, 8npoi, 16npoi, 32npoi
  fgets(msg,max_len,fpx);
  segment_length = atoi(S);

  fscanf(fpx,"%s",S);   //e.g. 8132 (512 nodes * 16 cores - 60)
  fgets(msg,max_len,fpx);
  segment_max = atoi(S);

  fscanf(fpx,"%s",S);   //e.g. 16 ranks per node
  fgets(msg,max_len,fpx);
  ranks_per_node = atoi(S);

  run_time = atoi(argv[2]);
  strcpy(run_t, argv[2]);

  strcpy(buffer, inputpath);
  strcat(buffer, maskfile);
  if(nc_open(buffer, NC_NOWRITE, &nc_id) != NC_NOERR) {
    printf("Error opening source NETCDF mask file\n");
    return 0;
  }
  if ((fp1 = fopen("sub_region_list_original.txt", "wt"))==NULL){
    printf("can not create output subregion records!\n");
    return 0;
  }

  for(i=0; i<maxblocks; i++){
    valid_segment[i] = 0;
    BlockPoints[i] = 0;
    points[i] = 0;
    rand_loc[i].id = maxblocks;
    rand_loc[i].pixels = 0;
    rand_loc[i].line1 = 0;
    rand_loc[i].line2 = 0;
    rand_loc[i].col1 = 0;
    rand_loc[i].col2 = 0;
    rand_loc[i].segments = 0;
    rand_loc[i].nodes = 0;
    rand_loc[i].blocksize = 0;
  }

  printf("\n------ reading the netcdf mask window: %d %d %d %d\n", Brow, Erow, Bcol, Ecol);
  Brow = Brow-1;//for 0 reference counting
  Bcol = Bcol-1;
  Erow = Erow-1;
  Ecol = Ecol-1;

  nc_inq_varid (nc_id, "surta", &var_id);
  nc_inq_vartype(nc_id, var_id, &var_type);
  row = Erow-Brow+1;
  col = Ecol-Bcol+1;
  array_length = row*col;
  BlockColumns = (col-1)/BlockWideth + 1;

  int* theArray = (int*) malloc(array_length*sizeof(int));
  start[0] = 0;
  start[1] = 0;
  start[2] = Brow;
  start[3] = Bcol;
  count[0] = 1;
  count[1] = 1;
  count[2] = row;
  count[3] = col;
  {
    if(var_type == NC_BYTE) {//byte data type is signed-char or unsigned-char
      elementsize = sizeof(unsigned char);
      unsigned char *yArray = (unsigned char *) malloc(array_length * elementsize);
      nc_get_vara_uchar(nc_id, var_id, start, count, yArray);
      for(i=0; i<array_length; i++){
        theArray[i] = (int)yArray[i] ;
      }
      free(yArray);
    }
    if(var_type == NC_CHAR) {
      elementsize = sizeof(signed char);
      signed char *yArray = (signed char *) malloc(array_length * elementsize);
      nc_get_vara_schar(nc_id, var_id, start, count, yArray);
      for(i=0; i<array_length; i++){
        theArray[i] = (int)yArray[i] ;
      }
      free(yArray);
    }
    if(var_type == NC_SHORT) {
      elementsize = sizeof(short);
      short *yArray = (short *) malloc(array_length * elementsize);
      nc_get_vara_short(nc_id, var_id, start, count, yArray);
      for(i=0; i<array_length; i++){
        theArray[i] = (int)yArray[i] ;
      }
      free(yArray);
    }
    if(var_type == NC_INT) {
      elementsize = sizeof(int);
      int *yArray = (int *) malloc(array_length * elementsize);
      nc_get_vara_int(nc_id, var_id, start, count, yArray);
      for(i=0; i<array_length; i++){
        theArray[i] = (int)yArray[i] ;
      }
      free(yArray);
    }
    if(var_type== NC_FLOAT) {
      elementsize = sizeof(float);
      float *yArray = (float *) malloc(array_length * elementsize);
      nc_get_vara_float(nc_id, var_id, start, count, yArray);
      for(i=0; i<array_length; i++){
        theArray[i] = (int)yArray[i] ;
      }
      free(yArray);
    }
    if(var_type== NC_DOUBLE) {
      elementsize = sizeof(double);
      double *yArray = (double *) malloc(array_length * elementsize);
      nc_get_vara_double(nc_id, var_id, start, count, yArray);
      for(i=0; i<array_length; i++){
        theArray[i] = (int)yArray[i] ;
      }
      free(yArray);
    }
  }
  nc_close(nc_id);

  printf("------ whole region is %d rows by %d columns\n", row, col);
  fprintf(fp1, "BlockID APixels BPixels StartRow EndRow StartCol EndCol Segments Nodes BlockSize\n");
  printf("BlockID APixels BPixels StartRow EndRow StartCol EndCol Segments Nodes BlockSize\n");

  BlockID = 0;
  StartLineTmp = 0;
  EndLineTmp = 0;
  StartColTmp = 0;
  EndColTmp = 0;
  valid_segment[BlockID] = 0;
  tmp_int = Interval*segment_length;
  col1 = 0;
  col2 = col1 + BlockWideth;
  if(col2 > col){
    col2 = col;
  }

  //iterate by block-columns, each block-column contains BlockWideth columns.
  for(m=0;m<BlockColumns;m++){
    k = 0;
    l = 0;
    segment_npoi = 0; 
    tmp_i = 0;
    tmp_i0 = -1;
    tmp_i00 = 0;

    for(i=0;i<row;i++){
      for(j=col1;j<col2;j++){
        tmp_char = theArray[i*col+j];//scan the mask map
        if(i%Interval == 0 && j%Interval == 0){//a valid sampling location
          if(tmp_char > 0){ //the sampling location is real valid land
            if(tmp_i0 < 0){
              tmp_i0 = i;   //this is the first valid row, calculate only once!
              tmp_i00 = tmp_i0;//a row shift value used later
            }
            BlockPoints[BlockID] = BlockPoints[BlockID] + 1;
            segment_npoi = segment_npoi + 1; //add up mask value in segment
          }

          if(j%tmp_int == (tmp_int - Interval)){//the last pixel of a segment
            if(segment_npoi > 0){
              valid_segment[BlockID] = valid_segment[BlockID] + 1;
            }
            segment_npoi = 0;
          }
        }
      }//for(j=col1;j<col2;j++), scanned one line on mask map

      if(tmp_i00 > 0){
        tmp_i00 = 0;//use the row shift only once to reset start row counter
        tmp_i = 0;  //first valid row start to count
      }
      else{
        tmp_i = tmp_i + 1;
      }
    
      if(i==row-1 || valid_segment[BlockID] >= segment_max || tmp_i==(max_row/Interval)*Interval+1){
        if(StartLineTmp == 0){
          if(tmp_i0 >= 0)
            StartLineTmp = tmp_i0 + 1;
        }
        else{
          StartLineTmp = EndLineTmp+1;
        }
        EndLineTmp = i+Interval;
        StartColTmp = col1+1;
        EndColTmp = j;
        if(EndLineTmp > row) EndLineTmp = row;
        if(EndColTmp > col) EndColTmp = col;

        if(valid_segment[BlockID] > 0){
          rand_loc[BlockID].id = BlockID;
          rand_loc[BlockID].line1 = StartLineTmp + Brow;
          rand_loc[BlockID].line2 = EndLineTmp + Brow;
          rand_loc[BlockID].col1 = StartColTmp + Bcol;
          rand_loc[BlockID].col2 = EndColTmp + Bcol;
          rand_loc[BlockID].pixels = BlockPoints[BlockID];
          rand_loc[BlockID].segments = valid_segment[BlockID];
          rand_loc[BlockID].nodes = (valid_segment[BlockID]-1)/ranks_per_node + 1;
          rand_loc[BlockID].blocksize = (EndLineTmp-StartLineTmp+1)*(EndColTmp-StartColTmp+1);
          l = l + rand_loc[BlockID].pixels;

          printf("%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n",
            BlockID+StartRegionID, l, BlockPoints[BlockID], rand_loc[BlockID].line1, rand_loc[BlockID].line2, 
            rand_loc[BlockID].col1, rand_loc[BlockID].col2, rand_loc[BlockID].segments,rand_loc[BlockID].nodes,
            rand_loc[BlockID].blocksize);
          fprintf(fp1, "%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n", 
            BlockID+StartRegionID, l, BlockPoints[BlockID], rand_loc[BlockID].line1, rand_loc[BlockID].line2, 
            rand_loc[BlockID].col1, rand_loc[BlockID].col2, rand_loc[BlockID].segments,rand_loc[BlockID].nodes,
            rand_loc[BlockID].blocksize);

          BlockID++;
          valid_segment[BlockID] = 0;
          TotalBlocks = BlockID; 
          tmp_i = 0;
        }
        if(i==row-1){
          col1 = col2;
          col2 = col1+BlockWideth;
          if(col2 > col){
            col2 = col;
          }
          StartLineTmp = 0;
          EndLineTmp = 0;
          StartColTmp = col1;
        }
      }//if(i==row-1 || valid_segment[BlockID] > segment_max || tmp_i==(max_row-Interval+1))
    }//for(i=0;i<row;i++)
  }//BlockColumns loop
  fclose(fp1);

  printf("------will begin building sub_regions in 5 seconds\n");
  if(StartRegionID < 1){
    StartRegionID = 0;
  }
  else{
    StartRegionID = StartRegionID -1;
  }
  for(j=1; j<=TotalBlocks; j++){
    npoi = rand_loc[j-1].pixels;
    RegionID = StartRegionID + j;
    if(npoi>0){
      printf("------ Building sub_region %d\n", RegionID);
      sprintf(buffer, "mkdir ../xibis%d", RegionID); //xibis1, xibis2,....
      system (buffer);
      sprintf(buffer1, " ../xibis%d/input", RegionID);
      strcpy(buffer,"ln -s ");
      strcat(buffer, inputpath);
      strcat(buffer, buffer1);
      system (buffer);

      strcpy(buffer, "ibis.infile.bak");
      if ((fp02 = fopen(buffer, "rt"))==NULL){
        return 0;
      }
      strcpy(buffer, "ibis.infile");
      if ((fp03 = fopen(buffer, "wt"))==NULL){
        return 0;
      }
      for(i=0;i<26;i++){
        if(i==20){
          fscanf(fp02,"%s",&S[0]);
          fprintf(fp03,"%d",rand_loc[j-1].line1);
          fgets(msg,500,fp02);
          fputs(msg,fp03);
        }
        else if(i==21){
          fscanf(fp02,"%s",&S[0]);
          fprintf(fp03,"%d",rand_loc[j-1].line2);
          fgets(msg,500,fp02);
          fputs(msg,fp03);
        }
        else if(i==22){
          fscanf(fp02,"%s",&S[0]);
          fprintf(fp03,"%d",rand_loc[j-1].col1);
          fgets(msg,500,fp02);
          fputs(msg,fp03);
        }
        else if(i==23){
          fscanf(fp02,"%s",&S[0]);
          fprintf(fp03,"%d",rand_loc[j-1].col2);
          fgets(msg,500,fp02);
          fputs(msg,fp03);
        }
        else if(i==24){
          fscanf(fp02,"%s",&S[0]);
          fprintf(fp03,"%d",Interval);
          fgets(msg,500,fp02);
          fputs(msg,fp03);
        }
        else if(i==25){
          fscanf(fp02,"%s",&S[0]);
          fprintf(fp03,"%d",Interval);
          fgets(msg,500,fp02);
          fputs(msg,fp03);
        }
        else{
          fgets(msg,500,fp02);
          fputs(msg,fp03);
        }
      }//if(npoi>0)
      fclose(fp02);
      fclose(fp03);

/* NERSC Cori myscript_cray.sh process */
      strcpy(buffer, "myscript_cray.sh.nersc");
      if ((fp02 = fopen(buffer, "rt"))==NULL){
        return 0;
      }
      strcpy(buffer, "myscript_cray.sh");
      if ((fp03 = fopen(buffer, "wt"))==NULL){
        return 0;
      }

      used_nodes = rand_loc[j-1].nodes;
/*
      if(used_nodes <= 128){
        used_nodes = 128;
      }
      else if(used_nodes <= 256){
        used_nodes = 256;
      }
      else if(used_nodes <= 512){
        used_nodes = 512;
      }
      else if(used_nodes <= 1024){
        used_nodes = 1024;
      }
      else if(used_nodes <= 2048){
        used_nodes = 2048;
      }
      else if(used_nodes <= 4096){
        used_nodes = 4096;
      }
      else if(used_nodes <= 8192){
        used_nodes = 8192;
      }
      else{
        used_nodes = 0;
      }
*/
      for(i=0;i<9;i++){
        fgets(msg,500,fp02);
        if(i==2){
          sprintf(buffer, "#SBATCH --nodes=%d\n", used_nodes);
          fputs(buffer,fp03);
        }
	else if(i==3){
          //sprintf(buffer, "#SBATCH --time=%d\n", run_time);
          sprintf(buffer, "#SBATCH --time=%s\n", run_t);
          fputs(buffer,fp03);
        }
        else if(i==8){
          sprintf(buffer, "srun -n %d -c 2 --cpu-bind=cores ./pibis_p_cray\n", rand_loc[j-1].segments);
          fputs(buffer,fp03);
        }
        else{
          fputs(msg,fp03);
        }
      }
      fclose(fp02);
      fclose(fp03);
/* End of NERSC Cori myscript_cray.sh process */
/*
      strcpy(buffer, "myscript_cray.sh.bak");
      if ((fp02 = fopen(buffer, "rt"))==NULL){
        return 0;
      }
      strcpy(buffer, "myscript_cray.sh");
      if ((fp03 = fopen(buffer, "wt"))==NULL){
        return 0;
      }

      used_nodes = rand_loc[j-1].nodes;
      if(used_nodes <= 128){
        used_nodes = 128;
      }
      else if(used_nodes <= 256){
        used_nodes = 256;
      }
      else if(used_nodes <= 512){
        used_nodes = 512;
      }
      else if(used_nodes <= 1024){
        used_nodes = 1024;
      }
      else if(used_nodes <= 2048){
        used_nodes = 2048;
      }
      else if(used_nodes <= 4096){
        used_nodes = 4096;
      }
      else if(used_nodes <= 8192){
        used_nodes = 8192;
      }
      else{
        used_nodes = 0;
      }

      for(i=0;i<18;i++){
        fgets(msg,500,fp02);
        if(i==1){
          sprintf(buffer, "#COBALT -t %d\n", run_time);
          fputs(buffer,fp03);
        }
        else if(i==2){
          sprintf(buffer, "#COBALT -n %d\n", used_nodes);
          fputs(buffer,fp03);
        }
        else if(i==9){
          sprintf(buffer, "export n_mpi_ranks=%d\n", rand_loc[j-1].segments);
          fputs(buffer,fp03);
        }
        else{
          fputs(msg,fp03);
        }
      }
      fclose(fp02);
      fclose(fp03);
*/
      sprintf(buffer, "cp -p sub_region_list_original.txt ../xibis%d/", RegionID);
      system (buffer);
      sprintf(buffer, "cp -p pibis_input_list.txt ../xibis%d/", RegionID);
      system (buffer);
      sprintf(buffer, "cp -p ibis.infile ../xibis%d/ibis.infile", RegionID);
      system (buffer);
      sprintf(buffer, "cp -p paramsx.??? ../xibis%d/", RegionID);
      system (buffer);

      //sprintf(buffer, "cp -p pibis_p_local ../xibis%d/", RegionID);
      sprintf(buffer, "cp -p pibis_p_cray ../xibis%d/", RegionID);
      system (buffer);
      //sprintf(buffer, "cp -p pibis_p000_local ../xibis%d/", RegionID);
      sprintf(buffer, "cp -p pibis_p000_cray ../xibis%d/", RegionID);
      system (buffer);
      sprintf(buffer, "cp -p myscript_cray.sh ../xibis%d/", RegionID);
      system (buffer);

    }//if(npoi>0)
    else{
      printf("------ Sub_region %d has no land points\n\n", j);
    }
  }//for(j=1; j<=TotalBlocks; j++)

  return 0;
}

int** Make2DIntArray(int arraySizeX, int arraySizeY) {
  int** theArray;
  int i;
  theArray = (int**) malloc(arraySizeX*sizeof(int*));
  for (i = 0; i < arraySizeX; i++)
   theArray[i] = (int*) malloc(arraySizeY*sizeof(int));
  return theArray;
}

 

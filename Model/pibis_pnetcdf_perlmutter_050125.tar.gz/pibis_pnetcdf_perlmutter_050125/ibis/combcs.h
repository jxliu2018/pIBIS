c
c ------
c combcs
c ------
c
      real
     >  xintopo(npoi),    ! topography (m)
     >  xinveg(npoi),     ! fixed vegetation map
     >  xinvegc(npoi),    ! initial vegetation C pools
     >  xinsoilc(npoi),   ! initial soil C pools
     >  xinnmmax(npoi),   ! N saturation threshold (gN/m2)
     >  deltat(npoi),     ! absolute minimum temperature -
     >                    ! temp on average of coldest month (C)
     >  lctrend(npoi,5),  ! land cover trends
     >  lcfill(npoi,30),  ! land cover filled (interpolated) map series
     >  lcfill2(npoi,30), ! land cover filled (interpolated) map series
     >  lcfill3(npoi),    ! land cover of a single year, for output
     >  lccmatrix(11,11), ! land use change types
     >  firescar(npoi),   ! fire scar (map) for one year
     >  burnfh(npoi),     ! fire severity (map) for one year, forest high
     >  burnfm(npoi),     ! fire severity (map) for one year, forest mix
     >  burnfl(npoi),     ! fire severity (map) for one year, forest low
     >  burnsh(npoi),     ! fire severity (map) for one year, shrub high
     >  burnsm(npoi),     ! fire severity (map) for one year, shrub mix
     >  burnsl(npoi),     ! fire severity (map) for one year, shrub low
     >  xsubpix(npoi,10), ! sub-pixel infomation
     >  xinfbiom(npoi),   ! initial biomass for forest
     >  xinsbiom(npoi),   ! initial biomass for shrub
     >  xingbiom(npoi),   ! initial biomass for grass
     >  xinwbiom(npoi),   ! initial biomass for wetland
     >  xcovfor(npoi),    ! cover fraction of forest
     >  xcovshrub(npoi),  ! cover fraction of shrub
     >  xcovgrass(npoi),  ! cover fraction of grass
     >  xcovwet(npoi),    ! cover fraction of wetland
     >  xnonveg(npoi),    ! fraction of non-vegetation, 0-100 (e.g water)
     >  xcovcrop(npoi),   ! cover fraction of crop
     >  xcovwdcrop(npoi), ! cover fraction of woody crop
     >  xcovmax(npoi),    ! maximum cover fraction among the above
     >  xrestart,         ! restart flag
     >  ecoreg(npoi),     ! ecoregion mask (ecoreg id 1-84)
     >  fips(npoi),       ! fips code (US county code map) (fips_id 1-3111)
     >  fips123(npoi),    ! fips code in serial number 1 - npoi
     >  ownertype(npoi),  ! fips code in a subregion 
     >  fipscode(nfips),  ! fips code in a subregion 
     >  scalers(9,nfips), ! scaler file for each region
     >  landuse(9,nfips), ! landuse file for each region
     >  ratio1(npoi),     ! soil C in/out ratio
     >  ratio2(npoi),     ! averaged soil C in/out ratio
     >  xinForesFra(npoi),  ! Forest    fraction limitation for each pixel -- ZhuQiuAn 2011_06_14
     >  xinGrassFra(npoi),  ! Grassland fraction limitation for each pixel -- ZhuQiuAn 2011_06_14
     >  xinShrubFra(npoi),  ! Shrubland fraction limitation for each pixel -- ZhuQiuAn 2011_06_14
     >  xinCropsFra(npoi),  ! Cropsland fraction limitation for each pixel -- ZhuQiuAn 2011_06_14
     >  xinNovegFra(npoi),   ! Nonveg    fraction limitation for each pixel -- ZhuQiuAn 2011_06_14
     >  xinC3CropFra(npoi),  ! C3 crops fraction for each pixel -- ZhuQiuAn 2011_06_17
     >  xinC4CropFra(npoi)  ! C4 crops fraction for each pixel -- ZhuQiuAn 2011_06_17
c
      integer
     >  xdist(npoi)       ! disturbance types (map) for one year
      real
     >  xdistf(npoi)      ! float type disturbance types (map) for one year
      real
     >  edc(npoi)         ! float type annual soil carbon erosion/deposition
      real
     >  edctidal(npoi)    ! float type annual tidal mudflat soil carbon deposition
      real
     >  dic_geo(npoi)     ! DIC from mineral weathering
      real
     >  dic_bio(npoi)     ! DIC from soc decomposition
      real
     >  ndepf(npoi)       ! float type nitrogen deposition rate gN/m2/yr 
      integer
     >  serid(npoi)       ! serial id of simulation block after sampling
      integer
     >  wdcage(npoi)      ! woody crop age (years)
c
      real
     > slrk(npoi),
     > slr(npoi),
     > elevopt(npoi),
     > delev(npoi),
     > elev(npoi),
     > rNPP(npoi),
     > rSOC(npoi),
     > rsedlat(npoi),
     > flood(npoi),
     > drain(npoi),
     > fldrphase(npoi)
c
      real
     > fraclc1(npoi),
     > fraclc2(npoi),
     > fraclc3(npoi),
     > fraclc4(npoi),
     > fraclc5(npoi),
     > fraclc6(npoi),
     > fraclc7(npoi),
     > fraclc8(npoi),
     > fraclcc1(npoi),
     > fraclcc2(npoi),
     > fraclcc3(npoi),
     > fraclcc4(npoi),
     > fraclcc5(npoi),
     > fraclcc6(npoi),
     > fraclcc7(npoi),
     > fraclcc8(npoi),
     > fraclcc9(npoi),
     > fraclcc10(npoi),
     > fraclcc11(npoi),
     > fraclcc12(npoi),
     > fraclcc13(npoi),
     > fraclcc14(npoi),
     > fraclcc15(npoi),
     > fraclcc16(npoi),
     > fraclcc17(npoi),
     > fraclcc18(npoi),
     > fraclcc19(npoi),
     > fraclcc20(npoi)

      common /combcs1/ xintopo,xinveg,xinvegc,xinsoilc,xinnmmax,deltat,
     >               lctrend,lcfill,lcfill2,lcfill3,lccmatrix,firescar,
     >                 burnfh, burnfm, burnfl, burnsh, burnsm, burnsl,
     >                 xsubpix, xinfbiom, xinsbiom, xingbiom, xinwbiom,
     >                 xcovfor, xcovshrub, xcovgrass, xcovwet,xnonveg, 
     >                 xcovcrop,xcovwdcrop,xcovmax,xrestart,ecoreg,
     >                 fips,fips123,ownertype,fipscode,scalers,landuse,
     >                 ratio1, ratio2,
     >                 xinForesFra,xinGrassFra,xinShrubFra,xinCropsFra,
     >                 xinNovegFra,xinC3CropFra,xinC4CropFra, ! ZhuQiuAn 2011_06_14
     >                 xdist, xdistf,edc,edctidal,dic_geo,dic_bio,
     >                 ndepf,serid,wdcage,
     >                 slrk,slr,elevopt,delev,elev,rNPP,rSOC,rsedlat,
     >                 flood, drain, fldrphase,
     >               fraclc1,fraclc2,fraclc3,fraclc4,
     >               fraclc5,fraclc6,fraclc7,fraclc8,
     >               fraclcc1,fraclcc2,fraclcc3,fraclcc4,fraclcc5,
     >               fraclcc6,fraclcc7,fraclcc8,fraclcc9,fraclcc10,
     >               fraclcc11,fraclcc12,fraclcc13,fraclcc14,fraclcc15,
     >               fraclcc16,fraclcc17,fraclcc18,fraclcc19,fraclcc20
c
      integer
     >  lmclust(npoi),   ! landmask cluster, i.e. polygons
     >  lmask(nlon,nlat)  ! landmask 0=water, 1=land
c
      common /combcs2/ lmclust, lmask
c
      real
     >  xint(npoi,12),    ! climatological temp + anomaly (C)
     >  xinq(npoi,12),    ! climatological relative humidity + anomaly (%)
     >  xinprec(npoi,12), ! climatological precipition + anomaly (mm/day)
     >  xinwind(npoi,12), ! climatological wind speed + anomaly (m s-1)
     >  xincld(npoi,12),  ! climatological cloudiness + anomaly(%)
     >  xinwet(npoi,12),  ! climatological wet days + anomaly (days/month)
     >  xintrng(npoi,12)  ! climatological temp range + anomaly(C)
c
      common /combcs3/ xint, xinq,xinprec,xinwind,xincld,xinwet,xintrng
c
      real
     >  clmt(npoi,12),    ! climatological temperature (C)
     >  clmq(npoi,12),    ! climatological relative humidity (%)
     >  clmprec(npoi,12), ! climatological precipitation (mm/day)
     >  clmw(npoi,12),    ! climatological wind speed (m s-1)
     >  clmwet(npoi,12),  ! climatological wet days (days/month)
     >  clmcld(npoi,12),  ! climatological cloudiness (%)
     >  clmtrng(npoi,12)  ! climatological temp range (C)
c
      common /combcs4/ clmt, clmq, clmprec, clmw, clmwet,clmcld,clmtrng
c
      real
     >  xintd(npoi),      ! daily climatological temperature (C) +
     >                    !   anomaly (C) + daily anomaly (C)
     >  xinqd(npoi),      ! daily climatological relative humidity (%) +
     >                    !   anomaly (%) * daily anomaly (fraction)
     >  xinprecd(npoi),   ! daily climatological precipitation (mm/day) +
     >                    !   anomaly (mm/day) * daily anomaly (fraction)
     >  xinwindd(npoi),   ! daily climatological windspeed (m/s) +
     >                    !   anomaly (m/s) * daily anomaly (fraction)
     >  xincldd(npoi),    ! daily climatological cloud fraction (fraction) +
     >                    !   anomaly (fraction) + daily anomaly (fraction)
     >  xintrngd(npoi)    ! daily climatological temp range (C) +
     >                    !   anomaly (C) * daily anomaly (C)
c

* DTP 2002/04/17: Declare scaling factors for compressed anomaly data
*                 Used in rdanom(), readit() and init_anoms()

      common /combcs5/ xintd, xinqd, xinprecd,xinwindd,xincldd,xintrngd

      real*4 
     >       temp_scale,
     >       temp_ofs,
     >       trng_scale,
     >       trng_ofs,
     >       prec_scale,
     >       prec_ofs,
     >       cld_scale,
     >       cld_ofs,
     >       rh_scale,
     >       rh_ofs,
     >       wetd_scale,
     >       wetd_ofs,
     >       wspd_scale,
     >       wspd_ofs
 
      logical*1 
     >       temp_iscompressed, 
     >       trng_iscompressed, 
     >       prec_iscompressed, 
     >       cld_iscompressed, 
     >       rh_iscompressed, 
     >       wetd_iscompressed, 
     >       wspd_iscompressed 

      common /combcs6/
     >       temp_scale,
     >       temp_ofs,
     >       trng_scale,
     >       trng_ofs,
     >       prec_scale,
     >       prec_ofs,
     >       cld_scale,
     >       cld_ofs,
     >       rh_scale,
     >       rh_ofs,
     >       wetd_scale,
     >       wetd_ofs,
     >       wspd_scale,
     >       wspd_ofs,
     >       temp_iscompressed, 
     >       trng_iscompressed, 
     >       prec_iscompressed, 
     >       cld_iscompressed, 
     >       rh_iscompressed, 
     >       wetd_iscompressed, 
     >       wspd_iscompressed 


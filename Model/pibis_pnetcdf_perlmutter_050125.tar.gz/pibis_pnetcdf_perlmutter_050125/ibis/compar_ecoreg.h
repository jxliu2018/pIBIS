c ------
c compar
c ------
c
c ------------------------
c main parameters for ibis
c ------------------------
c
      integer nlon,    ! longitude dimension of domain
     >        nlat,    ! latitude dimension of domain
     >        npoi,    ! total number of land points
     >        nband,   ! number of solar radiation wavebands
     >        nsoilay, ! number of soil layers
     >        nsnolay, ! number of snow layers
     >        npft,    ! number of plant functional types (PFT)
     >        npftu,   ! number of upper canopy pfts
     >        ndist,   ! number of disturbance types !J.Liu
     >        npart,   ! number of plant parts (leaf, wood, root)
     >        ncrop    ! number of crop types
c
      real xres,       ! longitude resolution (in degrees)
     >     yres,       ! latitude resolution (in degrees)
     >     pi          ! you know, that constant thing
c
      parameter (nlon    = 200,
     >           nlat    = 1,
     >           npoi    = 200,
     >           nband   = 2,
     >           nsoilay = 6,
     >           nsnolay = 3,
     >           npft    = 15,
     >           npftu   = 8,
     >           ndist   = 10,
     >           npart   = 3,
     >           ncrop   = 10,
     >           xres    = 1.0,
     >           yres    = 1.0,
     >           pi      = 3.1415927)
c
c ----------------------
c required common blocks
c ----------------------
c
      real
     >  epsilon,       ! small quantity to avoid zero-divides
     >  dtime,         ! model timestep (seconds)
     >  zweight,
     >  stef,          ! stefan-boltzmann constant (W m-2 K-4)
     >  vonk,          ! von karman constant (dimensionless)
     >  grav,          ! gravitational acceleration (m s-2)
     >  tmelt,         ! freezing point of water (K)
     >  hfus,          ! latent heat of fusion of water (J kg-1)
     >  hvap,          ! latent heat of vaporization of water (J kg-1)
     >  hsub,          ! latent heat of sublimation of ice (J kg-1)
     >  ch2o,          ! specific heat of liquid water (J deg-1 kg-1)
     >  cice,          ! specific heat of ice (J deg-1 kg-1)
     >  cair,          ! specific heat of dry air at constant pressure (J deg-1 kg-1)
     >  cvap,          ! specific heat of water vapor at constant pressure (J deg-1 kg-1)
     >  rair,          ! gas constant for dry air (J deg-1 kg-1)
     >  rvap,          ! gas constant for water vapor (J deg-1 kg-1)
     >  cappa,         ! rair/cair
     >  rhow,          ! density of liquid water (all types) (kg m-3)
     >  startlon,      ! base location
     >  startlat,      ! base location
     >  endlon,        ! base location
     >  endlat         ! base location 
c
      common /compar1/ epsilon, dtime, zweight, stef, vonk, grav,
     >  tmelt, hfus,
     >  hvap, hsub, ch2o,  cice, cair, cvap, rair, rvap, cappa, rhow,
     >  startlon, startlat, endlon, endlat
c
      real
     >  garea(npoi),   ! area of each gridcell (m**2)
     >  vzero(npoi),   ! a real array of zeros, of length npoi
     >  landcl(npoi)  ! a real array to hold landclass info.c

      common /compar2/ garea, vzero, landcl
c
      integer
     >  ndaypy,        ! number of days per year
     >  nlonsub,       ! number of longitude points for subsetting
     >  nlatsub,       ! number of latitude points for subsetting
     >  nlonsubs,      ! number of longitude points for subsetting, by scale
     >  nlatsubs,      ! number of latitude points for subsetting, by scale
     >  nclust,        ! number of cluster, no larger then npoi
     >  cluster,       ! flag indicating polygon simulation
     >  events,        ! starting year of LULCC/disturbance, 0 = no LULCC
     >  lccfrom(npoi), ! land cover change from (which type)
     >  lccto(npoi),   ! land cover change to (which type)
     >  lcctime(npoi), ! land cover change to (which type)
     >  lcclen(npoi),  ! time length to keep the change (then merge to other type)
     >  lccflag(npoi), ! a lcc flag
     >  rowscale,      ! sampling interval by row, 1=wall-to-wall
     >  colscale,      ! sampling interval by col, 1=wall-to-wall
     >  istart(4),     ! map1 start, e.g. 250m map
     >  icount(4),     ! map1 count
     >  istartx(4),    ! map2 start, e.g. 10km map
     >  icountx(4),    ! map2 count
     >  map1area,      ! land cover map area
     >  map2area,      ! soil map area
     >  map3area,      ! climate map area
     >  map4area,      ! climate/other map area
     >  map5area       ! cliamte/other map area
c
c -------------------------------------
c map interpolation parameters for ibis
c -------------------------------------
c
      integer map1ncol, map1nrow,  ! hi-res map columns and rows
     >        map2ncol, map2nrow,  ! coarse map columns and rows
     >        map3ncol, map3nrow,  ! coarse map columns and rows
     >        map4ncol, map4nrow,  ! coarse map columns and rows
     >        map5ncol, map5nrow   ! coarse map columns and rows
      real map1res, map1left, map1right, map1upper, map1lower, !hi-res map coordinates
     >     map2res, map2left, map2right, map2upper, map2lower, !coarse map coordinates
     >     map3res, map3left, map3right, map3upper, map3lower, !coarse map coordinates
     >     map4res, map4left, map4right, map4upper, map4lower, !coarse map coordinates
     >     map5res, map5left, map5right, map5upper, map5lower  !coarse map coordinates
c
      common /compar3/ ndaypy, nlonsub, nlatsub, nlonsubs, nlatsubs,
     >                 nclust, cluster,events,
     >                 lccfrom, lccto, lcctime, lcclen, lccflag, 
     >                 rowscale, colscale,
     >                 istart, icount, istartx, icountx,
     >             map1area, map2area, map3area, map4area, map5area,
     >             map1ncol, map1nrow,
     >             map2ncol, map2nrow,
     >             map3ncol, map3nrow,
     >             map4ncol, map4nrow,
     >             map5ncol, map5nrow,
     >             map1res, map1left, map1right, map1upper, map1lower,
     >             map2res, map2left, map2right, map2upper, map2lower,
     >             map3res, map3left, map3right, map3upper, map3lower,
     >             map4res, map4left, map4right, map4upper, map4lower,
     >             map5res, map5left, map5right, map5upper, map5lower
c
      integer
     >  ndaypm(12),   ! number of days per month
     >  idies,        ! netcdf file indice
     >  istat,        ! netcdf error flag
     >  nyears,       ! this is the nth year since simulation
     >  mstep         ! this is time step for netcdf file
c
      character*10 cdate        ! date to use in history attribute in files
      character*10 tdate        ! character date for time step
      character*21 tunits       ! time units
c
      common /compar4/ ndaypm, idies, istat, nyears, mstep,
     >  cdate, tdate, tunits
c
      integer
     >  totfips,       ! conus total number of fips code in US fips_list file
     >  nfips          ! max number of fips of a simulation window (subregion)
c
      parameter (totfips = 85,
     >           nfips = 85)

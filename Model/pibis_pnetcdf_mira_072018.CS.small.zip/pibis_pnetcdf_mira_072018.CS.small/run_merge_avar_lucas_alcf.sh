sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc xcovmax.nc xcovmax xcovmax_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc fu.nc fu fu_m.nc
go xcovmax_m.nc xcovmax covmax.dat
go fu_m.nc fu fu.dat

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc aynpptot.nc aynpptot aynpptot_m.nc
fipsum_ibis_051315 aynpptot_m.nc aynpptot ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_aynpptot_m.nc.txt covmax1_sum_aynpptot_m.nc.txt
fipsum_ibis_051315 aynpptot_m.nc aynpptot ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_aynpptot_m.nc.txt covmax2_sum_aynpptot_m.nc.txt
fipsum_ibis_051315 aynpptot_m.nc aynpptot ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_aynpptot_m.nc.txt covmax3_sum_aynpptot_m.nc.txt
fipsum_ibis_051315 aynpptot_m.nc aynpptot ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_aynpptot_m.nc.txt covmax4_sum_aynpptot_m.nc.txt
fipsum_ibis_051315 aynpptot_m.nc aynpptot ecoreg.dat float 763 1206 1 300 fu.dat 0.0 1.0
mv sum_aynpptot_m.nc.txt fu0010_sum_aynpptot_m.nc.txt
fipsum_ibis_051315 aynpptot_m.nc aynpptot ecoreg.dat float 763 1206 1 300 fu.dat 0.5 1.0
mv sum_aynpptot_m.nc.txt fu0510_sum_aynpptot_m.nc.txt
rm aynpptot_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc aynbp.nc aynbp aynbp_m.nc
fipsum_ibis_051315 aynbp_m.nc aynbp ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_aynbp_m.nc.txt covmax1_sum_aynbp_m.nc.txt
fipsum_ibis_051315 aynbp_m.nc aynbp ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_aynbp_m.nc.txt covmax2_sum_aynbp_m.nc.txt
fipsum_ibis_051315 aynbp_m.nc aynbp ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_aynbp_m.nc.txt covmax3_sum_aynbp_m.nc.txt
fipsum_ibis_051315 aynbp_m.nc aynbp ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_aynbp_m.nc.txt covmax4_sum_aynbp_m.nc.txt
fipsum_ibis_051315 aynbp_m.nc aynbp ecoreg.dat float 763 1206 1 300 fu.dat 0.0 1.0
mv sum_aynbp_m.nc.txt fu0010_sum_aynbp_m.nc.txt
fipsum_ibis_051315 aynbp_m.nc aynbp ecoreg.dat float 763 1206 1 300 fu.dat 0.5 1.0
mv sum_aynbp_m.nc.txt fu0510_sum_aynbp_m.nc.txt
rm aynbp_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc cbiotot.nc cbiotot cbiotot_m.nc
fipsum_ibis_051315 cbiotot_m.nc cbiotot ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_cbiotot_m.nc.txt covmax1_sum_cbiotot_m.nc.txt
fipsum_ibis_051315 cbiotot_m.nc cbiotot ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_cbiotot_m.nc.txt covmax2_sum_cbiotot_m.nc.txt
fipsum_ibis_051315 cbiotot_m.nc cbiotot ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_cbiotot_m.nc.txt covmax3_sum_cbiotot_m.nc.txt
fipsum_ibis_051315 cbiotot_m.nc cbiotot ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_cbiotot_m.nc.txt covmax4_sum_cbiotot_m.nc.txt
fipsum_ibis_051315 cbiotot_m.nc cbiotot ecoreg.dat float 763 1206 1 300 fu.dat 0.0 1.0
mv sum_cbiotot_m.nc.txt fu0010_sum_cbiotot_m.nc.txt
fipsum_ibis_051315 cbiotot_m.nc cbiotot ecoreg.dat float 763 1206 1 300 fu.dat 0.5 1.0
mv sum_cbiotot_m.nc.txt fu0510_sum_cbiotot_m.nc.txt
rm cbiotot_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc totlit.nc totlit totlit_m.nc
fipsum_ibis_051315 totlit_m.nc totlit ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_totlit_m.nc.txt covmax1_sum_totlit_m.nc.txt
fipsum_ibis_051315 totlit_m.nc totlit ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_totlit_m.nc.txt covmax2_sum_totlit_m.nc.txt
fipsum_ibis_051315 totlit_m.nc totlit ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_totlit_m.nc.txt covmax3_sum_totlit_m.nc.txt
fipsum_ibis_051315 totlit_m.nc totlit ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_totlit_m.nc.txt covmax4_sum_totlit_m.nc.txt
fipsum_ibis_051315 totlit_m.nc totlit ecoreg.dat float 763 1206 1 300 covmax.dat 0.0 1.0
mv sum_totlit_m.nc.txt fu0010_sum_totlit_m.nc.txt
fipsum_ibis_051315 totlit_m.nc totlit ecoreg.dat float 763 1206 1 300 covmax.dat 0.5 1.0
mv sum_totlit_m.nc.txt fu0510_sum_totlit_m.nc.txt
rm totlit_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc totcsoi.nc totcsoi totcsoi_m.nc
fipsum_ibis_051315 totcsoi_m.nc totcsoi ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_totcsoi_m.nc.txt covmax1_sum_totcsoi_m.nc.txt
fipsum_ibis_051315 totcsoi_m.nc totcsoi ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_totcsoi_m.nc.txt covmax2_sum_totcsoi_m.nc.txt
fipsum_ibis_051315 totcsoi_m.nc totcsoi ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_totcsoi_m.nc.txt covmax3_sum_totcsoi_m.nc.txt
fipsum_ibis_051315 totcsoi_m.nc totcsoi ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_totcsoi_m.nc.txt covmax4_sum_totcsoi_m.nc.txt
fipsum_ibis_051315 totcsoi_m.nc totcsoi ecoreg.dat float 763 1206 1 300 fu.dat 0.0 1.0
mv sum_totcsoi_m.nc.txt fu0010_sum_totcsoi_m.nc.txt
fipsum_ibis_051315 totcsoi_m.nc totcsoi ecoreg.dat float 763 1206 1 300 fu.dat 0.5 1.0
mv sum_totcsoi_m.nc.txt fu0510_sum_totcsoi_m.nc.txt
rm totcsoi_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc stdwdc.nc stdwdc stdwdc_m.nc
fipsum_ibis_051315 stdwdc_m.nc stdwdc ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_stdwdc_m.nc.txt covmax1_sum_stdwdc_m.nc.txt
fipsum_ibis_051315 stdwdc_m.nc stdwdc ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_stdwdc_m.nc.txt covmax2_sum_stdwdc_m.nc.txt
fipsum_ibis_051315 stdwdc_m.nc stdwdc ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_stdwdc_m.nc.txt covmax3_sum_stdwdc_m.nc.txt
fipsum_ibis_051315 stdwdc_m.nc stdwdc ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_stdwdc_m.nc.txt covmax4_sum_stdwdc_m.nc.txt
fipsum_ibis_051315 stdwdc_m.nc stdwdc ecoreg.dat float 763 1206 1 300 fu.dat 0.0 1.0
mv sum_stdwdc_m.nc.txt fu0010_sum_stdwdc_m.nc.txt
fipsum_ibis_051315 stdwdc_m.nc stdwdc ecoreg.dat float 763 1206 1 300 fu.dat 0.5 1.0
mv sum_stdwdc_m.nc.txt fu0510_sum_stdwdc_m.nc.txt
rm stdwdc_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc deadwdc.nc deadwdc deadwdc_m.nc
fipsum_ibis_051315 deadwdc_m.nc deadwdc ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_deadwdc_m.nc.txt covmax1_sum_deadwdc_m.nc.txt
fipsum_ibis_051315 deadwdc_m.nc deadwdc ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_deadwdc_m.nc.txt covmax2_sum_deadwdc_m.nc.txt
fipsum_ibis_051315 deadwdc_m.nc deadwdc ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_deadwdc_m.nc.txt covmax3_sum_deadwdc_m.nc.txt
fipsum_ibis_051315 deadwdc_m.nc deadwdc ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_deadwdc_m.nc.txt covmax4_sum_deadwdc_m.nc.txt
fipsum_ibis_051315 deadwdc_m.nc deadwdc ecoreg.dat float 763 1206 1 300 fu.dat 0.0 1.0
mv sum_deadwdc_m.nc.txt fu0010_sum_deadwdc_m.nc.txt
fipsum_ibis_051315 deadwdc_m.nc deadwdc ecoreg.dat float 763 1206 1 300 fu.dat 0.5 1.0
mv sum_deadwdc_m.nc.txt fu0510_sum_deadwdc_m.nc.txt
rm deadwdc_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc rawlitc.nc rawlitc rawlitc_m.nc
fipsum_ibis_051315 rawlitc_m.nc rawlitc ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_rawlitc_m.nc.txt covmax1_sum_rawlitc_m.nc.txt
fipsum_ibis_051315 rawlitc_m.nc rawlitc ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_rawlitc_m.nc.txt covmax2_sum_rawlitc_m.nc.txt
fipsum_ibis_051315 rawlitc_m.nc rawlitc ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_rawlitc_m.nc.txt covmax3_sum_rawlitc_m.nc.txt
fipsum_ibis_051315 rawlitc_m.nc rawlitc ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_rawlitc_m.nc.txt covmax4_sum_rawlitc_m.nc.txt
fipsum_ibis_051315 rawlitc_m.nc rawlitc ecoreg.dat float 763 1206 1 300 fu.dat 0.0 1.0
mv sum_rawlitc_m.nc.txt fu0010_sum_rawlitc_m.nc.txt
fipsum_ibis_051315 rawlitc_m.nc rawlitc ecoreg.dat float 763 1206 1 300 fu.dat 0.5 1.0
mv sum_rawlitc_m.nc.txt fu0510_sum_rawlitc_m.nc.txt
rm rawlitc_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc fallw.nc fallw fallw_m.nc
fipsum_ibis_051315 fallw_m.nc fallw ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_fallw_m.nc.txt covmax1_sum_fallw_m.nc.txt
fipsum_ibis_051315 fallw_m.nc fallw ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_fallw_m.nc.txt covmax2_sum_fallw_m.nc.txt
fipsum_ibis_051315 fallw_m.nc fallw ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_fallw_m.nc.txt covmax3_sum_fallw_m.nc.txt
fipsum_ibis_051315 fallw_m.nc fallw ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_fallw_m.nc.txt covmax4_sum_fallw_m.nc.txt
fipsum_ibis_051315 fallw_m.nc fallw ecoreg.dat float 763 1206 1 300 fu.dat 0.0 1.0
mv sum_fallw_m.nc.txt fu0010_sum_fallw_m.nc.txt
fipsum_ibis_051315 fallw_m.nc fallw ecoreg.dat float 763 1206 1 300 fu.dat 0.5 1.0
mv sum_fallw_m.nc.txt fu0510_sum_fallw_m.nc.txt
rm fallw_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc cdisturb.nc cdisturb cdisturb_m.nc
fipsum_ibis_051315 cdisturb_m.nc cdisturb ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_cdisturb_m.nc.txt covmax1_sum_cdisturb_m.nc.txt
fipsum_ibis_051315 cdisturb_m.nc cdisturb ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_cdisturb_m.nc.txt covmax2_sum_cdisturb_m.nc.txt
fipsum_ibis_051315 cdisturb_m.nc cdisturb ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_cdisturb_m.nc.txt covmax3_sum_cdisturb_m.nc.txt
fipsum_ibis_051315 cdisturb_m.nc cdisturb ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_cdisturb_m.nc.txt covmax4_sum_cdisturb_m.nc.txt
fipsum_ibis_051315 cdisturb_m.nc cdisturb ecoreg.dat float 763 1206 1 300 fu.dat 0.0 1.0
mv sum_cdisturb_m.nc.txt fu0010_sum_cdisturb_m.nc.txt
fipsum_ibis_051315 cdisturb_m.nc cdisturb ecoreg.dat float 763 1206 1 300 fu.dat 0.5 1.0
mv sum_cdisturb_m.nc.txt fu0510_sum_cdisturb_m.nc.txt
rm cdisturb_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc lit2soc.nc lit2soc lit2soc_m.nc
fipsum_ibis_051315 lit2soc_m.nc lit2soc ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_lit2soc_m.nc.txt covmax1_sum_lit2soc_m.nc.txt
fipsum_ibis_051315 lit2soc_m.nc lit2soc ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_lit2soc_m.nc.txt covmax2_sum_lit2soc_m.nc.txt
fipsum_ibis_051315 lit2soc_m.nc lit2soc ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_lit2soc_m.nc.txt covmax3_sum_lit2soc_m.nc.txt
fipsum_ibis_051315 lit2soc_m.nc lit2soc ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_lit2soc_m.nc.txt covmax4_sum_lit2soc_m.nc.txt
fipsum_ibis_051315 lit2soc_m.nc lit2soc ecoreg.dat float 763 1206 1 300 fu.dat 0.0 1.0
mv sum_lit2soc_m.nc.txt fu0010_sum_lit2soc_m.nc.txt
fipsum_ibis_051315 lit2soc_m.nc lit2soc ecoreg.dat float 763 1206 1 300 fu.dat 0.5 1.0
mv sum_lit2soc_m.nc.txt fu0510_sum_lit2soc_m.nc.txt
rm lit2soc_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc lit2co2.nc lit2co2 lit2co2_m.nc
fipsum_ibis_051315 lit2co2_m.nc lit2co2 ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_lit2co2_m.nc.txt covmax1_sum_lit2co2_m.nc.txt
fipsum_ibis_051315 lit2co2_m.nc lit2co2 ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_lit2co2_m.nc.txt covmax2_sum_lit2co2_m.nc.txt
fipsum_ibis_051315 lit2co2_m.nc lit2co2 ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_lit2co2_m.nc.txt covmax3_sum_lit2co2_m.nc.txt
fipsum_ibis_051315 lit2co2_m.nc lit2co2 ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_lit2co2_m.nc.txt covmax4_sum_lit2co2_m.nc.txt
fipsum_ibis_051315 lit2co2_m.nc lit2co2 ecoreg.dat float 763 1206 1 300 fu.dat 0.0 1.0
mv sum_lit2co2_m.nc.txt fu0010_sum_lit2co2_m.nc.txt
fipsum_ibis_051315 lit2co2_m.nc lit2co2 ecoreg.dat float 763 1206 1 300 fu.dat 0.5 1.0
mv sum_lit2co2_m.nc.txt fu0510_sum_lit2co2_m.nc.txt
rm lit2co2_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc down2lit.nc down2lit down2lit_m.nc
fipsum_ibis_051315 down2lit_m.nc down2lit ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_down2lit_m.nc.txt covmax1_sum_down2lit_m.nc.txt
fipsum_ibis_051315 down2lit_m.nc down2lit ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_down2lit_m.nc.txt covmax2_sum_down2lit_m.nc.txt
fipsum_ibis_051315 down2lit_m.nc down2lit ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_down2lit_m.nc.txt covmax3_sum_down2lit_m.nc.txt
fipsum_ibis_051315 down2lit_m.nc down2lit ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_down2lit_m.nc.txt covmax4_sum_down2lit_m.nc.txt
fipsum_ibis_051315 down2lit_m.nc down2lit ecoreg.dat float 763 1206 1 300 fu.dat 0.0 1.0
mv sum_down2lit_m.nc.txt fu0010_sum_down2lit_m.nc.txt
fipsum_ibis_051315 down2lit_m.nc down2lit ecoreg.dat float 763 1206 1 300 fu.dat 0.5 1.0
mv sum_down2lit_m.nc.txt fu0510_sum_down2lit_m.nc.txt
rm down2lit_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc soc2co2.nc soc2co2 soc2co2_m.nc
fipsum_ibis_051315 soc2co2_m.nc soc2co2 ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_soc2co2_m.nc.txt covmax1_sum_soc2co2_m.nc.txt
fipsum_ibis_051315 soc2co2_m.nc soc2co2 ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_soc2co2_m.nc.txt covmax2_sum_soc2co2_m.nc.txt
fipsum_ibis_051315 soc2co2_m.nc soc2co2 ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_soc2co2_m.nc.txt covmax3_sum_soc2co2_m.nc.txt
fipsum_ibis_051315 soc2co2_m.nc soc2co2 ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_soc2co2_m.nc.txt covmax4_sum_soc2co2_m.nc.txt
fipsum_ibis_051315 soc2co2_m.nc soc2co2 ecoreg.dat float 763 1206 1 300 fu.dat 0.0 1.0
mv sum_soc2co2_m.nc.txt fu0010_sum_soc2co2_m.nc.txt
fipsum_ibis_051315 soc2co2_m.nc soc2co2 ecoreg.dat float 763 1206 1 300 fu.dat 0.5 1.0
mv sum_soc2co2_m.nc.txt fu0510_sum_soc2co2_m.nc.txt
rm soc2co2_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc stdwcloss.nc stdwcloss stdwcloss_m.nc
fipsum_ibis_051315 stdwcloss_m.nc stdwcloss ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_stdwcloss_m.nc.txt covmax1_sum_stdwcloss_m.nc.txt
fipsum_ibis_051315 stdwcloss_m.nc stdwcloss ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_stdwcloss_m.nc.txt covmax2_sum_stdwcloss_m.nc.txt
fipsum_ibis_051315 stdwcloss_m.nc stdwcloss ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_stdwcloss_m.nc.txt covmax3_sum_stdwcloss_m.nc.txt
fipsum_ibis_051315 stdwcloss_m.nc stdwcloss ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_stdwcloss_m.nc.txt covmax4_sum_stdwcloss_m.nc.txt
fipsum_ibis_051315 stdwcloss_m.nc stdwcloss ecoreg.dat float 763 1206 1 300 fu.dat 0.0 1.0
mv sum_stdwcloss_m.nc.txt fu0010_sum_stdwcloss_m.nc.txt
fipsum_ibis_051315 stdwcloss_m.nc stdwcloss ecoreg.dat float 763 1206 1 300 fu.dat 0.5 1.0
mv sum_stdwcloss_m.nc.txt fu0510_sum_stdwcloss_m.nc.txt
rm stdwcloss_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc yrleach.nc yrleach yrleach_m.nc
fipsum_ibis_051315 yrleach_m.nc yrleach ecoreg.dat float 763 1206 1 300 covmax.dat 1 1
mv sum_yrleach_m.nc.txt covmax1_sum_yrleach_m.nc.txt
fipsum_ibis_051315 yrleach_m.nc yrleach ecoreg.dat float 763 1206 1 300 covmax.dat 2 2
mv sum_yrleach_m.nc.txt covmax2_sum_yrleach_m.nc.txt
fipsum_ibis_051315 yrleach_m.nc yrleach ecoreg.dat float 763 1206 1 300 covmax.dat 3 3
mv sum_yrleach_m.nc.txt covmax3_sum_yrleach_m.nc.txt
fipsum_ibis_051315 yrleach_m.nc yrleach ecoreg.dat float 763 1206 1 300 covmax.dat 4 4
mv sum_yrleach_m.nc.txt covmax4_sum_yrleach_m.nc.txt
fipsum_ibis_051315 yrleach_m.nc yrleach ecoreg.dat float 763 1206 1 300 fu.dat 0.0 1.0
mv sum_yrleach_m.nc.txt fu0010_sum_yrleach_m.nc.txt
fipsum_ibis_051315 yrleach_m.nc yrleach ecoreg.dat float 763 1206 1 300 fu.dat 0.5 1.0
mv sum_yrleach_m.nc.txt fu0510_sum_yrleach_m.nc.txt
rm yrleach_m.nc



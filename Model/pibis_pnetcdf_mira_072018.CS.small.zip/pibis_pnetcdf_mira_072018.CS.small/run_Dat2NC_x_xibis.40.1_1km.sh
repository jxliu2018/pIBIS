#!/bin/bash
block=1
while [ $block -le 21 ]; do
            echo current block: $block
            if [ $block -gt 21 ]; then
               break          # all blocks allocated.
            fi
# corresponding to ibislib.f yearly outputp1~outputp40
# 1~11
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/fips.dat fips ../xibis$block/fips.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/ecoreg.dat ecoreg ../xibis$block/ecoreg.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/xcovmax.dat xcovmax ../xibis$block/xcovmax.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/fu.dat fu ../xibis$block/fu.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/cbiotot.dat cbiotot ../xibis$block/cbiotot.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/totbiou.dat totbiou ../xibis$block/totbiou.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/totcsoi.dat totcsoi ../xibis$block/totcsoi.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/stddown.dat stddown ../xibis$block/stddown.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/cgrain.dat cgrain ../xibis$block/cgrain.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/vegtype0.dat vegtype0 ../xibis$block/vegtype0.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/aynpptot.dat aynpptot ../xibis$block/aynpptot.nc
# 12~20
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/totlit.dat totlit ../xibis$block/totlit.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/ayneetot.dat ayneetot ../xibis$block/ayneetot.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/aynbp.dat aynbp ../xibis$block/aynbp.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/ayCH4.dat ayCH4 ../xibis$block/ayCH4.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/ayn2oflux.dat ayn2oflux ../xibis$block/ayn2oflux.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/gdd5this.dat gdd5this ../xibis$block/gdd5this.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/ayprcp.dat ayprcp ../xibis$block/ayprcp.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/totceco.dat totceco ../xibis$block/totceco.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/yrleach.dat yrleach ../xibis$block/yrleach.nc
# 21~30
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/xdist.dat xdist ../xibis$block/xdist.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/logging.dat logging ../xibis$block/logging.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/soilcomb.dat soilcomb ../xibis$block/soilcomb.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/vegcomb.dat vegcomb ../xibis$block/vegcomb.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/strawc.dat strawc ../xibis$block/strawc.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/deadcrem.dat deadcrem ../xibis$block/deadcrem.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/livecrem.dat livecrem ../xibis$block/livecrem.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/cdisturb.dat cdisturb ../xibis$block/cdisturb.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/totwdl.dat totwdl ../xibis$block/totwdl.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/stdwdc.dat stdwdc ../xibis$block/stdwdc.nc
# 31~40
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/rawlitc.dat rawlitc ../xibis$block/rawlitc.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/fallw.dat fallw ../xibis$block/fallw.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/livc2std.dat livc2std ../xibis$block/livc2std.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/livc2down.dat livc2down ../xibis$block/livc2down.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/stdwcloss.dat stdwcloss ../xibis$block/stdwcloss.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/down2lit.dat down2lit ../xibis$block/down2lit.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/lit2co2.dat lit2co2 ../xibis$block/lit2co2.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/lit2soc.dat lit2soc ../xibis$block/lit2soc.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/soc2co2.dat soc2co2 ../xibis$block/soc2co2.nc
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/raw2lit.dat raw2lit ../xibis$block/raw2lit.nc
# others
#            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/cfruit.dat cfruit ../xibis$block/cfruit.nc
#            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/csoislow.dat csoislow ../xibis$block/csoislow.nc
#            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/deadwdc.dat deadwdc ../xibis$block/deadwdc.nc
            let block=block+1
done
exit


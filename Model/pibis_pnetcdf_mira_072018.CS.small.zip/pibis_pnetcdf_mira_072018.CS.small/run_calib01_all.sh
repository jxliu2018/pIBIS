#### convert netcdf_m.data to raw binery_m.data
go fips_m.nc fips fips.dat
go ecoreg_m.nc ecoreg ecoreg.dat
go xcovmax_m.nc xcovmax covmax.dat
go fu_m.nc fu fu.dat

#### for calibration purpose
# nc_interp_samp conus_pct_agr960m_schar.nc pct_agr p_list_nc_interp_local.asc
# mv conus_pct_agr960m_schar.nc_x.dat local_pct_agr960m_schar.datx
# nc_interp_samp conus_pct_agr960m_schar.nc pct_agr p_list_nc_interp_all.asc
# mv conus_pct_agr960m_schar.nc_x.dat conus_pct_agr960m_schar.nc_x.datx
# nc_interp_samp nlcd_2006_agr_pct_960m_schar.nc pct_agr p_list_nc_interp_all.asc
# mv nlcd_2006_agr_pct_960m_schar.nc_x.dat nlcd_2006_agr_pct_960m_schar.nc_x.datx

cp -p cgrain_m.nc cgrain_m_calib.nc
cp -p aynpptot_m.nc aynpptot_m_calib.nc
cp -p totbiou_m.nc totbiou_m_calib.nc
cp -p stddown_m.nc stddown_m_calib.nc

#fipsum_ibis_pct_112015 cgrain_m_calib.nc cgrain fips.dat float 1018 1608 1 115 covmax.dat 2 2 local_pct_agr960m_schar.datx 11 100
#fipsum_biom_ibis_102615 totbiou_m_calib.nc totbiou fips.dat float 1018 1608 1 115 fu.dat 0.5 1.0
#fipsum_biom_ibis_102615 stddown_m_calib.nc stddown fips.dat float 1018 1608 1 115 fu.dat 0.5 1.0

#fipsum_ibis_pct_112015 cgrain_m_calib.nc cgrain ecoreg.dat float 1018 1608 1 115 covmax.dat 2 2 conus_pct_agr960m_schar.nc_x.datx 11 100
fipsum_ibis_pct_112015 cgrain_m_calib.nc cgrain ecoreg.dat float 1018 1608 1 115 covmax.dat 2 2 nlcd_2006_agr_pct_960m_schar.nc_x.datx 11 100
fipsum_biom_ibis_102615 totbiou_m_calib.nc totbiou ecoreg.dat float 1018 1608 1 115 fu.dat 0.5 1.0
fipsum_biom_ibis_102615 stddown_m_calib.nc stddown ecoreg.dat float 1018 1608 1 115 fu.dat 0.5 1.0

#fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot fips.dat float 1018 1608 1 115 fu.dat 0.5 1.0
#fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot fips.dat float 1018 1608 1 115 covmax.dat 3 3
#fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot fips.dat float 1018 1608 1 115 covmax.dat 4 4
#fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot fips.dat float 1018 1608 1 115 covmax.dat 2 2

fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot ecoreg.dat float 1018 1608 1 115 fu.dat 0.5 1.0
mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.f
fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot ecoreg.dat float 1018 1608 1 115 covmax.dat 3 3
mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.s
fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot ecoreg.dat float 1018 1608 1 115 covmax.dat 4 4
mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.g
fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot ecoreg.dat float 1018 1608 1 115 covmax.dat 2 2
mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.c

#cp -p paramsx.scl.conus84.base CONUS_scalers.txt
#cp -p CONUS_scalers_base.txt CONUS_scalers.txt
cp -p paramsx.scl CONUS_scalers.txt
scalers_ibis.120216 p_list_scalers_all.asc
tar czf calib_ecosum_temp.tar.gz *_temp.txt *_m_calib.nc.txt* *.scl p_list_scalers_*


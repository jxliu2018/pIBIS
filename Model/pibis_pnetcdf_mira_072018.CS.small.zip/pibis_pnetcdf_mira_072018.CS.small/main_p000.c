/*               _       
 _ __ ___   __ _(_)_ __    ___
| '_ ` _ \ / _` | | '_ \  / __|
| | | | | | (_| | | | | || (__
|_| |_| |_|\__,_|_|_| |_(_)___|
                       
*/
//main.c ~ pibis
//Wanjing Wei, pnetcdf procedures
//Jinxun Liu, updated 8/9/2017
//jxliu@usgs.gov

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
//#include <mpi.h>
#include "netcdf.h"
#include "ibis_common_p.h"

const int s1 = npoi*saveyears;
int fg = 1;
void ibislib_(float m1[][npoi*6], float m2[][npoi*12], float m3[][npoi*anomyears*12], 
         float m4[][npoi], float m5[][npoi*lccyears],
         float vp[1200], float vs[nfips*9], float vl[nfips*9], float arr[npoi*400],
         float o1[s1], float o2[s1], float o3[s1], float o4[s1], float o5[s1],
         float o6[s1], float o7[s1], float o8[s1], float o9[s1], float o10[s1],
         float o11[s1], float o12[s1], float o13[s1], float o14[s1], float o15[s1],
         float o16[s1], float o17[s1], float o18[s1], float o19[s1], float o20[s1],
         float o21[s1], float o22[s1], float o23[s1], float o24[s1], float o25[s1],
         float o26[s1], float o27[s1], float o28[s1], float o29[s1], float o30[s1],
         float o31[s1], float o32[s1], float o33[s1], float o34[s1], float o35[s1],
         float o36[s1], float o37[s1], float o38[s1], float o39[s1], float o40[s1]);

const int dimcnt = 20;
int vectorp_len = 1200;
int vectors_len = nfips*9;
int vectorl_len = nfips*9;

char dimnames[][50] = {
"array_size1", "array_size1_samp", "array_size1_interp",
"array_size2", "array_size2_samp", "array_size2_interp",
"array_size3", "array_size3_samp", "array_size3_interp",
"array_size4", "array_size4_samp", "array_size4_interp",
"array_size5", "array_size5_samp", "array_size5_interp",
"vectorp_len", "vectors_len", "vectorl_len",
"array_size4_interp_s", "array_size4_interp_x"
};

int dimid[50];
int ncid1, ncid2, ncid3, ncid4, ncid5;
int ncid, varid[105];
int varcnt = 80; //77; added onwer_type, nmmax, ndep

char varnames[][105] = {
"vectorp", "vectors", "vectorl",
"surta_data", "serial_id_samp", "cell_lat_data", "cell_area_data", "topo_data",
"vegtype0_data", "ecoreg_data", "fips_data", "fips123", "wetland_data", "biomf_c_data",
"bioms_c_data", "biomg_c_data", "nh4dep_data", "no3dep_data", "burnlow_data",
"burnmix_data", "burnhigh_data", "pct_for_data", "pct_shr_data", "pct_gra_data",
"pct_agr_data", "pct_c3crop_data", "pct_wdcrop_data", "pct_wetland_data",
"pct_nveg_data", "soilc_data", "owner_type_data","nmmax_data", "deltat_norm_data_interp",
"sand_data_scatter", "clay_data_scatter", "ph_data_scatter",
"wetd_norm_data_scatter", "cld_norm_data_scatter", "prec_norm_data_scatter",
"temp_norm_data_scatter", "trange_norm_data_scatter", "rhum_norm_data_scatter",
"wspd_norm_data_scatter", "co2spa_norm_data_scatter",
"prec_anorm_data_scatter1", "prec_anorm_data_scatter2", "prec_anorm_data_scatter3",
"prec_anorm_data_scatter4", "prec_anorm_data_scatter5", "prec_anorm_data_scatter6",
"prec_anorm_data_scatter7", "prec_anorm_data_scatter8", "prec_anorm_data_scatter9",
"temp_anorm_data_scatter1", "temp_anorm_data_scatter2", "temp_anorm_data_scatter3",
"temp_anorm_data_scatter4", "temp_anorm_data_scatter5", "temp_anorm_data_scatter6",
"temp_anorm_data_scatter7", "temp_anorm_data_scatter8", "temp_anorm_data_scatter9",
"trange_anorm_data_scatter1", "trange_anorm_data_scatter2", "trange_anorm_data_scatter3",
"trange_anorm_data_scatter4", "trange_anorm_data_scatter5", "trange_anorm_data_scatter6",
"trange_anorm_data_scatter7", "trange_anorm_data_scatter8", "trange_anorm_data_scatter9",
"lcc_data_scatter",
"fire_data_scatter", "burnlf_data_scatter", "burnhf_data_scatter",
"burnmf_data_scatter", "burnls_data_scatter", "burnhs_data_scatter", "burnms_data_scatter",
"ndep_data_scatter"
};

int vardimind[] = {
15,16,17,
0,1,0,0,0,//0 for one-layer map before sampling; 1 for serial ID after sampling
0,0,0,0,0,0,
0,0,0,0,0,
0,0,0,0,0,
0,0,0,0,
0,0,0,0,8,//8 for deltat interp?
4,4,4,    //4 for soil texture data after sampling
7,7,7,    //7 for norm cliamte data after sampling
7,7,7,
7,7,
18,18,18, //18 for anom data interp
18,18,18,
18,18,18,
18,18,18,
18,18,18,
18,18,18,
18,18,18,
18,18,18,
18,18,18,
13,       //13 for lcc/fire data after sampling
13,13,13,
13,13,13,13,
13
};

nc_type vartypes[] = {
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_BYTE, NC_INT, NC_FLOAT, NC_BYTE, NC_FLOAT,
NC_BYTE, NC_BYTE, NC_INT, NC_INT, NC_BYTE, NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT, NC_FLOAT, NC_BYTE,
NC_BYTE, NC_BYTE, NC_BYTE, NC_BYTE, NC_BYTE,
NC_BYTE, NC_BYTE, NC_BYTE, NC_BYTE,
NC_BYTE, NC_FLOAT, NC_BYTE, NC_FLOAT, NC_FLOAT,  //non_veg, soilc, owner, nmmax, deltat
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_FLOAT, NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_FLOAT
};
/*
MPI_Datatype readtypes[] = {
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT,
MPI_BYTE, MPI_INT, MPI_FLOAT, MPI_BYTE, MPI_FLOAT,
MPI_BYTE, MPI_BYTE, MPI_INT, MPI_INT, MPI_BYTE, MPI_FLOAT,//wetland data tyep?
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT, MPI_FLOAT, MPI_BYTE,
MPI_BYTE, MPI_BYTE, MPI_BYTE, MPI_BYTE, MPI_BYTE,
MPI_BYTE, MPI_BYTE, MPI_BYTE, MPI_BYTE,//pct_wdcrop_data, pct_wetland_data
MPI_BYTE, MPI_FLOAT, MPI_BYTE, MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT,
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT, MPI_FLOAT, MPI_FLOAT, MPI_FLOAT,
MPI_FLOAT
};
*/
void data_init(int rank) {
  int flag = 0;
  int status;
  int i;
  if(rank == 0){
    status = nc_create("global1.nc", NC_NOCLOBBER, &ncid1);
        if (status == NC_NOERR) flag = 1;
    status = nc_create("global2.nc", NC_NOCLOBBER, &ncid2);
        if (status == NC_NOERR) flag = 1;
    status = nc_create("global3.nc", NC_NOCLOBBER, &ncid3);
        if (status == NC_NOERR) flag = 1;
    status = nc_create("global4.nc", NC_NOCLOBBER, &ncid4);
        if (status == NC_NOERR) flag = 1;
    status = nc_create("global5.nc", NC_NOCLOBBER, &ncid5);
        if (status == NC_NOERR) flag = 1;
    readnames();//read netcdf and params file names
      printf("passed readnames()\n");
    rdinfile(); //read the control file
      printf("passed rdinfile()\n");
    rdparam();  //read all the fixed parameters
      printf("passed rdparam()\n");
    ncread0(flag);  //read map parameters for netcdf processing
      printf("passed ncread0()\n");
    ncread1(flag);  //read single layer maps
      printf("passed ncread1() on rank 0  -- all single layer data\n");

    use_anom[0] = 1;
    use_lcc[0] = 1;
    use_fire[0] = 1;
    use_ndep[0] = 1;
    biom_reset[0] = 0;
    if(iyranom > iyear0 + nrun)
      use_anom[0] = 0;
    if(isimfire > iyear0 + nrun)
      use_fire[0] = 0;
    if(events > iyear0 + nrun)
      use_lcc[0] = 0;
    if(isimco2 == 0)
      use_ndep[0] = 0;
    if(idiag > 0)
      biom_reset[0] = idiag;

    //print some info from ncread0() and calc_valid_seg()
    //printf("  -- total_npoi = %d\n",total_npoi);
    //printf("  -- nlatsub = %d\n",nlatsub);
    //printf("  -- nlonsub = %d\n",nlonsub);
    //printf("  -- rowscale = %d\n",rowscale);
    //printf("  -- colscale = %d\n",colscale);
    //printf("  -- nlatsubs = %d\n",nlatsubs);
    //printf("  -- nlonsubs = %d\n",nlonsubs);
    printf("  -- total valid_segment = %d\n", valid_segment);
    //printf("  -- MPI nprocs = %d\n\n", nprocs);
    //printf("  -- use_anom = %d\n", use_anom[0]);
    //printf("  -- use_fire = %d\n", use_fire[0]);
    //printf("  -- use_lcc = %d\n", use_lcc[0]);
    //printf("  -- use_ndep = %d\n", use_ndep[0]);
    //printf("  -- biom_reset = %d\n", biom_reset[0]);
    //endtime   = MPI_Wtime();
    //printf("  -- time now %f seconds\n\n",endtime-starttime);
  }

  if(rank == 0){
    ncread2(flag);  //soil maps
      printf("passed ncread2()\n");
    ncread3(flag);
      printf("passed ncread3()\n");
  }

  if(rank == 0){
    ncread4_1(flag);  //prec anom
    ncread4_2(flag);  //prec anom
    ncread4_3(flag);  //prec anom
    ncread4_4(flag);  //prec anom
    ncread4_5(flag);  //prec anom
    ncread4_6(flag);  //prec anom
    ncread4_7(flag);  //prec anom
    ncread4_8(flag);  //prec anom
    ncread4_9(flag);  //prec anom
      printf("passed ncread4()\n");
  }

  if(rank == 0){
    ncread5_1(flag);  //temp anom
    ncread5_2(flag);  //temp anom
    ncread5_3(flag);  //temp anom
    ncread5_4(flag);  //temp anom
    ncread5_5(flag);  //temp anom
    ncread5_6(flag);  //temp anom
    ncread5_7(flag);  //temp anom
    ncread5_8(flag);  //temp anom
    ncread5_9(flag);  //temp anom
      printf("passed ncread5()\n");
  }

  if(rank == 0){
    if (flag) {
      ncread6_1(flag);  //trange anom
      ncread6_2(flag);  //trange anom
      ncread6_3(flag);  //trange anom
      ncread6_4(flag);  //trange anom
      ncread6_5(flag);  //trange anom
      ncread6_6(flag);  //trange anom
      ncread6_7(flag);  //trange anom
      ncread6_8(flag);  //trange anom
      ncread6_9(flag);  //trange anom
      printf("passed ncread6()\n");
    }
  }

  if(rank == 0){
    if (flag) {
      ncread7(flag);  //lcc
      printf("passed ncread7()\n");
    }
  }

  if(rank == 0){
    if (flag) {
      ncread8_1(flag);  //fire
      ncread8_2(flag);  //fire
      ncread8_3(flag);  //fire
      ncread8_4(flag);  //fire
      ncread8_5(flag);  //fire
      ncread8_6(flag);  //fire
      ncread8_7(flag);  //fire
      printf("passed ncread8()\n");
    }
  }

  if (rank == 0) { 
    if (flag) {
      ncread9(flag);
      printf("passed ncread9()\n");
    }

  }

  void* varpointers[] = {
  vectorp, vectors, vectorl,
  surta_data, serial_id_samp, cell_lat_data, cell_area_data, topo_data,
  vegtype0_data, ecoreg_data, fips_data, fips123, wetland_data, biomf_c_data,
  bioms_c_data, biomg_c_data, nh4dep_data, no3dep_data, burnlow_data,
  burnmix_data, burnhigh_data, pct_for_data, pct_shr_data, pct_gra_data,
  pct_agr_data, pct_c3crop_data, pct_wdcrop_data, pct_wetland_data,
  pct_nveg_data, soilc_data, owner_type_data, nmmax_data, deltat_norm_data_interp,
  sand_data_scatter, clay_data_scatter, ph_data_scatter,
  wetd_norm_data_scatter, cld_norm_data_scatter, prec_norm_data_scatter,
  temp_norm_data_scatter, trange_norm_data_scatter, rhum_norm_data_scatter,
  wspd_norm_data_scatter, co2spa_norm_data_scatter,
  prec_anorm_data_scatter1, prec_anorm_data_scatter2, prec_anorm_data_scatter3,
  prec_anorm_data_scatter4, prec_anorm_data_scatter5, prec_anorm_data_scatter6,
  prec_anorm_data_scatter7, prec_anorm_data_scatter8, prec_anorm_data_scatter9,
  temp_anorm_data_scatter1, temp_anorm_data_scatter2, temp_anorm_data_scatter3,
  temp_anorm_data_scatter4, temp_anorm_data_scatter5, temp_anorm_data_scatter6,
  temp_anorm_data_scatter7, temp_anorm_data_scatter8, temp_anorm_data_scatter9,
  trange_anorm_data_scatter1, trange_anorm_data_scatter2, trange_anorm_data_scatter3,
  trange_anorm_data_scatter4, trange_anorm_data_scatter5, trange_anorm_data_scatter6,
  trange_anorm_data_scatter7, trange_anorm_data_scatter8, trange_anorm_data_scatter9,
  lcc_data_scatter,
  fire_data_scatter, burnlf_data_scatter, burnhf_data_scatter,
  burnmf_data_scatter, burnls_data_scatter, burnhs_data_scatter, burnms_data_scatter,
  ndep_data_scatter
  };

  if (rank == 0) {
    if (flag) {
      int dimnums[] = {
        array_size1, array_size1_samp, array_size1_interp,
        array_size2, array_size2_samp, array_size2_interp,
        array_size3, array_size3_samp, array_size3_interp,
        array_size4, array_size4_samp, array_size4_interp,
        array_size5, array_size5_samp, array_size5_interp,
        vectorp_len, vectors_len, vectorl_len,
        array_size4_interp_s, array_size4_interp_x
      };
      for (i = 0; i < dimcnt; i++) {
        nc_def_dim(ncid1, dimnames[i], dimnums[i], &dimid[i]);
        nc_def_dim(ncid2, dimnames[i], dimnums[i], &dimid[i]);
        nc_def_dim(ncid3, dimnames[i], dimnums[i], &dimid[i]);
        nc_def_dim(ncid4, dimnames[i], dimnums[i], &dimid[i]);
        nc_def_dim(ncid5, dimnames[i], dimnums[i], &dimid[i]);
      }
      printf("passed nc def dim\n");
      for (i = 0; i < 44; i++) {
        nc_def_var(ncid1, varnames[i], vartypes[i], 1, &dimid[vardimind[i]], &varid[i]);
      }
      for (i = 44; i < 53; i++) {
        nc_def_var(ncid2, varnames[i], vartypes[i], 1, &dimid[vardimind[i]], &varid[i]);
      }
      for (i = 53; i < 62; i++) {
        nc_def_var(ncid3, varnames[i], vartypes[i], 1, &dimid[vardimind[i]], &varid[i]);
      }
      for (i = 62; i < 71; i++) {
        nc_def_var(ncid4, varnames[i], vartypes[i], 1, &dimid[vardimind[i]], &varid[i]);
      }
      for (i = 71; i < varcnt; i++) {
        nc_def_var(ncid5, varnames[i], vartypes[i], 1, &dimid[vardimind[i]], &varid[i]);
      }
      printf("passed nc def var\n");
      nc_enddef(ncid1);
      nc_enddef(ncid2);
      nc_enddef(ncid3);
      nc_enddef(ncid4);
      nc_enddef(ncid5);
      for (i = 0; i < 44; i++) {
        status = nc_put_var(ncid1, varid[i], varpointers[i]);
        if (status != NC_NOERR) printf("putvar %s error=%d\n", varnames[i], status);
      }
      for (i = 44; i < 53; i++) {
        status = nc_put_var(ncid2, varid[i], varpointers[i]);
        if (status != NC_NOERR) printf("putvar %s error=%d\n", varnames[i], status);
      }
      for (i = 53; i < 62; i++) {
        status = nc_put_var(ncid3, varid[i], varpointers[i]);
        if (status != NC_NOERR) printf("putvar %s error=%d\n", varnames[i], status);
      }
      for (i = 62; i < 71; i++) {
        status = nc_put_var(ncid4, varid[i], varpointers[i]);
        if (status != NC_NOERR) printf("putvar %s error=%d\n", varnames[i], status);
      }
      for (i = 71; i < varcnt; i++) {
        status = nc_put_var(ncid5, varid[i], varpointers[i]);
        if (status != NC_NOERR) printf("putvar %s error=%d\n", varnames[i], status);
      }
      nc_close(ncid1);
      nc_close(ncid2);
      nc_close(ncid3);
      nc_close(ncid4);
      nc_close(ncid5);
      printf("passed nc put value\n");
    }
  }

  if(rank == 0){
    if (flag) {
      free(surta_data);
      free(serial_id_samp);
      free(cell_lat_data);
      free(cell_area_data);
      free(topo_data);
      free(vegtype0_data);
      free(ecoreg_data);
      free(fips_data);
      free(fips123);
      free(wetland_data);
      free(biomf_c_data);
      free(bioms_c_data);
      free(biomg_c_data);
      free(nh4dep_data);
      free(no3dep_data);
      free(burnlow_data);
      free(burnmix_data);
      free(burnhigh_data);
      free(pct_for_data);
      free(pct_shr_data);
      free(pct_gra_data);
      free(pct_agr_data);
      free(pct_c3crop_data);
      free(pct_wdcrop_data);
      free(pct_wetland_data);
      free(pct_nveg_data);
      free(soilc_data);
      free(owner_type_data);
      free(nmmax_data);
      free(deltat_norm_data_interp);
      printf("passed free tmp arrays\n");
    }
  }

  if(rank == 0){
    if (flag) {
      free(sand_data_scatter);
      free(clay_data_scatter);
      free(ph_data_scatter);
    }
    printf("passed ncread2() on rank %d  -- six layers of soil data\n", rank);
  }

  if(rank == 0){
    if (flag) {
      free(wetd_norm_data_scatter);
      free(cld_norm_data_scatter);
      free(prec_norm_data_scatter);
      free(temp_norm_data_scatter);
      free(trange_norm_data_scatter);
      free(rhum_norm_data_scatter);
      free(wspd_norm_data_scatter);
      free(co2spa_norm_data_scatter);
    }
    printf("passed ncread3() on rank %d  -- monthly average climate data\n", rank);
  }

  if(rank == 0){
    if (flag) {
      free(prec_anorm_data_scatter1);
      free(prec_anorm_data_scatter2);
      free(prec_anorm_data_scatter3);
      free(prec_anorm_data_scatter4);
      free(prec_anorm_data_scatter5);
      free(prec_anorm_data_scatter6);
      free(prec_anorm_data_scatter7);
      free(prec_anorm_data_scatter8);
      free(prec_anorm_data_scatter9);
      free(prec_anorm_data);
      free(climate_anorm_interp_prec);
    }
    printf("passed ncread4() on rank %d  -- monthly precipitation data\n", rank);
  }

  if(rank == 0){
    if (flag) {
      free(temp_anorm_data_scatter1);
      free(temp_anorm_data_scatter2);
      free(temp_anorm_data_scatter3);
      free(temp_anorm_data_scatter4);
      free(temp_anorm_data_scatter5);
      free(temp_anorm_data_scatter6);
      free(temp_anorm_data_scatter7);
      free(temp_anorm_data_scatter8);
      free(temp_anorm_data_scatter9);
      free(temp_anorm_data);
      free(climate_anorm_interp_temp);
    }
    printf("passed ncread5() on rank %d  -- monthly temperature data\n", rank);
  }

  if(rank == 0){
    if (flag) {
      free(trange_anorm_data_scatter1);
      free(trange_anorm_data_scatter2);
      free(trange_anorm_data_scatter3);
      free(trange_anorm_data_scatter4);
      free(trange_anorm_data_scatter5);
      free(trange_anorm_data_scatter6);
      free(trange_anorm_data_scatter7);
      free(trange_anorm_data_scatter8);
      free(trange_anorm_data_scatter9);
      free(trange_anorm_data);
      free(climate_anorm_interp_trange);
    }
    printf("passed ncread6() on rank %d  -- monthly temperature range data\n", rank);
  }

  if(rank == 0){
    if (flag) {
      free(lcc_data_scatter);
    }
    printf("passed ncread7() on rank %d  -- annual land cover change data\n", rank);
  }

  if(rank == 0){
    if (flag) {
      free(fire_data_scatter);
      free(burnlf_data_scatter);
      free(burnhf_data_scatter);
      free(burnmf_data_scatter);
      free(burnls_data_scatter);
      free(burnhs_data_scatter);
      free(burnms_data_scatter);
    }
    printf("passed ncread8() on rank %d\n", rank);
  }

  if(rank == 0){
    if (flag) {
      free(ndep_data_scatter);
    }
    printf("passed ncread9() on rank %d  -- annual N deposition data\n", rank);
  }

}//data_init(int rank)

int main(int argc, char* argv[])
{
  if(argc > 1) {
    printf("Usage on ALCF Vesta\n");
    printf("  submit_pibis.sh: qsub -A IBIS-USPED -t 10 -n 1 -O LOG --mode script ./jobscript.sh\n");
    printf("  jobscript.sh: runjob -p 16 --np 1 --block $COBALT_PARTNAME : pibis\n\n");
    printf("Usage on local workstation\n");
    printf("  mpirun -np 5 pibis\n");
    printf("  mpiexec -n 2 ddd pibis\n");
    exit(1);
  }

  //MPI_Status status;
  int ierr, nprocs, rank;
  double starttime, endtime; 
  int arraylength, callocsize, callocerror;
  int USE_GATHER = 0;
  int node_size = 0;
 
  //ierr = MPI_Init(&argc, &argv);
  //ierr = MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  //ierr = MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
  //starttime = MPI_Wtime(); 
  //my_rank = rank;
  rank = 0;

  /* ibis calculation procedures start from master node*/
  if(rank == 0){//mpi root process
    printf("***********************************************\n");
    printf("* IBIS: Integrated BIosphere Simulator        *\n");
    printf("* Jonathan A Forley:  Version 2.5             *\n");
    printf("* David T Price:      Version 2.5+ (CanIBIS)  *\n");
    printf("* Jinxun Liu:         N Cycle, Crop, LULCC    *\n");
    printf("* QiuAn Zhu:          GHG (CH4, N20, NO)      *\n");
    printf("* Jinxun Liu:         Open MPI paralell code  *\n");
    printf("***********************************************\n");

    printf("***********************************************\n");
    printf("* Model setup example:                        *\n");
    printf("* ibis.infile   -- block size,interval,events *\n");
    printf("* ibis_common.h -- npoi = 10                  *\n");
    printf("*               -- saveyears = 110             *\n");
    printf("*               -- block size = 500           *\n");
    printf("*               -- interval = 1               *\n");
    printf("*               -- valid_segment_npoi[l]      *\n");
    printf("* l = 500x500/interval/interval/10 = 25000    *\n");
    printf("***********************************************\n");

    printf("***********************************************\n");
    printf("* Output variable list                        *\n");
    printf("*   key zonal variables                       *\n");
    printf("*           outputp1 = fips(i)                *\n");
    printf("*           outputp2 = ecoreg(i)              *\n");
    printf("*           outputp3 = xcovmax(i)             *\n");
    printf("*   major summary C pools                     *\n");
    printf("*           outputp4 = cbiotot(i)             *\n");
    printf("*           outputp5 = totbiou(i)             *\n");
    printf("*           outputp6 = rawlitc(i)             *\n");
    printf("*           outputp7 = totlit(i)              *\n");
    printf("*           outputp8 = stdwdc(i)              *\n");
    printf("*           outputp9 = deadwdc(i)             *\n");
    printf("*           outputp10 = totcsoi(i)            *\n");
    printf("*   major summary C fluxes                    *\n");
    printf("*           outputp11 = aynpptot(i)           *\n");
    printf("*           outputp12 = ayneetot(i)           *\n");
    printf("*           outputp13 = aynbp(i)              *\n");
    printf("*   additional C fluxes                       *\n");
    printf("*           outputp14 = fallw(i)              *\n");
    printf("*           outputp15 = livc2std(i)           *\n");
    printf("*           outputp16 = livc2down(i)          *\n");
    printf("*           outputp17 = stdwcloss(i)          *\n");
    printf("*           outputp18 = down2lit(i)           *\n");
    printf("*           outputp19 = lit2co2(i)            *\n");
    printf("*           outputp20 = lit2soc(i)            *\n");
    printf("*           outputp21 = soc2co2(i)            *\n");
    printf("*           outputp22 = yrleach(i)            *\n");
    printf("*   disturbance related variables             *\n");
    printf("*           outputp23 = cdisturb(i)           *\n");
    printf("*           outputp24 = logging(i)            *\n");
    printf("*           outputp25 = soilcomb(i)           *\n");
    printf("*           outputp26 = vegcomb(i)            *\n");
    printf("*   agriculture and wetland                   *\n");
    printf("*           outputp27 = cgrain(i)             *\n");
    printf("*           outputp28 = strawc(i)             *\n");
    printf("*   others                                    *\n");
    printf("*           outputp29 = fu(i)                 *\n");
    printf("*           outputp30 = vegtype0(i)           *\n");
    printf("*           outputp31 = cfruit(i)             *\n");
    printf("*           outputp32 = totwdl(i)             *\n");
    printf("*           outputp33 = xdist(i)              *\n");
    printf("*           outputp34 = deadcrem(i)           *\n");
    printf("*           outputp35 = livecrem(i)           *\n");
    printf("*   others                                    *\n");
    printf("*           outputp36 = totceco(i)            *\n");
    printf("*           outputp37 = csoipas(i)            *\n");
    printf("*           outputp38 = csoislop + csoislon   *\n");
    printf("*           outputp39 = ayCH4(i)              *\n");
    printf("*           outputp40 = ayn2oflux(i)          *\n");
    printf("***********************************************\n");
  }//if(rank == 0)

  data_init(rank);
  /*
  if(rank == 0){//mpi root process
      endtime   = MPI_Wtime();
      printf("Rank %d took %f seconds\n",rank,endtime-starttime);
  }//if(rank == 0)

  ierr = MPI_Finalize();
  */
  return 0;
}

void interp_samp_char(char *sourcex, float *interpx, float *sampx, float *targetx, int group){
  int i, j, k, l, ii, jj, iii, jjj;

  map1size = count_g1[2] * count_g1[3];
  map2size = count_g2[2] * count_g2[3];
  map3size = count_g3[2] * count_g3[3];
  map4size = count_g4[2] * count_g4[3];
  mapSsize = nlatsubs * nlonsubs;

  //step 1: interpolate coarse resolution data to base resolution
  if(group == 1){
    for(i=0;i<total_npoi;i++){ //interp single layer map3, deltat
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map3_id[ii] + layerx*map3size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 2){
    for(i=0;i<total_npoi*nsoilay;i++){ //interp 6 layer soil map2
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map2_id[ii] + layerx*map2size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 3){
    for(i=0;i<total_npoi*12;i++){ //interp 12 layer norm climate maps3
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map3_id[ii] + layerx*map3size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 4){
    for(i=0;i<total_npoi*12*saveyears;i++){ //interp 12*saveyears layer anorm climate map4
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map4_id[ii] + layerx*map4size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*lccyears;i++){ //interp lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map1_id[ii] + layerx*map1size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else{
    printf("interp_samp error1!\n");
    exit;
  }

  //Step 2: make sampling dataset from base and interpolated map
  if(group == 1){
    for(i=0;i<total_npoi;i++){ //sampling single layer maps
      ii = i/nlonsub;//original row
      jj = i%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = iii*nlonsubs + jjj; //serial id after sampling (k <= i)

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 2){
    for(i=0;i<total_npoi*nsoilay;i++){ //sampling interpolated 6 layer soil maps
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 3){
    for(i=0;i<total_npoi*12;i++){ //sampling interpolated 12 layer norm climate maps
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 4){
    for(i=0;i<total_npoi*12*saveyears;i++){ //sampling interpolated 12*saveyears layer anorm climate map
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*lccyears;i++){ //sampling interpolated lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else{
    printf("interp_samp error2!\n");
    exit(0);
  }

  //Step 3: rearrange multi-layer sampled data into segment for MPI_SCATTER
  total_segment = mapSsize/npoi; //sampling by rowscale and colscale

  l = 0;
  start_loc_new = 0;
  if(group == 1){
  }
  else if(group == 2){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*nsoilay;i++){ //rearrange 6 layer soil map2
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*nsoilay + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else if(group == 3){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*12;i++){ //rearrange 12 layer norm climate maps3
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*12 + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else if(group == 4){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*12*saveyears;i++){ //rearrange 12*saveyears layer anorm climate map4
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*12*saveyears + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else if(group == 5){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*lccyears;i++){ //rearrange lccyears layer lcc and disturb data
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*lccyears + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else{
    printf("interp_samp error2!\n");
    exit(0);
  }

  return;
}

//------------------------------------------------------------------------
void interp_samp_float(float *sourcex, float *interpx, float *sampx, float *targetx, int group){
  int i, j, k, l, ii, jj, iii, jjj;

  map1size = count_g1[2] * count_g1[3];
  map2size = count_g2[2] * count_g2[3];
  map3size = count_g3[2] * count_g3[3];
  map4size = count_g4[2] * count_g4[3];
  mapSsize = nlatsubs * nlonsubs;

  //step 1: interpolate coarse resolution data to base resolution
  if(group == 1){
    for(i=0;i<total_npoi;i++){ //interp single layer map3, deltat
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map3_id[ii] + layerx*map3size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 2){
    for(i=0;i<total_npoi*nsoilay;i++){ //interp 6 layer soil map2
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map2_id[ii] + layerx*map2size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 3){
    for(i=0;i<total_npoi*12;i++){ //interp 12 layer norm climate maps3
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map3_id[ii] + layerx*map3size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 4){
    for(i=0;i<total_npoi*12*anomyears;i++){ //interp 12*anomyears layer anorm climate map4
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map4_id[ii] + layerx*map4size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*lccyears;i++){ //interp lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map1_id[ii] + layerx*map1size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else{
    printf("interp_samp error1!\n");
    exit;
  }

  //Step 2: make sampling dataset from base and interpolated map
  if(group == 1){
    for(i=0;i<total_npoi;i++){ //sampling single layer maps
      ii = i/nlonsub;//original row
      jj = i%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = iii*nlonsubs + jjj; //serial id after sampling (k <= i)

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 2){
    for(i=0;i<total_npoi*nsoilay;i++){ //sampling interpolated 6 layer soil maps
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 3){
    for(i=0;i<total_npoi*12;i++){ //sampling interpolated 12 layer norm climate maps
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 4){
    for(i=0;i<total_npoi*12*anomyears;i++){ //sampling interpolated 12*anomyears layer anorm climate map
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*lccyears;i++){ //sampling interpolated lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else{
    printf("interp_samp error2!\n");
    exit(0);
  }

  //Step 3: rearrange multi-layer sampled data into segment for MPI_SCATTER
  total_segment = mapSsize/npoi; //sampling by rowscale and colscale

  l = 0;
  start_loc_new = 0;
  if(group == 1){
  }
  else if(group == 2){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*nsoilay;i++){ //rearrange 6 layer soil map2
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*nsoilay + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else if(group == 3){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*12;i++){ //rearrange 12 layer norm climate maps3
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*12 + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else if(group == 4){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*12*anomyears;i++){ //rearrange 12*anomyears layer anorm climate map4
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*12*anomyears + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else if(group == 5){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*lccyears;i++){ //rearrange lccyears layer lcc and disturb data
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*lccyears + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else{
    printf("interp_samp error2!\n");
    exit(0);
  }

  return;
}

//////////////////
void interp_float(float *sourcex, float *interpx, float *targetx, int group, int group_s){
  int i, j, k, l, ii, jj, iii, jjj;
  int offset_s;

  map1size = count_g1[2] * count_g1[3];
  map2size = count_g2[2] * count_g2[3];
  map3size = count_g3[2] * count_g3[3];
  map4size = count_g4[2] * count_g4[3];
  mapSsize = nlatsubs * nlonsubs;
  offset_s = scatter_years * 12 * (group_s - 1);

  //step 1: interpolate coarse resolution data to base resolution
  if(group == 1){
  }
  else if(group == 2){
  }
  else if(group == 3){
  }
  else if(group == 4){
    for(i=0;i<total_npoi*12*scatter_years;i++){ //interp 12*scatter_years layer anorm climate map4
      layerx = i/total_npoi + offset_s;
      remx = i%total_npoi;
      ii = remx;
      iii = map4_id[ii] + layerx*map4size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*lccyears;i++){ //interp lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map1_id[ii] + layerx*map1size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else{
    printf("interp_samp error1!\n");
    exit;
  }

  //Step 2: make sampling dataset from base and interpolated map

  //Step 3: rearrange multi-layer sampled data into segment for MPI_SCATTER
  total_segment = mapSsize/npoi; //sampling by rowscale and colscale

  l = 0;
  start_loc_new = 0;
  if(group == 1){
  }
  else if(group == 2){
  }
  else if(group == 3){
  }
  else if(group == 4){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*12*scatter_years;i++){ //rearrange 12*scatter_years layer anorm climate map4
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*12*scatter_years + i;
        targetx[k] = interpx[iii];
      }
    }
  }
  else if(group == 5){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*lccyears;i++){ //rearrange lccyears layer lcc and disturb data
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*lccyears + i;
        targetx[k] = interpx[iii];
      }
    }
  }
  else{
    printf("interp_float error!\n");
    exit(0);
  }

  return;
}

void interp_samp_float_anom(float *sourcex, float *interpx, float *sampx, float *targetx, int group, int group_s){
  int i, j, k, l, ii, jj, iii, jjj;
  int offset_s;

  map1size = count_g1[2] * count_g1[3];
  map2size = count_g2[2] * count_g2[3];
  map3size = count_g3[2] * count_g3[3];
  map4size = count_g4[2] * count_g4[3];
  mapSsize = nlatsubs * nlonsubs;
  offset_s = scatter_years * 12 * (group_s - 1);

  //step 1: interpolate coarse resolution data to base resolution
  if(group == 4){
    for(i=0;i<total_npoi*12*scatter_years;i++){ //interp 12*scatter_years layer anorm climate map4
      layerx = i/total_npoi + offset_s;
      remx = i%total_npoi;
      ii = remx;
      iii = map4_id[ii] + layerx*map4size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else{
    printf("interp_samp_anom error1!\n");
    exit;
  }

  //Step 2: make sampling dataset from base and interpolated map
  if(group == 4){
    for(i=0;i<total_npoi*12*scatter_years;i++){ //sampling interpolated 12*anomyears layer anorm climate map
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else{
    printf("interp_samp_anom error2!\n");
    exit(0);
  }

  //Step 3: rearrange multi-layer sampled data into segment for MPI_SCATTER
  total_segment = mapSsize/npoi; //sampling by rowscale and colscale

  l = 0;
  start_loc_new = 0;
  if(group == 4){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*12*scatter_years;i++){ //rearrange 12*scatter_years layer anorm climate map4
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*12*scatter_years + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else{
    printf("interp_float_anom error!\n");
    exit(0);
  }

  return;
}
//////////////////

//------------------------------------------------------------------------
void calc_valid_seg(){
    FILE *fp2;

    int i, j, k, l, ii, jj, iii, jjj;
    int seg_all;

    if ((fp2 = fopen("valid_segments.txt", "wt"))==NULL){
      return;
    }

    segment_npoi = 0;
    valid_segment = 0;
    l = 0;
    for(i=0;i<total_npoi;i++){ //sampling single layer maps
      ii = i/nlonsub;//original row
      jj = i%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = iii*nlonsubs + jjj; //serial id after sampling (k <= i)
        l = k/npoi; //segment_id after sampling

        if(surta_data[i] == 1)//be aware of integer promotion issue, -15 -> 222?
          segment_npoi = segment_npoi + 1; //add mask in segment
        if(k%npoi == npoi-1){
          valid_segment_npoi[l] = 0;
          if(segment_npoi > 0){
            valid_segment_npoi[l] = segment_npoi;
            valid_segment = valid_segment + 1;
          }
          //fprintf(fp2, "%d\t%d\t%d\n", l, valid_segment_npoi[l], valid_segment);
          //fprintf(fp2, "%d\n", valid_segment_npoi[l]);
          seg_all = l+1;
          segment_npoi = 0;
        }
      }
    }

    if(valid_segment <= 0){
      printf("no valid segment, exit now!\n");
      exit(-1);
    }

    fprintf(fp2, "%d\n", nlatsubs);
    fprintf(fp2, "%d\n", nlonsubs);
    fprintf(fp2, "%d\n", npoi);
    fprintf(fp2, "%d\n", valid_segment);
    fprintf(fp2, "%d\n", saveyears);
    for(l=0; l<seg_all; l++){
      fprintf(fp2, "%d\n", valid_segment_npoi[l]);
    }
    fclose(fp2);

    return;
}


//------------------------------------------------------------------------
void interp(){
    int i, j, k, l, ii, jj, iii, jjj;

    map1size = count_g1[2] * count_g1[3];
    map2size = count_g2[2] * count_g2[3];
    map3size = count_g3[2] * count_g3[3];
    map4size = count_g4[2] * count_g4[3];
    mapSsize = nlatsubs * nlonsubs;

    //step 1: interpolate coarse resolution data to base resolution
    for(i=0;i<total_npoi;i++){ //interp single layer map3, deltat
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map3_id[ii] + layerx*map3size;

      k = i;
      if(iii >= 0){
        deltat_norm_data_interp[k] = deltat_norm_data[iii];
      }
      else{
        deltat_norm_data_interp[k] = 0;
      }
    }
    printf("  -- interp_step1 passed!\n");

    //Step 2: make sampling dataset from base and interpolated map
    for(i=0;i<total_npoi;i++){ //sampling single layer maps
      ii = i/nlonsub;//original row
      jj = i%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = iii*nlonsubs + jjj; //serial id after sampling (k <= i)

        surta_data[k] = surta_data[i];
        cell_lat_data[k] = cell_lat_data[i];
        cell_area_data[k] = cell_area_data[i];
        topo_data[k] = topo_data[i];
        vegtype0_data[k] = vegtype0_data[i];
        ecoreg_data[k] = ecoreg_data[i];
        fips_data[k] = fips_data[i];
        wetland_data[k] = wetland_data[i];
        biomf_c_data[k] = biomf_c_data[i];
        bioms_c_data[k] = bioms_c_data[i];
        biomg_c_data[k] = biomg_c_data[i];
        nh4dep_data[k] = nh4dep_data[i];
        no3dep_data[k] = no3dep_data[i];
        burnlow_data[k] = burnlow_data[i];
        burnmix_data[k] = burnmix_data[i];
        burnhigh_data[k] = burnhigh_data[i];
        pct_for_data[k] = pct_for_data[i];
        pct_shr_data[k] = pct_shr_data[i];
        pct_gra_data[k] = pct_gra_data[i];
        pct_agr_data[k] = pct_agr_data[i];
        pct_c3crop_data[k] = pct_c3crop_data[i];
        pct_wdcrop_data[k] = pct_wdcrop_data[i];
        pct_wetland_data[k] = pct_wetland_data[i];
        pct_nveg_data[k] = pct_nveg_data[i];
        owner_type_data[k] = owner_type_data[i];
        soilc_data[k] = soilc_data[i];
        nmmax_data[k] = nmmax_data[i];

        deltat_norm_data_interp[k] = deltat_norm_data_interp[i];
        fips123[k] = fips123[i];
        serial_id_samp[k] = k;
      }
    }
    printf("  -- interp_step2 passed!\n");

    //Step 3: rearrange single-layer sampled data into segment for MPI_SCATTER
    total_segment = mapSsize/npoi; //sampling by rowscale and colscale

    l = 0;
    start_loc_new = 0;
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi;i++){ //rearrange data on base map1
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new + i;
        surta_data[k] = surta_data[iii];
        cell_lat_data[k] = cell_lat_data[iii];
        cell_area_data[k] = cell_area_data[iii];
        topo_data[k] = topo_data[iii];
        vegtype0_data[k] = vegtype0_data[iii];
        ecoreg_data[k] = ecoreg_data[iii];
        fips_data[k] = fips_data[iii];
        wetland_data[k] = wetland_data[iii];
        biomf_c_data[k] = biomf_c_data[iii];
        bioms_c_data[k] = bioms_c_data[iii];
        biomg_c_data[k] = biomg_c_data[iii];
        nh4dep_data[k] = nh4dep_data[iii];
        no3dep_data[k] = no3dep_data[iii];
        burnlow_data[k] = burnlow_data[iii];
        burnmix_data[k] = burnmix_data[iii];
        burnhigh_data[k] = burnhigh_data[iii];
        pct_for_data[k] = pct_for_data[iii];
        pct_shr_data[k] = pct_shr_data[iii];
        pct_gra_data[k] = pct_gra_data[iii];
        pct_agr_data[k] = pct_agr_data[iii];
        pct_c3crop_data[k] = pct_c3crop_data[iii];
        pct_wdcrop_data[k] = pct_wdcrop_data[iii];
        pct_wetland_data[k] = pct_wetland_data[iii];
        pct_nveg_data[k] = pct_nveg_data[iii];
        owner_type_data[k] = owner_type_data[iii];
        soilc_data[k] = soilc_data[iii];
        nmmax_data[k] = nmmax_data[iii];

        deltat_norm_data_interp[k] = deltat_norm_data_interp[iii];
        fips123[k] = fips123[iii];
        serial_id_samp[k] = serial_id_samp[iii];
      }
    }
    printf("  -- interp_step3 passed!\n");
}

//------------------------------------------------------------------------
void datapack(){//do this on each rank after MPI_Scatter()
    int i, j, k, l;
    int size_s, offset_s, offset_ss, offset_sss;

    for(i=0;i<npoi;i++){
      
      matrix4[0][i] = local_surta_data[i];
      matrix4[1][i] = local_cell_lat_data[i];
      matrix4[2][i] = local_cell_area_data[i];
      matrix4[3][i] = local_topo_data[i];
      matrix4[4][i] = local_vegtype0_data[i];
      matrix4[5][i] = local_ecoreg_data[i];
      matrix4[6][i] = local_fips_data[i];
      matrix4[7][i] = local_wetland_data[i];
      matrix4[8][i] = local_biomf_c_data[i];
      matrix4[9][i] = local_bioms_c_data[i];
      matrix4[10][i] = local_biomg_c_data[i];
      matrix4[11][i] = local_nh4dep_data[i];
      matrix4[12][i] = local_no3dep_data[i];
      matrix4[13][i] = local_burnlow_data[i];
      matrix4[14][i] = local_burnmix_data[i];
      matrix4[15][i] = local_burnhigh_data[i];
      matrix4[16][i] = local_pct_for_data[i];
      matrix4[17][i] = local_pct_shr_data[i];
      matrix4[18][i] = local_pct_gra_data[i];
      matrix4[19][i] = local_pct_agr_data[i];
      matrix4[20][i] = local_pct_c3crop_data[i];
      matrix4[21][i] = local_pct_wdcrop_data[i];
      matrix4[22][i] = local_pct_wetland_data[i];
      matrix4[23][i] = local_pct_nveg_data[i];
      matrix4[24][i] = local_soilc_data[i];

      matrix4[25][i]= local_deltat_norm_data[i];
      matrix4[26][i] = local_fips123[i];
      matrix4[27][i] = my_rank;
      matrix4[28][i] = local_nmmax_data[i];
      matrix4[29][i] = local_owner_type_data[i];
    }

    for(i=0;i<npoi*nsoilay;i++){
      matrix1[0][i] = matrix1_sand[i];
      matrix1[1][i] = matrix1_clay[i];
      matrix1[2][i] = matrix1_ph[i];
    }

    for(i=0;i<npoi*12;i++){
      matrix2[0][i] = matrix2_wetd_norm[i];
      matrix2[1][i] = matrix2_cld_norm[i];
      matrix2[2][i] = matrix2_prec_norm[i];
      matrix2[3][i] = matrix2_temp_norm[i];
      matrix2[4][i] = matrix2_trange_norm[i];
      matrix2[5][i] = matrix2_rhum_norm[i];
      matrix2[6][i] = matrix2_wspd_norm[i];
      matrix2[7][i] = matrix2_co2spa_norm[i];
    }

    for(k=0; k<anomyears; k++){
      size_s = npoi*12;
      offset_s = size_s*k;
      offset_ss = size_s * (k%scatter_years);
      offset_sss = k/scatter_years;

      for(j=0;j<size_s;j++){
        i = j + offset_s;
        l = j + offset_ss;

        if(offset_sss == 0){
          matrix3[0][i] = matrix3_prec_anorm1[l];
          matrix3[1][i] = matrix3_temp_anorm1[l];
          matrix3[2][i] = matrix3_trange_anorm1[l];
        }
        else if(offset_sss == 1){
          matrix3[0][i] = matrix3_prec_anorm2[l];
          matrix3[1][i] = matrix3_temp_anorm2[l];
          matrix3[2][i] = matrix3_trange_anorm2[l];
        }
        else if(offset_sss == 2){
          matrix3[0][i] = matrix3_prec_anorm3[l];
          matrix3[1][i] = matrix3_temp_anorm3[l];
          matrix3[2][i] = matrix3_trange_anorm3[l];
        }
        else if(offset_sss == 3){
          matrix3[0][i] = matrix3_prec_anorm4[l];
          matrix3[1][i] = matrix3_temp_anorm4[l];
          matrix3[2][i] = matrix3_trange_anorm4[l];
        }
        else if(offset_sss == 4){
          matrix3[0][i] = matrix3_prec_anorm5[l];
          matrix3[1][i] = matrix3_temp_anorm5[l];
          matrix3[2][i] = matrix3_trange_anorm5[l];
        }
        else if(offset_sss == 5){
          matrix3[0][i] = matrix3_prec_anorm6[l];
          matrix3[1][i] = matrix3_temp_anorm6[l];
          matrix3[2][i] = matrix3_trange_anorm6[l];
        }
        else if(offset_sss == 6){
          matrix3[0][i] = matrix3_prec_anorm7[l];
          matrix3[1][i] = matrix3_temp_anorm7[l];
          matrix3[2][i] = matrix3_trange_anorm7[l];
        }
        else if(offset_sss == 7){
          matrix3[0][i] = matrix3_prec_anorm8[l];
          matrix3[1][i] = matrix3_temp_anorm8[l];
          matrix3[2][i] = matrix3_trange_anorm8[l];
        }
        else if(offset_sss == 8){
          matrix3[0][i] = matrix3_prec_anorm9[l];
          matrix3[1][i] = matrix3_temp_anorm9[l];
          matrix3[2][i] = matrix3_trange_anorm9[l];
        }
        else if(offset_sss == 9){
          matrix3[0][i] = matrix3_prec_anorm10[l];
          matrix3[1][i] = matrix3_temp_anorm10[l];
          matrix3[2][i] = matrix3_trange_anorm10[l];
        }
        else{
          matrix3[0][i] = matrix3_prec_anorm1[l];
          matrix3[1][i] = matrix3_temp_anorm1[l];
          matrix3[2][i] = matrix3_trange_anorm1[l];
        }
      }
    }
/*
    for(i=0;i<npoi*12*anomyears;i++){
      years = i/(npoi*12)/scatter_years;
      if(years == 0){
      matrix3[0][i] = matrix3_prec_anorm1[i];
      matrix3[1][i] = matrix3_temp_anorm1[i];
      matrix3[2][i] = matrix3_trange_anorm1[i];
      }
      if(years == 1){
      }
      if(years == 2){
      }
      if(years == 3){
      }
      if(years == 4){
      }
    }
*/
    for(i=0;i<npoi*lccyears;i++){
      matrix5[0][i] = matrix5_lcc[i];
      matrix5[1][i] = matrix5_fire[i];
      matrix5[2][i] = matrix5_burnlf[i];
      matrix5[3][i] = matrix5_burnhf[i];
      matrix5[4][i] = matrix5_burnmf[i];
      matrix5[5][i] = matrix5_burnls[i];
      matrix5[6][i] = matrix5_burnhs[i];
      matrix5[7][i] = matrix5_burnms[i];
      matrix5[8][i] = matrix5_ndep[i];

      //avoid interger promotion issue on BG/Q Vesta
      if(matrix5[0][i] > 12) matrix5[0][i] = 0;
      if(matrix5[1][i] > 100) matrix5[1][i] = 0;
      if(matrix5[2][i] > 100) matrix5[2][i] = 0;
      if(matrix5[3][i] > 100) matrix5[3][i] = 0;
      if(matrix5[4][i] > 100) matrix5[4][i] = 0;
      if(matrix5[5][i] > 100) matrix5[5][i] = 0;
      if(matrix5[6][i] > 100) matrix5[6][i] = 0;
      if(matrix5[7][i] > 100) matrix5[7][i] = 0;
      if(matrix5[8][i] > 100) matrix5[8][i] = 0;
    }
  return;
}
//------------------------------------------------------------------------
void invertp0(char *output_name){
}

//------------------------------------------------------------------------
void invertp(){
}

//------------------------------------------------------------------------
void invert_npp(){
    int i, j, kk, array_length;
    //float ncfill  = -9999.0;
    float ncfill = 9.9692099683868690e+36;

    mapSsize = nlatsubs * nlonsubs;
    total_segment = mapSsize/npoi; //sampling by rowscale and colscale
    printf("mapSsize = %d\n", mapSsize);
    printf("total_segment = %d\n", total_segment);

    for(i=0;i<mapSsize*saveyears;i++){
      invert_aynpptot[i] = ncfill;
    }

    valid_segment_id = -1;
    for(segment_id=0; segment_id<total_segment; segment_id++){
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      valid_segment_id = valid_segment_id + 1;

      start_loc = segment_id*npoi;
      j = valid_segment_id*npoi*saveyears;

      for(i=0;i<npoi*saveyears;i++){
        layerx = i/npoi;
        remx = i%npoi;
        kk = start_loc + remx + layerx*mapSsize;

        invert_aynpptot[kk] = out_11[j];
        j = j + 1;
      }
    }
    printf("finished invert_npp\n");

    array_length = mapSsize * saveyears;

    writeDat(invert_aynpptot,"aynpptot.dat", array_length, 4);     
}

void writeDat(float *var4, char *targetfile, int array_length, int elementsize){
      FILE *fTargetFile;
      if((fTargetFile=fopen(targetfile,"wb")) == NULL){
        printf("Error opening target DAT file\n");
        return;
      }
      fwrite(var4, elementsize, array_length, fTargetFile);
      fclose(fTargetFile);
      //free(var4);

      //printf("          finished writeDat %s\n", targetfile);
}

int errmsg(const char *msg, int retval) {
    //fprintf(stderr, "%s\n", msg);
    printf("%s\n", msg);
    return retval;
}

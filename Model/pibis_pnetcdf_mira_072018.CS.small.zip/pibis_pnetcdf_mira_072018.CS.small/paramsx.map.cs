c Map parameteris for CONUS
c base map 960m
184            ! map1ncol 
234            ! map1nrow
960            ! map1res
204195         ! map1left
380835         ! map1right
938535         ! map1upper
713895         ! map1lower
c soil map, 960m
184            ! map2ncol 
234            ! map2nrow
960            ! map2res
204195         ! map1left
380835         ! map1right
938535         ! map1upper
713895         ! map1lower
c climate map 4000m
45             ! map3ncol
57             ! map3nrow
4000           ! map3res
201150         ! map3left
381150         ! map3right
940557         ! map3upper
712557         ! map3lower
c prism map 4000m
45             ! map4ncol
57             ! map4nrow
4000           ! map4res
201150         ! map3left
381150         ! map3right
940557         ! map3upper
712557         ! map3lower
c cgcm3 climate clip, 9656m
469            ! map5ncol
293            ! map5nrow
9956           ! map5res
-2362845       ! map5left
2327155        ! map5right
3180555        ! map5upper
250555         ! map5lower
c cgcm3 bigger climate map 
589            ! map4ncol
306            ! map4nrow
9956           ! map4res
-2920381       ! map4left
2943703        ! map4right
3250247        ! map4pper
203711         ! map4lower

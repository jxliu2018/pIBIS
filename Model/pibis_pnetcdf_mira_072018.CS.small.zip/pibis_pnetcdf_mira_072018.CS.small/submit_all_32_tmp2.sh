cd ../xibis22
submit_pibis.sh
cd ../xibis23
submit_pibis.sh
cd ../xibis24
submit_pibis.sh
cd ../xibis25
submit_pibis.sh
cd ../xibis26
submit_pibis.sh
cd ../xibis27
submit_pibis.sh
#cd ../xibis28
#submit_pibis.sh
cd ../xibis29
submit_pibis.sh
cd ../xibis30
submit_pibis.sh
cd ../xibis31
submit_pibis.sh
#cd ../xibis32
#submit_pibis.sh


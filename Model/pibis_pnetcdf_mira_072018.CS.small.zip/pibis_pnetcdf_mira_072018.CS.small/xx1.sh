cp -p p_list_avg_std_ayneetot_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_ayneetot_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_ayneetot_m.nc
#tar czf subset_ayneetot_m.nc.tar.gz subset_ayneetot_m.nc
echo "--"

cp -p p_list_avg_std_aynpptot_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_aynpptot_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_aynpptot_m.nc
#tar czf subset_aynpptot_m.nc.tar.gz subset_aynpptot_m.nc
echo "--"

cp -p p_list_avg_std_cgrain_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_cgrain_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_cgrain_m.nc
#tar czf subset_cgrain_m.nc.tar.gz subset_cgrain_m.nc
echo "--"

cp -p p_list_avg_std_ayCH4_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_ayCH4_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_ayCH4_m.nc
#tar czf subset_ayCH4_m.nc.tar.gz subset_ayCH4_m.nc
echo "--"

cp -p p_list_avg_std_cbiotot_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_cbiotot_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_cbiotot_m.nc
#tar czf subset_cbiotot_m.nc.tar.gz subset_cbiotot_m.nc
echo "--"

cp -p p_list_avg_std_totbiou_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_totbiou_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_totbiou_m.nc
#tar czf subset_totbiou_m.nc.tar.gz subset_totbiou_m.nc
echo "--"

cp -p p_list_avg_std_cdisturb_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_cdisturb_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_cdisturb_m.nc
#tar czf subset_cdisturb_m.nc.tar.gz subset_cdisturb_m.nc
echo "--"

cp -p p_list_avg_std_vegcomb_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_vegcomb_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_vegcomb_m.nc
#tar czf subset_vegcomb_m.nc.tar.gz subset_vegcomb_m.nc
echo "--"

cp -p p_list_avg_std_logging_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_logging_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_logging_m.nc
#tar czf subset_logging_m.nc.tar.gz subset_logging_m.nc
echo "--"

cp -p p_list_avg_std_totceco_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_totceco_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_totceco_m.nc
#tar czf subset_totceco_m.nc.tar.gz subset_totceco_m.nc
echo "--"

cp -p p_list_avg_std_totcsoi_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_totcsoi_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_totcsoi_m.nc
#tar czf subset_totcsoi_m.nc.tar.gz subset_totcsoi_m.nc
echo "--"

cp -p p_list_avg_std_stddown_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_stddown_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_stddown_m.nc
#tar czf subset_stddown_m.nc.tar.gz subset_stddown_m.nc
echo "--"

cp -p p_list_avg_std_totlit_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_totlit_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_totlit_m.nc
#tar czf subset_totlit_m.nc.tar.gz subset_totlit_m.nc
echo "--"

cp -p p_list_avg_std_vegtype0_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_vegtype0_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_vegtype0_m.nc
#tar czf subset_vegtype0_m.nc.tar.gz subset_vegtype0_m.nc
echo "--"

echo Finished!

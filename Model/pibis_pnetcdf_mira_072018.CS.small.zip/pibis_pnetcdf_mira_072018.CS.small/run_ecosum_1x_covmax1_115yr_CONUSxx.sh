#### convert netcdf_m.data to raw binery_m.data
#### do region summary
fipsum_ibis xcovmax_m.nc xcovmax ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis fu_m.nc fu ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis cbiotot_m.nc cbiotot ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis totbiou_m.nc totbiou ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis totcsoi_m.nc totcsoi ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis stddown_m.nc stddown ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis cgrain_m.nc cgrain ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis vegtype0_m.nc vegtype0 ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis aynpptot_m.nc aynpptot ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1 

fipsum_ibis totlit_m.nc totlit ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis ayneetot_m.nc ayneetot ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis aynbp_m.nc aynbp ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1 
fipsum_ibis ayCH4_m.nc ayCH4 ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1 
fipsum_ibis ayn2oflux_m.nc ayn2oflux ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1 
fipsum_ibis gdd5this_m.nc gdd5this ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis ayprcp_m.nc ayprcp ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis totceco_m.nc totceco ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis yrleach_m.nc yrleach ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1

fipsum_ibis xdist_m.nc xdist ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis logging_m.nc logging ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis soilcomb_m.nc soilcomb ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis vegcomb_m.nc vegcomb ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis strawc_m.nc strawc ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis deadcrem_m.nc deadcrem ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis livecrem_m.nc livecrem ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis cdisturb_m.nc cdisturb ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis totwdl_m.nc totwdl ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis stdwdc_m.nc stdwdc ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1

fipsum_ibis rawlitc_m.nc rawlitc ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis fallw_m.nc fallw ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis livc2std_m.nc livc2std ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis livc2down_m.nc livc2down ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis stdwcloss_m.nc stdwcloss ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis down2lit_m.nc down2lit ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis lit2co2_m.nc lit2co2 ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis lit2soc_m.nc lit2soc ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis soc2co2_m.nc soc2co2 ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1
fipsum_ibis raw2lit_m.nc raw2lit ecoreg.dat float 3052 4823 1 115 covmax.dat 1 1

sum_all_10000 p_list_sum_all_CONUSxx.asc
tar czf sum_covmax1.tar.gz sum_*.txt 


cd ../xibis1
cp -p ../pibis_pnetcdf/pibis_p000 .
pibis_p000

cd ../xibis2
cp -p ../pibis_pnetcdf/pibis_p000 .
pibis_p000

cd ../xibis4
cp -p ../pibis_pnetcdf/pibis_p000 .
pibis_p000

cd ../xibis5
cp -p ../pibis_pnetcdf/pibis_p000 .
pibis_p000

cd ../xibis6
cp -p ../pibis_pnetcdf/pibis_p000 .
pibis_p000

cd ../xibis7
cp -p ../pibis_pnetcdf/pibis_p000 .
pibis_p000

cd ../xibis8
cp -p ../pibis_pnetcdf/pibis_p000 .
pibis_p000

cd ../xibis9
cp -p ../pibis_pnetcdf/pibis_p000 .
pibis_p000

cd ../xibis10
cp -p ../pibis_pnetcdf/pibis_p000 .
pibis_p000

cd ../xibis11
cp -p ../pibis_pnetcdf/pibis_p000 .
pibis_p000

cd ../xibis12
cp -p ../pibis_pnetcdf/pibis_p000 .
pibis_p000

cd ../xibis13
cp -p ../pibis_pnetcdf/pibis_p000 .
pibis_p000

cd ../xibis14
cp -p ../pibis_pnetcdf/pibis_p000 .
pibis_p000

cd ../xibis15
cp -p ../pibis_pnetcdf/pibis_p000 .
pibis_p000

cd ../xibis16
cp -p ../pibis_pnetcdf/pibis_p000 .
pibis_p000


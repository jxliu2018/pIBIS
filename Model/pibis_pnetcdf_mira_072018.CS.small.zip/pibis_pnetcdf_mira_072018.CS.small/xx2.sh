tar czf subset_ayneetot_m.nc.tar.gz subset_ayneetot_m.nc
echo "--"

tar czf subset_aynpptot_m.nc.tar.gz subset_aynpptot_m.nc
echo "--"

tar czf subset_cgrain_m.nc.tar.gz subset_cgrain_m.nc
echo "--"

tar czf subset_ayCH4_m.nc.tar.gz subset_ayCH4_m.nc
echo "--"

tar czf subset_cbiotot_m.nc.tar.gz subset_cbiotot_m.nc
echo "--"

tar czf subset_totbiou_m.nc.tar.gz subset_totbiou_m.nc
echo "--"

tar czf subset_cdisturb_m.nc.tar.gz subset_cdisturb_m.nc
echo "--"

tar czf subset_vegcomb_m.nc.tar.gz subset_vegcomb_m.nc
echo "--"

tar czf subset_logging_m.nc.tar.gz subset_logging_m.nc
echo "--"

tar czf subset_totceco_m.nc.tar.gz subset_totceco_m.nc
echo "--"

tar czf subset_totcsoi_m.nc.tar.gz subset_totcsoi_m.nc
echo "--"

tar czf subset_stddown_m.nc.tar.gz subset_stddown_m.nc
echo "--"

tar czf subset_totlit_m.nc.tar.gz subset_totlit_m.nc
echo "--"

tar czf subset_vegtype0_m.nc.tar.gz subset_vegtype0_m.nc
echo "--"

echo Finished!

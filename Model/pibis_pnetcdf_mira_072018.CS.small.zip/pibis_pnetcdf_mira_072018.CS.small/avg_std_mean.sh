go aynbp_m.nc aynbp aynbp_m.dat
go ayneetot_m.nc ayneetot ayneetot_m.dat
go aynpptot_m.nc aynpptot aynpptot_m.dat
go cgrain_m.nc cgrain cgrain_m.dat
go cbiotot_m.nc cbiotot cbiotot_m.dat
go cdisturb_m.nc cdisturb cdisturb_m.dat
go logging_m.nc logging logging_m.dat
go vegcomb_m.nc vegcomb vegcomb_m.dat
go ayCH4_m.nc ayCH4 ayCH4_m.dat
go totceco_m.nc totceco totceco_m.dat
go totcsoi_m.nc totcsoi totcsoi_m.dat
go stddown_m.nc stddown stddown_m.dat
go totlit_m.nc totlit totlit_m.dat
go vegtype0_m.nc vegtype0 vegtype0_m.dat
echo "finished go --"

cp -p p_list_avg_std_aynbp_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_aynbp_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_aynbp_m.nc
tar czf subset_aynbp_m.nc.tar.gz subset_aynbp_m.nc
echo "--"

cp -p p_list_avg_std_ayneetot_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_ayneetot_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_ayneetot_m.nc
tar czf subset_ayneetot_m.nc.tar.gz subset_ayneetot_m.nc
echo "--"

cp -p p_list_avg_std_aynpptot_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_aynpptot_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_aynpptot_m.nc
tar czf subset_aynpptot_m.nc.tar.gz subset_aynpptot_m.nc
echo "--"

cp -p p_list_avg_std_cgrain_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_cgrain_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_cgrain_m.nc
tar czf subset_cgrain_m.nc.tar.gz subset_cgrain_m.nc
echo "--"

cp -p p_list_avg_std_ayCH4_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_ayCH4_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_ayCH4_m.nc
tar czf subset_ayCH4_m.nc.tar.gz subset_ayCH4_m.nc
echo "--"

cp -p p_list_avg_std_cbiotot_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_cbiotot_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_cbiotot_m.nc
tar czf subset_cbiotot_m.nc.tar.gz subset_cbiotot_m.nc
echo "--"

cp -p p_list_avg_std_cdisturb_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_cdisturb_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_cdisturb_m.nc
tar czf subset_cdisturb_m.nc.tar.gz subset_cdisturb_m.nc
echo "--"

cp -p p_list_avg_std_vegcomb_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_vegcomb_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_vegcomb_m.nc
tar czf subset_vegcomb_m.nc.tar.gz subset_vegcomb_m.nc
echo "--"

cp -p p_list_avg_std_logging_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_logging_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_logging_m.nc
tar czf subset_logging_m.nc.tar.gz subset_logging_m.nc
echo "--"

cp -p p_list_avg_std_totceco_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_totceco_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_totceco_m.nc
tar czf subset_totceco_m.nc.tar.gz subset_totceco_m.nc
echo "--"

cp -p p_list_avg_std_totcsoi_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_totcsoi_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_totcsoi_m.nc
tar czf subset_totcsoi_m.nc.tar.gz subset_totcsoi_m.nc
echo "--"

cp -p p_list_avg_std_stddown_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_stddown_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_stddown_m.nc
tar czf subset_stddown_m.nc.tar.gz subset_stddown_m.nc
echo "--"

cp -p p_list_avg_std_totlit_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_totlit_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_totlit_m.nc
tar czf subset_totlit_m.nc.tar.gz subset_totlit_m.nc
echo "--"

cp -p p_list_avg_std_vegtype0_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_vegtype0_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_vegtype0_m.nc
tar czf subset_vegtype0_m.nc.tar.gz subset_vegtype0_m.nc
echo "--"

echo Finished!

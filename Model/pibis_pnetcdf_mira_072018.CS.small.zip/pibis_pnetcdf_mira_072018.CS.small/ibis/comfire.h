c
c -------
c comfire
c -------
c
      real
     >  moe(npft),       ! PFT moisture of extinction parameters...
     >  combust(ndist,npft,npart),	!combustion factor 
     >  mortlity(ndist,npft,npart),	!mortality factor
     >  mortlev(4,4),	 !MTBS veg mortality factor 0-x1-x2-100, three classes
     >  comblev(6,4),	 !MTBS veg combustion level 0-x1-x2-100, three classes
     >  combsoil(5,4),	 !MTBS soil combustion level 0-x1-x2-100, three classes
c
     >  forharv(12,5),	 !forest harvest ratio by ecoregion and year
     >  defor(12,5),	 !deforestation ratio by ecoregion and year
c
     >  vegcomb(npoi),   !vegetation combustion amount kg/m2/yr
     >  deadcomb(npoi),  !standing and down deadwood combustion amount kg/m2/yr
     >  litcomb(npoi),   !soil litter combustion amount kg/m2/yr
     >  miccomb(npoi),   !soil imicrobe pool combustion amount kg/m2/yr
     >  sloncomb(npoi),  !soil slow non-protected pool combustion amount kg/m2/yr
     >  slopcomb(npoi),  !soil slow protected pool combustion amount kg/m2/yr
     >  pascomb(npoi),   !soil passive pool combustion amount kg/m2/yr
     >  soilcomb(npoi),  !total soil combustion amount kg/m2/yr
     >  soilncomb(npoi), !total soil nitrogen combustion amount kg/m2/yr
     >  firemort(npoi),  !mortality of trees in carbon kg/m2/yr
     >  charcoal(npoi),  !charcoal production from fire kg/m2/yr
     >  fireyear(npoi),  !number of years after fire event
     >  deleyyear(npoi), !number of years deleyed for regeneration after fire event
     >  stdwcloss(npoi), !standing dead wood C falling down rate to down dead wood
     >  stdwnloss(npoi), !standing dead wood N falling down rate to down dead wood
c
     >  lccmort(npoi),   !land cover change induced mortality carbon kg/m2/yr
     >  thining(npoi),   !thinging carbon removal kg/m2/yr
     >  logging(npoi),   !rotational logging carbon loss kg/m2/yr
     >  loggyear(npoi),  !number of years after stand-replacing log/harvest event
     >  deforsg(npoi),   !forest to shrub and grass carbon loss kg/m2/yr
     >  deforag(npoi),   !forest to agriculture carbon loss kg/m2/yr
     >  agexpan(npoi),   !agriculture expansion to grass/shrub carbon loss kg/m2/yr
     >  furban(npoi),    !forest to urban-barran carbon loss kg/m2/yr
     >  agurban(npoi),   !agriculture to urban-barran carbon loss kg/m2/yr
     >  sgurban(npoi),   !shrub-grass to urban-barran carbon loss kg/m2/yr
     >  deadcrem(npoi),  !standing and downdead wood, and raw litter C removal kg/m2/yr
     >  deadnrem(npoi),  !standing and downdead wood, and raw litter N removal kg/m2/yr
     >  livecrem(npoi),  !live C removal kg/m2/yr
     >  livenrem(npoi)   !live N removal kg/m2/yr
c
      integer
     >  bamboo1(npoi),   !bamboo map value at time x1
     >  bamboo2(npoi),   !bamboo map value at time x2
     >  bamboo(npoi)     !flag, bamboo true=1, false=0
c
      common /comfire/ moe, 
     >  combust, 
     >  mortlity,
     >  mortlev,
     >  comblev,
     >  combsoil,
     >  forharv,
     >  defor,
     >  vegcomb,
     >  deadcomb,
     >  litcomb,
     >  miccomb,
     >  sloncomb,
     >  slopcomb,
     >  pascomb,
     >  soilcomb,
     >  soilncomb,
     >  firemort,
     >  charcoal,
     >  fireyear,
     >  deleyyear,
     >  stdwcloss,
     >  stdwnloss,
     >  lccmort,
     >  thining,
     >  logging,
     >  loggyear,
     >  deforsg,
     >  deforag,
     >  agexpan,
     >  furban,
     >  agurban,
     >  sgurban,
     >  deadcrem,
     >  deadnrem,
     >  livecrem,
     >  livenrem,
     >  bamboo1,
     >  bamboo2,
     >  bamboo

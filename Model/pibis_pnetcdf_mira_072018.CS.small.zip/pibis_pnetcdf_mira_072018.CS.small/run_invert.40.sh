#!/bin/bash
sleep_time1=1s
block=1
while [ $block -le 32 ]; do
  echo
  echo current block: ibis$block

  cd /gpfs/mira-fs1/projects/MiraBootCamp2015/jxliu/pibis_pnetcdf/
  cp -p ./invert.40.sh ../xibis$block/invert.sh
  cp -p ./pIO_invert ../xibis$block/pIO_invert
  cd ../xibis$block
  invert.sh > /dev/null &
  let block=block+1
  echo
  sleep $sleep_time1
done
exit



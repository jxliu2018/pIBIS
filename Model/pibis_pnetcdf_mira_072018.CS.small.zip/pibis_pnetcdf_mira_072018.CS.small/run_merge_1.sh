sub_region_N_blocks_merge_alcf p_list_merge1.asc fips.nc fips fips_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc ecoreg.nc ecoreg ecoreg_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc xcovmax.nc xcovmax xcovmax_m.nc

sub_region_N_blocks_merge_alcf p_list_merge1.asc cbiotot.nc cbiotot cbiotot_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc totbiou.nc totbiou totbiou_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc rawlitc.nc rawlitc rawlitc_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc totlit.nc totlit totlit_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc stdwdc.nc stdwdc stdwdc_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc deadwdc.nc deadwdc deadwdc_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc totcsoi.nc totcsoi totcsoi_m.nc

sub_region_N_blocks_merge_alcf p_list_merge1.asc aynpptot.nc aynpptot aynpptot_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc ayneetot.nc ayneetot ayneetot_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc aynbp.nc aynbp aynbp_m.nc

sub_region_N_blocks_merge_alcf p_list_merge1.asc fallw.nc fallw fallw_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc livc2std.nc livc2std livc2std_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc livc2down.nc livc2down livc2down_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc stdwcloss.nc stdwcloss stdwcloss_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc down2lit.nc down2lit down2lit_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc lit2co2.nc lit2co2 lit2co2_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc lit2soc.nc lit2soc lit2soc_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc soc2co2.nc soc2co2 soc2co2_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc yrleach.nc yrleach yrleach_m.nc

sub_region_N_blocks_merge_alcf p_list_merge1.asc cdisturb.nc cdisturb cdisturb_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc logging.nc logging logging_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc soilcomb.nc soilcomb soilcomb_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc vegcomb.nc vegcomb vegcomb_m.nc

sub_region_N_blocks_merge_alcf p_list_merge1.asc cgrain.nc cgrain cgrain_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc strawc.nc strawc strawc_m.nc

sub_region_N_blocks_merge_alcf p_list_merge1.asc fu.nc fu fu_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc vegtype0.nc vegtype0 vegtype0_m.nc

sub_region_N_blocks_merge_alcf p_list_merge1.asc cfruit.nc cfruit cfruit_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc totwdl.nc totwdl totwdl_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc CH4.nc CH4 CH4_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc gdd5.nc gdd5 gdd5_m.nc
sub_region_N_blocks_merge_alcf p_list_merge1.asc tcmin.nc tcmin tcmin_m.nc


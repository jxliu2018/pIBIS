#!/bin/bash
sleep_time1=1s
block=22
while [ $block -le 32 ]; do
  echo
  echo current block: ibis$block

  cd /gpfs/mira-fs1/projects/MiraBootCamp2015/jxliu/pibis_pnetcdf/
  cd ../xibis$block
  rm outfile?
  rm outfile??
  let block=block+1
  echo
  sleep $sleep_time1
done
exit



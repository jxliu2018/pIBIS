0         ! irestart   0: not a restart run  1: restart run
1901      ! iyear0     initial year of simulation (don't change for restart)
115       ! nrun       number of years in this simulation (change for restart)
1971      ! iyranom    year to start reading anomalies (don't chng for restart)
45        ! nanom      number of years in the anomaly files (ditto)
9999      ! iyrdaily   year to start reading daily data (ditto)
0         ! soilcspin  0: no soil spinup, 1: acceleration procedure used
1         ! iyearout   0: no yearly output, 1: yearly output
0         ! imonthout  0: no monthly output, 1: monthly output
0         ! idailyout  0: no daily output, 1: daily output
1         ! isimveg    0: static veg, 1: dynamic veg, 2: dynamic veg-cold start
1984      ! isimfire   0: fixed fire, N: dynam fire starting year
0         ! isimlcc    0: lcc maps (xdist)  1: lct that needs interpolation
1         ! isimco2    0: fixed co2,  1: ramped co2
0.000308  ! co2init    initial co2 concentration in mol/mol (real)
0.209000  ! o2init     initial o2 concentration in mol/mol (real)
3600.0    ! dtime      time step in seconds
1970      ! idiag      0: no biomass reset, 1970- reset biomass
0         ! cluster    if use JFD or polygon mask in simulation
2100 !1971      ! events     start year of LULCC events e.g. 1973; 0 = no LULCC
61        ! snorth     northern latitude for subsetting in/ouput
100       ! ssouth     southern latitude for subsetting in/ouput
61        ! swest      western longitude for subsetting in/ouput
100       ! seast      eastern longitude for subsetting in/ouput
4         ! row sampling interval (rowscale)
4         ! column sampling interval (colscale)







~~~~~~~~~~~~
1861-1880;3536-3555;10-10; compare Blue Ridge two fips, 47139,13111
741-760;4251-4270;10-10;   CO2sp missing data test
1185-1204;3993-4012;10-10; unknown hole at later simulateion stage
2301-2320;3811-3830;10-10; Florida big variation and blue hole
1431-1450;266-285;10-10; CA woody crop
991-1140;21-120;30-30;county 6045 with NPP calib issue
1351-1380;421-450;CA grassland, check why grass NPP is so low
407-410;2267-2276;ND Prairie Pothole wetland, 48%
2336-2345;3767-3776;Florida inland wetland, 48%
1551-1560;4251-4260;Great Dismal Swamp wetland, 100%
1241-1250;141-150;Bay area wetland, 49%
2566-2575;2951-2960;Louisiana Delta wetlands
2551-2560;2881-2890;Louisiana Delta wetlands

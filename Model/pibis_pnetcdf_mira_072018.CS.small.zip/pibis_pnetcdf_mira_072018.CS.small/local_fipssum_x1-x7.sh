cp -p ../CS_tmp/xxibis1-1/*.nc .
sleep 5s
local_fipssum_all_CS.sh.115
sleep 5s
mv sum_*_CS.tar.gz ../CS_tmp/fipssum-1/
rm1.sh

cp -p ../CS_tmp/xxibis1-2/*.nc .
sleep 5s
local_fipssum_all_CS.sh.115
sleep 5s
mv sum_*_CS.tar.gz ../CS_tmp/fipssum-2/
rm1.sh

cp -p ../CS_tmp/xxibis1-3/*.nc .
sleep 5s
local_fipssum_all_CS.sh.115
sleep 5s
mv sum_*_CS.tar.gz ../CS_tmp/fipssum-3/
rm1.sh

cp -p ../CS_tmp/xxibis1-4/*.nc .
sleep 5s
local_fipssum_all_CS.sh.115
sleep 5s
mv sum_*_CS.tar.gz ../CS_tmp/fipssum-4/
rm1.sh

cp -p ../CS_tmp/xxibis1-5/*.nc .
sleep 5s
local_fipssum_all_CS.sh.115
sleep 5s
mv sum_*_CS.tar.gz ../CS_tmp/fipssum-5/
rm1.sh

cp -p ../CS_tmp/xxibis1-6/*.nc .
sleep 5s
local_fipssum_all_CS.sh.115
sleep 5s
mv sum_*_CS.tar.gz ../CS_tmp/fipssum-6/
rm1.sh

cp -p ../CS_tmp/xxibis1-7/*.nc .
sleep 5s
local_fipssum_all_CS.sh.115
sleep 5s
mv sum_*_CS.tar.gz ../CS_tmp/fipssum-7/
rm1.sh





cd ../xibis1
submit_pibis.sh
cd ../xibis2
submit_pibis.sh
cd ../xibis3
submit_pibis.sh
cd ../xibis4
submit_pibis.sh
cd ../xibis5
submit_pibis.sh
cd ../xibis6
submit_pibis.sh
cd ../xibis7
submit_pibis.sh
cd ../xibis8
submit_pibis.sh
cd ../xibis9
submit_pibis.sh
#cd ../xibis10
#submit_pibis.sh
cd ../xibis11
submit_pibis.sh
cd ../xibis12
submit_pibis.sh
cd ../xibis13
submit_pibis.sh
cd ../xibis14
submit_pibis.sh
cd ../xibis15
submit_pibis.sh
cd ../xibis16
submit_pibis.sh
cd ../xibis17
submit_pibis.sh
cd ../xibis18
submit_pibis.sh
cd ../xibis19
submit_pibis.sh
cd ../xibis20
submit_pibis.sh
cd ../xibis21
submit_pibis.sh


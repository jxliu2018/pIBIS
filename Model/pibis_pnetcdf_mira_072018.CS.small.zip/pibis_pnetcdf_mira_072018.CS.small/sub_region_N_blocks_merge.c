//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h> 

#include "netcdf.h"
#define arr_size1 20
#define arr_size2 200
#define max_len 500

#pragma hdrstop

//---------------------------------------------------------------------------

#pragma argsused
char * ncfilename;
int nc_id;
int ndims;
int nvars;
int ngatts;
int unlimdimid;

char dim_name[arr_size1][arr_size2],var_dim_name[arr_size1][arr_size2];
int dim_ids[arr_size1];
size_t dim_lens[arr_size1];

char var_names[arr_size1][arr_size2];
int var_ids[arr_size1], var_id;
int var_ndims[arr_size1];
int var_dimids[arr_size1][arr_size1];
int var_natts[arr_size1];
nc_type var_type[arr_size1], nctype;

char att_txt[arr_size1][arr_size1][arr_size2];
char att_names[arr_size1][arr_size1][arr_size2];
nc_type att_type[arr_size1][arr_size1];
size_t  att_len;
double att_val[arr_size1][arr_size1];
int *dim1,*dim2,*dim3,*dim4;

int ncvar_dimids[4];
size_t ncvar_dimlen[4];
int timeid, latid, lonid, levid, pftid;
size_t timelen, latlen, lonlen,levlen,pftlen;

char path[arr_size2], sourcefile[arr_size2], targetfile[arr_size2], variablename[arr_size2], variablenamet[arr_size2];

void GetVarInfo(char *ncfilename, char *variablename);
void CreateNCFile(char *ncfilename, char names[][arr_size2], size_t *start, size_t *count, int *dim_data[]);
void CreateNCVar(char *ncfilename, char *ncvarname, nc_type nctype, int ndims, char ncvar_dimnames[][arr_size2]);
void NCRW(char *ncsource, char *nctarget, char *varname, size_t *start, size_t *count, size_t *startsub, size_t *countsub);
void WriteNCVara(char *ncfilename, char *ncvarname, nc_type nctype, size_t *start, size_t *count, void *tp);

int main(int argc, char* argv[])
{
  FILE *fpx;
  char msg[max_len], S[50], p_list[max_len]; //use x[], not *x

  FILE *fp1, *fp2;
  int *dim_data[4];
  size_t start[4];
  size_t count[4];
  size_t startsub[4];
  size_t countsub[4];
  int start_row0, start_col0, end_row0, end_col0, interval;
  int i, j, k, l;
  int nsubs, timeall, timep, startp, latlenall;
  char buffer[arr_size2], buffer1[arr_size2];
  char sort_list[arr_size2];
  int sub_id, sub_id_old, sub_npoi, sub_start_row, sub_end_row, sub_start_col, sub_end_col;

  if(argc < 2){
    printf("\nThis program combines sub-region NC files.\n");
    printf("Source code: sub_region_N_blocks_merge.c\n");
    printf("Build: gcc -g sub_region_N_blocks_merge.c -o sub_region_N_blocks_merge libnetcdf.a\n");
    printf("Usage: sub_region_N_blocks_merge p_list_merge.txt aynpptot.nc aynpptot aynpptot_m.nc\n\n");
    return 0;
  }

  strcpy(sourcefile, argv[2]);
  strcpy(variablename, argv[3]);
  strcpy(targetfile, argv[4]);
  strcpy(variablenamet, argv[3]);

  strcpy(p_list, argv[1]);
  if ((fpx = fopen(p_list, "rt")) == NULL){
    printf("Input paramater file p_list not opened .......\n");
    return;
  }
  fscanf(fpx,"%s",S);   //e.g /home/jxliu/
  fgets(msg,max_len,fpx);
  strcpy(path, S);

  fscanf(fpx,"%s",S);   //e.g time - output dim name
  fgets(msg,max_len,fpx);
  strcpy(dim_name[0], S);

  fscanf(fpx,"%s",S);   //e.g pft - output dim name
  fgets(msg,max_len,fpx);
  strcpy(dim_name[1], S);

  fscanf(fpx,"%s",S);   //e.g latitude - output dim name
  fgets(msg,max_len,fpx);
  strcpy(dim_name[2], S);

  fscanf(fpx,"%s",S);   //e.g longitude - output dim name
  fgets(msg,max_len,fpx);
  strcpy(dim_name[3], S);

  fscanf(fpx,"%s",S);   //number of sub-regions to combine
  fgets(msg,max_len,fpx);
  nsubs = atoi(S);

  fscanf(fpx,"%s",S);   //length of time period to combine
  fgets(msg,max_len,fpx);
  timep = atoi(S);

  fscanf(fpx,"%s",S);   //start of time period
  fgets(msg,max_len,fpx);
  startp = atoi(S);

  fscanf(fpx,"%s",S);   //original total time period length
  fgets(msg,max_len,fpx);
  timeall = atoi(S);

  fscanf(fpx,"%s",S);   //start row on whole map
  fgets(msg,max_len,fpx);
  start_row0 = atoi(S);

  fscanf(fpx,"%s",S);   //end row on whole map
  fgets(msg,max_len,fpx);
  end_row0 = atoi(S);

  fscanf(fpx,"%s",S);   //start column on whole map
  fgets(msg,max_len,fpx);
  start_col0 = atoi(S);

  fscanf(fpx,"%s",S);   //end column on whole map
  fgets(msg,max_len,fpx);
  end_col0 = atoi(S);

  fscanf(fpx,"%s",S);   //sampling interval
  fgets(msg,max_len,fpx);
  interval = atoi(S);

  fscanf(fpx,"%s",S);   //sort_list file
  fgets(msg,max_len,fpx);
  strcpy(sort_list, S);

  if ((fp1 = fopen(sort_list, "rt")) == NULL){
    printf("Input file sub_region_list_sorted.txt not opened.\n");
    return;
  }

    start[0] = 0;
    start[1] = 0;
    start[2] = 0;
    start[3] = 0;
    count[0] = timeall;
    count[1] = 1;
    count[2] = (end_row0 - start_row0) / interval + 1;
    count[3] = (end_col0 - start_col0) / interval + 1;

    if(timep<count[0]){
      count[0] = timep;
    }
    if(startp>0){
      start[0] = startp;
    }

    dim1 = NULL;
    dim2 = NULL;
    dim3 = NULL;
    dim4 = NULL;
    dim1 = (int *)malloc(sizeof(int) * count[0]);
    dim2 = (int *)malloc(sizeof(int) * count[1]);
    dim3 = (int *)malloc(sizeof(int) * count[2]);
    dim4 = (int *)malloc(sizeof(int) * count[3]);

    dim4[0]= 1;
    for(i=1;i<count[3];i++){
      dim4[i]=dim4[i-1]+1;
    }
    dim3[0]= count[2];
    for(i=1;i<count[2];i++){
      dim3[i]=dim3[i-1]-1;
    }
    dim2[0]= 1;
    for(i=1;i<count[1];i++){
      dim2[i]=dim2[i-1]+1;
    }
    dim1[0]= 1;
    for(i=1;i<count[0];i++){
      dim1[i]=dim1[i-1]+1;
    }

    dim_data[0] = dim1;
    dim_data[1] = dim2;
    dim_data[2] = dim3;
    dim_data[3] = dim4;
    latlenall = 0;

    fgets(msg,max_len,fp1); //skip sort_list file title line
    for(l=0;l<nsubs;l++){
      fscanf(fp1,"%s",S);   
      sub_id = atoi(S);    //e.g. 10 (ibis10)
      fscanf(fp1,"%s",S);   
      sub_id_old = atoi(S);//e.g. 13 (old ibis id before sort, no use) 
      fscanf(fp1,"%s",S);   
      sub_npoi = atoi(S);  //e.g. 10 (10 point in ibis10)
      fscanf(fp1,"%s",S);   
      sub_start_row = atoi(S); //e.g. 791, start row in whole map
      fscanf(fp1,"%s",S);   
      sub_end_row = atoi(S);   //e.g. 805, end row in whole map
      fscanf(fp1,"%s",S);   
      sub_start_col = atoi(S); //e.g. 1256, start row in whole map
      fscanf(fp1,"%s",S);   
      sub_end_col = atoi(S);   //e.g. 1305, end row in whole map
      fgets(msg,max_len,fp1);

      strcpy(buffer, path);
      sprintf(buffer1, "ibis%d/output/yearly/", l+1);
      strcat(buffer1, sourcefile);
      strcat(buffer, buffer1);
      GetVarInfo(buffer, variablename);
      if(l==0){
        CreateNCFile(targetfile, dim_name, start, count, dim_data);
        CreateNCVar(targetfile, variablenamet, var_type[var_id], var_ndims[var_id], var_dim_name);
      }
      if(var_ndims[var_id] == 3){  
        startsub[0] = 0;
        startsub[1] = 0;
        startsub[2] = 0;
        countsub[0] = ncvar_dimlen[0];
        countsub[1] = ncvar_dimlen[1];
        countsub[2] = ncvar_dimlen[2];

        startsub[0] = startp;
        countsub[0] = timep;

        start[1] = (sub_start_row - start_row0)/interval;//new start row in local map
        start[2] = (sub_start_col - start_col0)/interval;//new start row in local map
        count[0] = countsub[0];
        count[1] = countsub[1];
        count[2] = countsub[2];
      }
      else if(var_ndims[var_id] == 4){
        startsub[0] = 0;
        startsub[1] = 0;
        startsub[2] = 0;
        startsub[3] = 0;
        countsub[0] = ncvar_dimlen[0];
        countsub[1] = ncvar_dimlen[1];
        countsub[2] = ncvar_dimlen[2];
        countsub[3] = ncvar_dimlen[3];

        startsub[0] = startp;
        countsub[0] = timep;

        start[2] = (sub_start_row - start_row0)/interval + 1;//new start row in local map
        start[3] = (sub_start_col - start_col0)/interval + 1;//new start col in local map
        count[0] = countsub[0];
        count[1] = countsub[1];
        count[2] = countsub[2];
        count[3] = countsub[3];
      }
      else{
        printf("variable is not 3d or 4d data, stop \n");
        return 0;
      }
      
      NCRW(buffer, targetfile, variablename, start, count, startsub, countsub);
      printf("finished one NC combination! %s - %d \n", targetfile, l+1);
    }

    return 0;
}
//---------------------------------------------------------------------------

void GetVarInfo(char *ncfilename, char *variablename)
{
  int i, j;
  // open NC file for reading NC infomation
  if(nc_open(ncfilename,NC_NOWRITE,&nc_id) != NC_NOERR) {
    printf("Error opening source NETCDF file -- GetVarInfo\n");
    return;
  }
  // get general NC info
  nc_inq(nc_id, &ndims, &nvars, &ngatts, &unlimdimid);
  //nc_inq_dimid(nc_id, "time", &timeid);
  nc_inq_dimid(nc_id, "latitude", &latid);
  //nc_inq_dimid(nc_id, "longitude", &lonid);
  //nc_inq_dimid(nc_id, "pft", &pftid);
  //nc_inq_dimid(nc_id, "level", &levid);

  //nc_inq_dimlen(nc_id, timeid, &timelen);
  nc_inq_dimlen(nc_id, latid, &latlen);
  //nc_inq_dimlen(nc_id, lonid, &lonlen);
  //nc_inq_dimlen(nc_id, pftid, &pftlen);
  //nc_inq_dimlen(nc_id, levid, &levlen);

  nc_inq_varid(nc_id, variablename, &var_id);
  nc_inq_vartype(nc_id, var_id, &var_type[var_id]);
  nc_inq_var(nc_id, var_id, var_names[var_id], &var_type[var_id], &var_ndims[var_id], var_dimids[var_id], &var_natts[var_id]);

  for(j=0;j<var_ndims[var_id];j++){
    nc_inq_dimname(nc_id, var_dimids[var_id][j], var_dim_name[j]);
    nc_inq_dimlen(nc_id, var_dimids[var_id][j], &ncvar_dimlen[j]);
  }

  for(i = 0; i < nvars; i++) {
    for(j = 0; j < var_natts[i]; j++) {
      nc_inq_attname(nc_id, i, j, att_names[i][j]);
      nc_inq_atttype(nc_id, i, att_names[i][j], &att_type[i][j]);
      nc_inq_attlen (nc_id, i, att_names[i][j], &att_len);
      if(att_type[i][j] == 2){
        strcpy(att_txt[i][j],"");
        nc_get_att_text(nc_id, i, att_names[i][j], att_txt[i][j]);
        att_txt[i][j][att_len] = '\0';
      }
      else if(att_type[i][j] == 3){
        nc_get_att_double(nc_id, i, att_names[i][j], &att_val[i][j]);
      }
      else if(att_type[i][j] == 4){
        nc_get_att_double(nc_id, i, att_names[i][j], &att_val[i][j]);
      }
      else if(att_type[i][j] == 5){
        nc_get_att_double(nc_id, i, att_names[i][j], &att_val[i][j]);
      }
      else if(att_type[i][j] == 6){
        nc_get_att_double(nc_id, i, att_names[i][j], &att_val[i][j]);
      }
    }
  }

  nc_close(nc_id);
}
//---------------------------------------------------------------------------

void CreateNCFile(char *ncfilename, char names[][arr_size2], size_t *start, size_t *count, int *dim_data[])
{
  int tmp_nc_id;
  int time_dimid, level_dimid, lat_dimid, lon_dimid, jfd_dimid;
  int time_id, level_id, lat_id, lon_id, jfd_id;
  int ndim = 0, ndim_id[5];
  int dim_id[4];
  int status, tmp_dim_id;
  int i;
  char buffer[arr_size2];
  for(i=0; i<4; i++){
    if(names[i] != "") ndim++;
  }
  strcpy(buffer, "rm ");
  strcat(buffer, ncfilename);
  system(buffer);

    nc_create(ncfilename,NC_CLOBBER,&tmp_nc_id);
    for(i=0; i<ndim; i++){
      nc_def_dim(tmp_nc_id, names[i], count[i], &ndim_id[i]);
      nc_def_var(tmp_nc_id, names[i], NC_INT, 1, &ndim_id[i], &dim_id[i]);
    }
    nc_enddef(tmp_nc_id);

    for(i=0; i<ndim; i++){
      nc_put_var_int(tmp_nc_id,dim_id[i],dim_data[i]);
    }

  nc_close(tmp_nc_id);
}
//---------------------------------------------------------------------------

void CreateNCVar(char *ncfilename, char *ncvarname, nc_type nctype,
                         int ndims, char ncvar_dimnames[][arr_size2])
{
  int tmp_nc_id;
  int tmp_var_id;
  int i,j;
  int str_length;

  nc_open(ncfilename,NC_WRITE,&tmp_nc_id);
  for(i=0; i<ndims; i++){
    int status = nc_inq_dimid(tmp_nc_id, ncvar_dimnames[i], &ncvar_dimids[i]);
  }
  nc_redef(tmp_nc_id);
  nc_def_var(tmp_nc_id, ncvarname, nctype, ndims, ncvar_dimids, &tmp_var_id);

  for(j=0;j<var_natts[var_id];j++){
    if(att_type[var_id][j] == NC_CHAR){
      str_length = strlen(att_txt[var_id][j]);
      nc_put_att_text(tmp_nc_id, tmp_var_id, att_names[var_id][j], str_length, att_txt[var_id][j]);
    }
    else{
      nc_put_att_double(tmp_nc_id, tmp_var_id, att_names[var_id][j], NC_DOUBLE, 1, &att_val[var_id][j]);
    }
  }
  
  double att_val_tmp;
  att_val_tmp = 1.0;
  nc_put_att_double(tmp_nc_id, tmp_var_id, "scale_factor", NC_DOUBLE, 1, &att_val_tmp);
  att_val_tmp = 0.0;
  nc_put_att_double(tmp_nc_id, tmp_var_id, "add_offset", NC_DOUBLE, 1, &att_val_tmp);

  nc_enddef(tmp_nc_id);
  nc_close(tmp_nc_id);
}
//---------------------------------------------------------------------------

void NCRW(char *ncsource, char *nctarget, char *varname, size_t *start, size_t *count, size_t *startsub, size_t *countsub)
{
  int nc_id, var_id, dim;
  nc_type var_type;
  unsigned int array_length;
  int elementsize;
  int i;

  // open NC file and get variable info
  if(nc_open(ncsource,NC_NOWRITE,&nc_id) != NC_NOERR) {
    printf("Error opening source NETCDF file -- NCRW\n");
    return;
  }
  nc_inq_varid (nc_id, varname, &var_id);
  nc_inq_vartype(nc_id, var_id, &var_type);
  nc_inq_varndims (nc_id, var_id, &dim);
  array_length = 1;
  for(i=0; i<dim; i++){
    array_length = array_length * countsub[i];
  }

  //Read NC sub-set array and Write NC
  {
    if(var_type == NC_BYTE) {//byte data type is signed-char or unsigned-char
      elementsize = sizeof(unsigned char);
      unsigned char *yArray = (unsigned char *) malloc(array_length * elementsize);
      nc_get_vara_uchar(nc_id, var_id, startsub, countsub, yArray);
      WriteNCVara(nctarget, variablenamet, var_type, start, count, yArray);
      free(yArray);
    }
    if(var_type == NC_CHAR) {
      elementsize = sizeof(signed char);
      signed char *yArray = (signed char *) malloc(array_length * elementsize);
      nc_get_vara_schar(nc_id, var_id, startsub, countsub, yArray);
      WriteNCVara(nctarget, variablenamet, var_type, start, count, yArray);
      free(yArray);
    }
    if(var_type == NC_SHORT) {
      elementsize = sizeof(short);
      short *yArray = (short *) malloc(array_length * elementsize);
      nc_get_vara_short(nc_id, var_id, startsub, countsub, yArray);
      WriteNCVara(nctarget, variablenamet, var_type, start, count, yArray);
      free(yArray);
    }
    if(var_type == NC_INT) {
      elementsize = sizeof(int);
      int *yArray = (int *) malloc(array_length * elementsize);
      nc_get_vara_int(nc_id, var_id, startsub, countsub, yArray);
      WriteNCVara(nctarget, variablenamet, var_type, start, count, yArray);
      free(yArray);
    }
    if(var_type== NC_FLOAT) {
      elementsize = sizeof(float);
      float *yArray = (float *) malloc(array_length * elementsize);
      nc_get_vara_float(nc_id, var_id, startsub, countsub, yArray);
      WriteNCVara(nctarget, variablenamet, var_type, start, count, yArray);
      free(yArray);
    }
    if(var_type== NC_DOUBLE) {
      elementsize = sizeof(double);
      double *yArray = (double *) malloc(array_length * elementsize);
      nc_get_vara_double(nc_id, var_id, startsub, countsub, yArray);
      WriteNCVara(nctarget, variablenamet, var_type, start, count, yArray);
      free(yArray);
    }
  }
  nc_close(nc_id);
}
//---------------------------------------------------------------------------

void WriteNCVara(char *ncfilename, char *ncvarname, nc_type nctype, size_t *start, size_t *count, void *tp)
{
  int tmp_nc_id, tmp_var_id;
  nc_type xtype;

  nc_open(ncfilename,NC_NOWRITE,&tmp_nc_id);
  nc_inq_varid(tmp_nc_id, ncvarname, &tmp_var_id);
  nc_inq_vartype(tmp_nc_id, tmp_var_id, &xtype);
  nc_close(tmp_nc_id);

  nc_open(ncfilename,NC_WRITE,&tmp_nc_id);

  if(xtype == NC_BYTE && nctype == 1){
    unsigned char * tpp = (unsigned char *) tp;
    nc_put_vara_uchar(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_BYTE && nctype == 2){ //add this for animating signed char data
    const signed char * tpp = (const signed char *) tp;
    nc_put_vara_schar(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_CHAR){//this char data can not be animated with its 'char nc type'
    const signed char * tpp = (const signed char *) tp;
    nc_put_vara_schar(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_SHORT){
    short * tpp = (short *) tp;
    nc_put_vara_short(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_INT){
    int * tpp = (int *) tp;
    nc_put_vara_int(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_FLOAT){
    float * tpp = (float *) tp;
    nc_put_vara_float(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_DOUBLE){
    double * tpp = (double *) tp;
    nc_put_vara_double(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else{
    printf("Wrong data type (not a nc_type 1~6)");
  }
  nc_close(tmp_nc_id);
}

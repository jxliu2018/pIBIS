
cp -p p_list_avg_std_totbiou_m.asc p_list_avg_std.asc
avg_std_111117 p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_totbiou_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_totbiou_m.nc
tar czf subset_totbiou_m.nc.tar.gz subset_totbiou_m.nc
echo "--"


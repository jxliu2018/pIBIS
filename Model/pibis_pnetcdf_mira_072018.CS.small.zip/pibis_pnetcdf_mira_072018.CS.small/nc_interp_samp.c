/*
                _       _                                                    
 _ __   ___    (_)_ __ | |_ ___ _ __ _ __     ___  __ _ _ __ ___  _ __   ___ 
| '_ \ / __|   | | '_ \| __/ _ \ '__| '_ \   / __|/ _` | '_ ` _ \| '_ \ / __|
| | | | (__    | | | | | ||  __/ |  | |_) |  \__ \ (_| | | | | | | |_) | (__ 
|_| |_|\___|___|_|_| |_|\__\___|_|  | .__/___|___/\__,_|_| |_| |_| .__(_)___|
          |_____|                   |_| |_____|                  |_|         

*/
//nc_interp_samp.c
//Jinxun Liu, updated 1/23/2015
//jxliu@usgs.gov

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "netcdf.h"
#include "nc_interp_samp.h"

void interp_samp_float(float *, float *, float *, int, int);
void interp_samp_int(int *, float *, float *, int, int);
void interp_samp_char(char *, float *, float *, int, int);
void writeDat(float *, char *, int, int);
void ncwrite();

//called from io-netcdf.c
void GetNCInfo(char *ncfilename);
void CreateNCFile(char *ncfilename, char names[][100], size_t *start, size_t *count, int *dim_data[]);
void CreateNCVar(char *ncfilename, char *ncvarname, nc_type nctype, int ndims, char ncvar_dimnames[][100]);
void WriteNCVara(char *ncfilename, char *ncvarname, nc_type nctype, size_t *start, size_t *count, void *tp);
void ReadNCVara(char *ncfilename, char *ncvarname, nc_type nctype, size_t *start, size_t *count, void *tp);
void SetNCAttribute(char *ncfilename, char *ncvarname, char *attname, nc_type nctype, char *att, float floatval);


int main(int argc, char* argv[])
{
  FILE *fpx;
  char msg[200], S[50], file_list[200]; //use x[], not *x

  FILE *fp1, *fp2;

  int i, j, k;
  int map_group, nc_type;

  if(argc < 4){
    printf("  This program extract a subset of netcdf data and do sampling by interval\n");
    printf("  Usage: a.out nc_infile nc_variable p_list_nc_interp_samp.asc\n");
    printf("  Outputs: ncfile_x.nc and ncfile_x.dat\n");
    printf("  e.g: nc_interp_samp hist_prec_norm_out_4km.nc prec p_list_nc_interp_samp.asc.ca\n");
    printf("  Outputs: hist_prec_norm_out_4km.nc_x.dat, hist_prec_norm_out_4km.nc_x.nc\n");
    return 0;
  }

  strcpy(nc_infile, argv[1]);
  strcpy(nc_outfile, nc_infile);
  strcat(nc_outfile,"_x.nc");
  strcpy(dat_outfile, nc_infile);
  strcat(dat_outfile,"_x.dat");
  strcpy(nc_variable, argv[2]);

  strcpy(file_list, argv[3]);
  if ((fpx = fopen(file_list, "rt")) == NULL){
    printf("Input p_list file not openned ......\n");
    return;
  }

  fscanf(fpx,"%d", &layers);    fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &nc_type);   fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map_group); fgets(msg, 200, fpx);

  fscanf(fpx,"%d", &snorth);    fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &ssouth);    fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &swest);     fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &seast);     fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &rowscale);  fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &colscale);  fgets(msg, 200, fpx);  

  fscanf(fpx,"%d", &map1ncol);  fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map1nrow);  fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map1res);   fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map1left);  fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map1right); fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map1upper); fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map1lower); fgets(msg, 200, fpx);

  fscanf(fpx,"%d", &map2ncol);  fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map2nrow);  fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map2res);   fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map2left);  fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map2right); fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map2upper); fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map2lower); fgets(msg, 200, fpx);

  fscanf(fpx,"%d", &map3ncol);  fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map3nrow);  fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map3res);   fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map3left);  fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map3right); fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map3upper); fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map3lower); fgets(msg, 200, fpx);

  fscanf(fpx,"%d", &map4ncol);  fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map4nrow);  fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map4res);   fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map4left);  fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map4right); fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map4upper); fgets(msg, 200, fpx);
  fscanf(fpx,"%d", &map4lower); fgets(msg, 200, fpx);

  if(ssouth >= snorth && seast >= swest){
      nlatsub = ssouth - snorth + 1;       //subregion rows
      nlonsub = seast - swest + 1;         //subregion columns
      nlatsubs = (nlatsub-1)/rowscale + 1; //subregion rows, by sampling
      nlonsubs = (nlonsub-1)/colscale + 1; //subregion columns, by sampling
      startlon = map1left + (swest - 1) * map1res;
      startlat = map1upper - (snorth - 1) * map1res;
      endlon = startlon + nlonsub * map1res - 1;
      endlat = startlat - nlatsub * map1res + 1;
      total_npoi = nlatsub * nlonsub;      //npoi without smapling

      //map1, base resolution, 1 layer maps, e.g mask, veg, biomass, fips
      start_g1[0] = 0;
      start_g1[1] = 0;
      start_g1[2] = snorth - 1;
      start_g1[3] = swest - 1;
      count_g1[0] = layers;
      count_g1[1] = 1;
      count_g1[2] = ssouth - snorth + 1;;
      count_g1[3] = seast - swest + 1;
      array_size1 = count_g1[0]*count_g1[1]*count_g1[2]*count_g1[3];
      mapSsize = nlatsubs * nlonsubs;

      //maps interp and samp
      if(map_group == 1){//this eq map1
        start_g[2] = snorth - 1;
        start_g[3] = swest - 1;
        count_g[2] = ssouth - snorth + 1;
        count_g[3] = seast - swest + 1;
        offrow = map1upper - startlat;
        offcol = startlon - map1left;
        offrowx = offrow/map1res;
        offcolx = offcol/map1res;
        map1size = count_g[2] * count_g[3];
      }
      if(map_group == 2){
        start_g[2] = (map2upper - startlat)/map2res;
        start_g[3] = (startlon - map2left)/map2res;
        count_g[2] = 1 + (int)((map2upper - endlat)/map2res) - (int)((map2upper - startlat)/map2res);
        count_g[3] = 1 + (int)((endlon - map2left)/map2res) - (int)((startlon - map2left)/map2res);
        offrow = map2upper - startlat;
        offcol = startlon - map2left;
        offrowx = offrow/map2res;
        offcolx = offcol/map2res;
        map2size = count_g[2] * count_g[3];
      }
      if(map_group == 3){
        start_g[2] = (map3upper - startlat)/map3res;
        start_g[3] = (startlon - map3left)/map3res;
        count_g[2] = 1 + (int)((map3upper - endlat)/map3res) - (int)((map3upper - startlat)/map3res);
        count_g[3] = 1 + (int)((endlon - map3left)/map3res) - (int)((startlon - map3left)/map3res);
        offrow = map3upper - startlat;
        offcol = startlon - map3left;
        offrowx = offrow/map3res;
        offcolx = offcol/map3res;
        map3size = count_g[2] * count_g[3];
      }
      if(map_group == 4){
        start_g[2] = (map4upper - startlat)/map4res;
        start_g[3] = (startlon - map4left)/map4res;
        count_g[2] = 1 + (int)((map4upper - endlat)/map4res) - (int)((map4upper - startlat)/map4res);
        count_g[3] = 1 + (int)((endlon - map4left)/map4res) - (int)((startlon - map4left)/map4res);
        offrow = map4upper - startlat;
        offcol = startlon - map4left;
        offrowx = offrow/map4res;
        offcolx = offcol/map4res;
        map4size = count_g[2] * count_g[3];
      }
      start_g[0] = 0;
      start_g[1] = 0;
      count_g[0] = layers;
      count_g[1] = 1;
      array_size = count_g[0]*count_g[1]*count_g[2]*count_g[3];

      //arrange coarse map_ids on base map1
      map1_id = (int*) malloc(sizeof(int)*array_size1);
      map2_id = (int*) malloc(sizeof(int)*array_size1);
      map3_id = (int*) malloc(sizeof(int)*array_size1);
      map4_id = (int*) malloc(sizeof(int)*array_size1);

      int iii, jjj, loc1, loc2, loc3, loc4;
      int remainder_row, remainder_col;
      k = 0;
      for(i=0; i<count_g1[2]; i++){
        remainder_row = i%rowscale;
        for(j=0; j<count_g1[3]; j++){
          remainder_col = j%colscale;

          loc1 = i*count_g1[3] + j;
          map1_id[k] = loc1;

          if(remainder_row==0 && remainder_col==0){
           if(map_group == 2){
            iii = (i*map1res + offrow)/map2res - offrowx;
            jjj = (j*map1res + offcol)/map2res - offcolx;
            loc2 = iii*count_g[3] + jjj;
            map2_id[k] = loc2;
           }

           if(map_group == 3){
            iii = (i*map1res + offrow)/map3res - offrowx;
            jjj = (j*map1res + offcol)/map3res - offcolx;
            loc3 = iii*count_g[3] + jjj;
            map3_id[k] = loc3;
           }

           if(map_group == 4){
            iii = (i*map1res + offrow)/map4res - offrowx;
            jjj = (j*map1res + offcol)/map4res - offcolx;
            loc4 = iii*count_g[3] + jjj;
            map4_id[k] = loc4;
           }
          }
          else{
            map2_id[k] = -1;
            map3_id[k] = -1;
            map4_id[k] = -1;
          }

          k = k + 1;
        }
      }

      //common data array, interp to base map, samp to samp map
      array_size_interp = layers * count_g1[2] * count_g1[3];
      array_size_samp = layers * nlatsubs * nlonsubs;
  }

  data_interp = (float*) malloc(sizeof(float)*array_size1);
  data_samp = (float*) malloc(sizeof(float)*array_size_samp);
  if(map_group == 1){
    if(nc_type == 1){
      data_char = (char*) malloc(sizeof(char)*array_size);
      ReadNCVara(nc_infile, nc_variable, NC_BYTE, start_g, count_g, data_char);
      interp_samp_char(data_char, data_interp, data_samp, layers, map_group);
      writeDat(data_samp, dat_outfile, array_size_samp, 4);
      ncwrite();
      free(data_char);
    }
    if(nc_type == 4){
      data_int = (int*) malloc(sizeof(int)*array_size);
      ReadNCVara(nc_infile, nc_variable, NC_INT, start_g, count_g, data_int);
      interp_samp_int(data_int, data_interp, data_samp, layers, map_group);
      writeDat(data_samp, dat_outfile, array_size_samp, 4);
      ncwrite();
      free(data_int);
    }
    if(nc_type == 5){
      data_float = (float*) malloc(sizeof(float)*array_size);
      ReadNCVara(nc_infile, nc_variable, NC_FLOAT, start_g, count_g, data_float);
      interp_samp_float(data_float, data_interp, data_samp, layers, map_group);
      writeDat(data_samp, dat_outfile, array_size_samp, 4);
      ncwrite();
      free(data_float);
    }
  }
  if(map_group == 3){
    if(nc_type == 1){
      data_char = (char*) malloc(sizeof(char)*array_size);
      ReadNCVara(nc_infile, nc_variable, NC_BYTE, start_g, count_g, data_char);
      interp_samp_char(data_char, data_interp, data_samp, layers, map_group);
      writeDat(data_samp, dat_outfile, array_size_samp, 4);
      ncwrite();
      free(data_char);
    }
    if(nc_type == 4){
      data_int = (int*) malloc(sizeof(int)*array_size);
      ReadNCVara(nc_infile, nc_variable, NC_INT, start_g, count_g, data_int);
      interp_samp_int(data_int, data_interp, data_samp, layers, map_group);
      writeDat(data_samp, dat_outfile, array_size_samp, 4);
      ncwrite();
      free(data_int);
    }
    if(nc_type == 5){
      data_float = (float*) malloc(sizeof(float)*array_size);
      ReadNCVara(nc_infile, nc_variable, NC_FLOAT, start_g, count_g, data_float);
      interp_samp_float(data_float, data_interp, data_samp, layers, map_group);
      writeDat(data_samp, dat_outfile, array_size_samp, 4);
      ncwrite();
      free(data_float);
    }
  }

  return 0;
}

void interp_samp_char(char *sourcex, float *interpx, float *sampx, int layers, int group){
  int i, j, k, l, ii, jj, iii, jjj;

  //step 1: interpolate coarse resolution data to base resolution
  if(group == 1){
    for(i=0;i<total_npoi*layers;i++){ //interp single layer map3, deltat
      interpx[i] = sourcex[i];
    }
  }
  else if(group == 2){
    for(i=0;i<total_npoi*layers;i++){ //interp 6 layer soil map2
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map2_id[ii] + layerx*map2size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 3){
    for(i=0;i<total_npoi*layers;i++){ //interp 12 layer norm climate maps3
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map3_id[ii] + layerx*map3size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 4){
    for(i=0;i<total_npoi*layers;i++){ //interp 12*totyears layer anorm climate map4
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map4_id[ii] + layerx*map4size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*layers;i++){ //interp lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map1_id[ii] + layerx*map1size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else{
    printf("interp_samp error1!\n");
    exit;
  }

  //Step 2: make sampling dataset from base and interpolated map
  if(group == 1){
    for(i=0;i<total_npoi;i++){ //sampling single layer maps
      ii = i/nlonsub;//original row
      jj = i%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = iii*nlonsubs + jjj; //serial id after sampling (k <= i)

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 2){
    for(i=0;i<total_npoi*layers;i++){ //sampling interpolated 6 layer soil maps
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 3){
    for(i=0;i<total_npoi*layers;i++){ //sampling interpolated 12 layer norm climate maps
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 4){
    for(i=0;i<total_npoi*layers;i++){ //sampling interpolated 12*totyears layer anorm climate map
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*layers;i++){ //sampling interpolated lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else{
    printf("interp_samp error2!\n");
    exit(0);
  }

  return;
}

//------------------------------------------------------------------------
void interp_samp_int(int *sourcex, float *interpx, float *sampx, int layers, int group){
  int i, j, k, l, ii, jj, iii, jjj;

  //step 1: interpolate coarse resolution data to base resolution
  if(group == 1){
    for(i=0;i<total_npoi*layers;i++){ //already base resolution, no interp needed
      interpx[i] = sourcex[i];
    }
  }
  else if(group == 2){
    for(i=0;i<total_npoi*layers;i++){ //interp 6 layer soil map2
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map2_id[ii] + layerx*map2size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 3){
    for(i=0;i<total_npoi*layers;i++){ //interp 12 layer norm climate maps3
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map3_id[ii] + layerx*map3size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 4){
    for(i=0;i<total_npoi*layers;i++){ //interp 12*anomyears layer anorm climate map4
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map4_id[ii] + layerx*map4size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*layers;i++){ //interp lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map1_id[ii] + layerx*map1size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else{
    printf("interp_samp error1!\n");
    exit;
  }

  //Step 2: make sampling dataset from base and interpolated map
  if(group == 1){
    for(i=0;i<total_npoi*layers;i++){ //sampling single layer maps
      ii = i/nlonsub;//original row
      jj = i%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = iii*nlonsubs + jjj; //serial id after sampling (k <= i)

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 2){
    for(i=0;i<total_npoi*layers;i++){ //sampling interpolated 6 layer soil maps
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 3){
    for(i=0;i<total_npoi*layers;i++){ //sampling interpolated 12 layer norm climate maps
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 4){
    for(i=0;i<total_npoi*layers;i++){ //sampling interpolated 12*anomyears layer anorm climate map
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*layers;i++){ //sampling interpolated lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else{
    printf("interp_samp error2!\n");
    exit(0);
  }

  return;
}









//------------------------------------------------------------------------
void interp_samp_float(float *sourcex, float *interpx, float *sampx, int layers, int group){
  int i, j, k, l, ii, jj, iii, jjj;

  //step 1: interpolate coarse resolution data to base resolution
  if(group == 1){
    for(i=0;i<total_npoi*layers;i++){ //already base resolution, no interp needed
      interpx[i] = sourcex[i];
    }
  }
  else if(group == 2){
    for(i=0;i<total_npoi*layers;i++){ //interp 6 layer soil map2
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map2_id[ii] + layerx*map2size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 3){
    for(i=0;i<total_npoi*layers;i++){ //interp 12 layer norm climate maps3
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map3_id[ii] + layerx*map3size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 4){
    for(i=0;i<total_npoi*layers;i++){ //interp 12*anomyears layer anorm climate map4
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map4_id[ii] + layerx*map4size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*layers;i++){ //interp lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map1_id[ii] + layerx*map1size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else{
    printf("interp_samp error1!\n");
    exit;
  }

  //Step 2: make sampling dataset from base and interpolated map
  if(group == 1){
    for(i=0;i<total_npoi*layers;i++){ //sampling single layer maps
      ii = i/nlonsub;//original row
      jj = i%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = iii*nlonsubs + jjj; //serial id after sampling (k <= i)

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 2){
    for(i=0;i<total_npoi*layers;i++){ //sampling interpolated 6 layer soil maps
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 3){
    for(i=0;i<total_npoi*layers;i++){ //sampling interpolated 12 layer norm climate maps
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 4){
    for(i=0;i<total_npoi*layers;i++){ //sampling interpolated 12*anomyears layer anorm climate map
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*layers;i++){ //sampling interpolated lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else{
    printf("interp_samp error2!\n");
    exit(0);
  }

  return;
}




void writeDat(float *var4, char *targetfile, int array_length, int elementsize){
  FILE *fTargetFile;
  if((fTargetFile=fopen(targetfile,"wb")) == NULL){
    printf("Error opening target DAT file\n");
    return;
  }
  fwrite(var4, elementsize, array_length, fTargetFile);
  fclose(fTargetFile);

  return;
}

void ncwrite(){
    int i, j, k;

    /*Create primary NetCDF files for holding output variables*/
    char targetfile[100], variablename[100];
    char dim_name[10][100], var_dim_name[10][100];
    int *dim1, *dim2, *dim3, *dim4, *dim_data[4];
    size_t startx[4], countx[4];
    int row, col;
    int ndims;
    nc_type nctype;
    float missing_value;

    strcpy( dim_name[0], "time" );
    strcpy( dim_name[1], "level" );
    strcpy( dim_name[2], "latitude" );
    strcpy( dim_name[3], "longitude" );
    strcpy( var_dim_name[0], "time" );
    strcpy( var_dim_name[1], "level" );
    strcpy( var_dim_name[2], "latitude" );
    strcpy( var_dim_name[3], "longitude" );
    if(1){
      startx[0] = 0;
      startx[1] = 0;
      startx[2] = 0;
      startx[3] = 0;
      countx[0] = layers;
      countx[1] = 1;
      countx[2] = nlatsubs;
      countx[3] = nlonsubs;
      row = countx[2];
      col = countx[3];

      dim1 = (int*) malloc(sizeof(float)*countx[0]);
      dim2 = (int*) malloc(sizeof(float)*countx[1]);
      dim3 = (int*) malloc(sizeof(float)*countx[2]);
      dim4 = (int*) malloc(sizeof(float)*countx[3]);

      dim4[0]= 1;
      for(i=1;i<countx[3];i++){
        dim4[i]=dim4[i-1]+1;
      }
      dim3[0]= countx[2];
      for(i=1;i<countx[2];i++){
        dim3[i]=dim3[i-1]-1;
      }
      dim2[0]= 1;
      for(i=1;i<countx[1];i++){
        dim2[i]=dim2[i-1]+1;
      }
      dim1[0]= 1;
      for(i=1;i<countx[0];i++){
        dim1[i]=dim1[i-1]+1;
      }

      dim_data[0] = dim1;
      dim_data[1] = dim2;
      dim_data[2] = dim3;
      dim_data[3] = dim4;

      writex4(data_samp, nc_outfile, "dymmy", nc_variable, "dymmy",
              dim_name, dim_data, startx, countx);

      free (dim1);
      free (dim2);
      free (dim3);
      free (dim4);
    }
  return;
}
void writex4(float *var4, char *targetfile, char *title, char *varname, char *units, char dim_name[][100], int *dim_data[], size_t *startx, size_t *countx){
    /*Create primary NetCDF files for holding output variables*/
    if(1){
      CreateNCFile(targetfile, dim_name, startx, countx, dim_data);
      CreateNCVar(targetfile, varname, NC_FLOAT, 4, dim_name);
      SetNCAttribute(targetfile, "", "title", NC_CHAR, title, 0);
      SetNCAttribute(targetfile, "time", "units", NC_CHAR, "year", 0);
      SetNCAttribute(targetfile, "level", "units", NC_CHAR, "none", 0);
      SetNCAttribute(targetfile, "latitude", "units", NC_CHAR, "1km", 0);
      SetNCAttribute(targetfile, "longitude", "units", NC_CHAR, "1km", 0);
      SetNCAttribute(targetfile, varname, "units", NC_CHAR, units, 0);
      SetNCAttribute(targetfile, varname, "missing_value", NC_FLOAT, "", -9999);
      WriteNCVara(targetfile, varname, NC_FLOAT, startx, countx, var4);
    }

  return;
}


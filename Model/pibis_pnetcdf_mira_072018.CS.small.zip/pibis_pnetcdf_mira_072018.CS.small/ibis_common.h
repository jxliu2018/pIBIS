#ifndef ibis_commonH
#define ibis_commonH
#include "netcdf.h"

#define saveyears 115
#define anomyears 45
#define lccyears 40
#define fireyears 32
#define ndepyears 40
#define out0single 0

#define npft 15
#define npoi 10
#define nband 2
#define nsoilay 6
#define ncrop 10
#define ndat 12
#define nsoi 12
#define ndist 10
#define npart 3

#define nlon 100
#define nlat 100
#define xres 1.0
#define yres 1.0
#define nsnolay 3
#define npftu 8
#define totfips 3111
#define nfips 20
#define pi 3.1415927

#define OrgLayers 0
#define Theta 0.0000001
#define scatter_years 5

//called from main.c
void rdinfile();
void rdparam();
void rdscaler();
void rdlanduse();
int my_rank;

//void interp_char(char *, float *, int);
//void interp_float(float *, float *, int);
//void samp_float(float *, float *, int);
//void render_float(float *, float *, int);

void interp_float(float *, float *, float *, int, int);
void interp_samp_float_anom(float *, float *, float *, float *, int, int);
void interp_samp_float(float *, float *, float *, float *, int);
void interp_samp_char(char *, float *, float *, float *, int);
void interp();
void calc_valid_seg();
void datapack();
void invertp0(char *);
void invertp();
void invert_npp();
void writeDat(float *, char *, int, int);
int errmsg(const char *, int);

//called from ncvar.c
void set_init_value_char(char*, char, int);
void set_init_value_int(int*, int, int);
void set_init_value(float*, float, int);

void ncread(int flag);
void ncread0(int flag );
void ncread1(int flag);
void ncread2(int flag);
void ncread3(int flag);
void ncread4(int flag);
void ncread4_1(int flag);
void ncread4_2(int flag);
void ncread4_3(int flag);
void ncread4_4(int flag);
void ncread4_5(int flag);
void ncread4_6(int flag);
void ncread4_7(int flag);
void ncread4_8(int flag);
void ncread4_9(int flag);
void ncread4_10(int flag);
void ncread5();
void ncread5_1(int flag);
void ncread5_2(int flag);
void ncread5_3(int flag);
void ncread5_4(int flag);
void ncread5_5(int flag);
void ncread5_6(int flag);
void ncread5_7(int flag);
void ncread5_8(int flag);
void ncread5_9(int flag);
void ncread5_10(int flag);
void ncread6();
void ncread6_1();
void ncread6_2();
void ncread6_3();
void ncread6_4();
void ncread6_5();
void ncread6_6();
void ncread6_7();
void ncread6_8();
void ncread6_9();
void ncread6_10();
void ncread7();
void ncread8();
void ncread8_1();
void ncread8_2();
void ncread8_3();
void ncread8_4();
void ncread8_5();
void ncread8_6();
void ncread8_7();
void ncread8_8();
void ncread8_9();
void ncread8_10();
void ncread9();
void ncread10();
void ncwrite();
void writex4(float *, char *, char *, char *, char *, char names[][10], int *dim_data[], size_t *startx, size_t *countx);

//called from io-netcdf.c
void GetNCInfo(char *ncfilename);
void CreateNCFile(char *ncfilename, char names[][10], size_t *start, size_t *count, int *dim_data[]);
void CreateNCVar(char *ncfilename, char *ncvarname, nc_type nctype, int ndims, char ncvar_dimnames[][10]);
void WriteNCVara(char *ncfilename, char *ncvarname, nc_type nctype, size_t *start, size_t *count, void *tp);
void ReadNCVara(char *ncfilename, char *ncvarname, nc_type nctype, size_t *start, size_t *count, void *tp);
void SetNCAttribute(char *ncfilename, char *ncvarname, char *attname, nc_type nctype, char *att, float floatval);

/* variables used in ncvar.c*/
  size_t start_g1[4], count_g1[4];
  size_t start_g2[4], count_g2[4];
  size_t start_g3[4], count_g3[4];
  size_t start_g4[4], count_g4[4];
  size_t start_g5[4], count_g5[4];
  int *map1_id;
  int *map2_id;
  int *map3_id;
  int *map4_id;
  int *map5_id;

/* netcdf read-in related variables */
  //map1 class
  char *surta_data;
  float *cell_lat_data;
  char *cell_area_data;
  float *topo_data;
  char *vegtype0_data;
  char *ecoreg_data;
  int *fips_data;
  int *fips123; //fips code rearrange to 1, 2, 3
  char *wetland_data;

  float *biomf_c_data;
  float *bioms_c_data;
  float *biomg_c_data;
  float *nh4dep_data;
  float *no3dep_data;
  char *burnlow_data;
  char *burnmix_data;
  char *burnhigh_data;

  char *pct_for_data;
  char *pct_shr_data;
  char *pct_gra_data;
  char *pct_agr_data;
  char *pct_c3crop_data;
  char *pct_c4crop_data;
  char *pct_wdcrop_data;
  char *pct_wetland_data;
  char *pct_nveg_data;
  char *owner_type_data;

  //map2 class
  char  *sand_data;
  char  *clay_data;
  char  *ph_data;
  float *soilc_data;
  float *nmmax_data;

  //map3 class
  float *wetd_norm_data;
  float *cld_norm_data;
  float *prec_norm_data;
  float *temp_norm_data;
  float *trange_norm_data;
  float *rhum_norm_data;
  float *wspd_norm_data;
  float *co2spa_norm_data;
  float *deltat_norm_data;

  //map4 class
  float *prec_anorm_data;
  float *temp_anorm_data;
  float *trange_anorm_data;

  //map5 class
  char *lc_data;
  char *lcc_data;
  char *fire_data;
  char *ndep_data;
  char *burnlf_data;
  char *burnhf_data;
  char *burnmf_data;
  char *burnls_data;
  char *burnhs_data;
  char *burnms_data;

/* interpolation related variables */
  float *deltat_norm_data_interp;

/* sampling related variables */

/* scatter related variables */
  float *sand_data_scatter;
  float *clay_data_scatter;
  float *ph_data_scatter;
  float *soilc_data_scatter;
  float *nmmax_data_scatter;

  float *wetd_norm_data_scatter;
  float *cld_norm_data_scatter;
  float *prec_norm_data_scatter;
  float *temp_norm_data_scatter;
  float *trange_norm_data_scatter;
  float *rhum_norm_data_scatter;
  float *wspd_norm_data_scatter;
  float *co2spa_norm_data_scatter;
  float *deltat_norm_data_scatter;

  float *prec_anorm_data_scatter;
  float *temp_anorm_data_scatter;
  float *trange_anorm_data_scatter;

  float *prec_anorm_data_scatter1;
  float *temp_anorm_data_scatter1;
  float *trange_anorm_data_scatter1;

  float *prec_anorm_data_scatter2;
  float *temp_anorm_data_scatter2;
  float *trange_anorm_data_scatter2;

  float *prec_anorm_data_scatter3;
  float *temp_anorm_data_scatter3;
  float *trange_anorm_data_scatter3;

  float *prec_anorm_data_scatter4;
  float *temp_anorm_data_scatter4;
  float *trange_anorm_data_scatter4;

  float *prec_anorm_data_scatter5;
  float *temp_anorm_data_scatter5;
  float *trange_anorm_data_scatter5;

  float *prec_anorm_data_scatter6;
  float *temp_anorm_data_scatter6;
  float *trange_anorm_data_scatter6;

  float *prec_anorm_data_scatter7;
  float *temp_anorm_data_scatter7;
  float *trange_anorm_data_scatter7;

  float *prec_anorm_data_scatter8;
  float *temp_anorm_data_scatter8;
  float *trange_anorm_data_scatter8;

  float *prec_anorm_data_scatter9;
  float *temp_anorm_data_scatter9;
  float *trange_anorm_data_scatter9;

  float *prec_anorm_data_scatter10;
  float *temp_anorm_data_scatter10;
  float *trange_anorm_data_scatter10;

  float *lc_data_scatter;
  float *lcc_data_scatter;
  float *fire_data_scatter;
  float *ndep_data_scatter;
  float *burnlf_data_scatter;
  float *burnhf_data_scatter;
  float *burnmf_data_scatter;
  float *burnls_data_scatter;
  float *burnhs_data_scatter;
  float *burnms_data_scatter;

/* common data array */
  float *soil_data_interp;
  float *climate_norm_interp;
  float *climate_anorm_interp;
  float *climate_anorm_interp_prec;
  float *climate_anorm_interp_temp;
  float *climate_anorm_interp_trange;
  float *lcc_interp;
  float *fire_interp;
  float *ndep_interp;

  float *soil_data_samp;
  float *climate_norm_samp;
  float *climate_anorm_samp;
  float *lcc_samp;
  float *fire_samp;
  float *ndep_samp;

/* other single layer array*/
  int *serial_id_samp;

/* netcdf write-out related variables */
  float *out_aynpptot;
  float *invert_aynpptot;

  float *out_0;
  float *out_1;
  float *out_2;
  float *out_3;
  float *out_4;
  float *out_5;
  float *out_6;
  float *out_7;
  float *out_8;
  float *out_9;
  float *out_10;
  float *out_11;
  float *out_12;
  float *out_13;
  float *out_14;
  float *out_15;
  float *out_16;
  float *out_17;
  float *out_18;
  float *out_19;
  float *out_20;
  float *out_21;
  float *out_22;
  float *out_23;
  float *out_24;
  float *out_25;
  float *out_26;
  float *out_27;
  float *out_28;
  float *out_29;
  float *out_30;
  float *out_31;
  float *out_32;
  float *out_33;
  float *out_34;
  float *out_35;
  float *out_36;
  float *out_37;
  float *out_38;
  float *out_39;
  float *out_40;

  float *invert_0;
  float *invert_1;
  float *invert_2;
  float *invert_3;
  float *invert_4;
  float *invert_5;
  float *invert_6;
  float *invert_7;
  float *invert_8;
  float *invert_9;
  float *invert_10;
  float *invert_11;
  float *invert_12;
  float *invert_13;
  float *invert_14;
  float *invert_15;
  float *invert_16;
  float *invert_17;
  float *invert_18;
  float *invert_19;
  float *invert_20;
  float *invert_21;
  float *invert_22;
  float *invert_23;
  float *invert_24;
  float *invert_25;
  float *invert_26;
  float *invert_27;
  float *invert_28;
  float *invert_29;
  float *invert_30;
  float *invert_31;
  float *invert_32;
  float *invert_33;
  float *invert_34;
  float *invert_35;
  float *invert_36;
  float *invert_37;
  float *invert_38;
  float *invert_39;
  float *invert_40;

/* several global scope variables*/
  int totrows, totcols, total_npoi;
  int total_segment, segment_id, segment_npoi, start_loc, start_loc_new;
  int layerx, remx, map1size, map2size, map3size, map4size, mapSsize;
  int valid_segment, valid_segment_id, valid_segment_npoi[1310720];//for BGQ 8racks

  int time_length1, time_length2, time_length3, time_length4, time_length5;
  int rows1, rows2, rows3, rows4, rows5;
  int columns1, columns2, columns3, columns4, columns5;
  int layers1, layers2, layers3, layers4, layers5;
  int array_size1, array_size2, array_size3, array_size4, array_size5;
  int array_size1_interp, array_size2_interp, array_size3_interp, array_size4_interp, array_size5_interp;
  int array_size1_samp, array_size2_samp, array_size3_samp, array_size4_samp, array_size5_samp;
  int array_size4_interp_s, array_size4_interp_x;
  int offrow1,offcol1,offrow2,offcol2,offrow3,offcol3,offrow4,offcol4,offrow5,offcol5;
  int offrow1x,offcol1x,offrow2x,offcol2x,offrow3x,offcol3x,offrow4x,offcol4x,offrow5x,offcol5x;

/* vector holding univeral parameters read from infile and params files */
  float vectorp[1200];
  float vectors[nfips*9];//for passing scalers to all ranks
  float vectorl[nfips*9];//for passing landsue table to all ranks

/* other input data to be passed to ibislib_*/
  float matrix1[3][npoi*6];           //e.g. soil
  float matrix2[8][npoi*12];          //e.g. normal cliamte
  float matrix3[3][npoi*anomyears*12];//e.g. climate anomaly
  float matrix4[30][npoi];            //e.g. universal control variables
  float matrix5[9][npoi*lccyears];    //e.g. lcc, fire, ndep, wetland change, max length 

  float outputp1[npoi*saveyears];
  float outputp2[npoi*saveyears];
  float outputp3[npoi*saveyears];
  float outputp4[npoi*saveyears];
  float outputp5[npoi*saveyears];
  float outputp6[npoi*saveyears];
  float outputp7[npoi*saveyears];
  float outputp8[npoi*saveyears];
  float outputp9[npoi*saveyears];
  float outputp10[npoi*saveyears];
  float outputp11[npoi*saveyears];
  float outputp12[npoi*saveyears];
  float outputp13[npoi*saveyears];
  float outputp14[npoi*saveyears];
  float outputp15[npoi*saveyears];
  float outputp16[npoi*saveyears];
  float outputp17[npoi*saveyears];
  float outputp18[npoi*saveyears];
  float outputp19[npoi*saveyears];
  float outputp20[npoi*saveyears];
  float outputp21[npoi*saveyears];
  float outputp22[npoi*saveyears];
  float outputp23[npoi*saveyears];
  float outputp24[npoi*saveyears];
  float outputp25[npoi*saveyears];
  float outputp26[npoi*saveyears];
  float outputp27[npoi*saveyears];
  float outputp28[npoi*saveyears];
  float outputp29[npoi*saveyears];
  float outputp30[npoi*saveyears];
  float outputp31[npoi*saveyears];
  float outputp32[npoi*saveyears];
  float outputp33[npoi*saveyears];
  float outputp34[npoi*saveyears];
  float outputp35[npoi*saveyears];
  float outputp36[npoi*saveyears];
  float outputp37[npoi*saveyears];
  float outputp38[npoi*saveyears];
  float outputp39[npoi*saveyears];
  float outputp40[npoi*saveyears];
  char local_surta_data[npoi];
  char local_cell_area_data[npoi];
  char local_vegtype0_data[npoi];
  char local_ecoreg_data[npoi];
  char local_wetland_data[npoi];
  char local_burnlow_data[npoi];
  char local_burnmix_data[npoi];
  char local_burnhigh_data[npoi];
  char local_pct_for_data[npoi];
  char local_pct_shr_data[npoi];
  char local_pct_gra_data[npoi];
  char local_pct_agr_data[npoi];
  char local_pct_c3crop_data[npoi];
  char local_pct_c4crop_data[npoi];
  char local_pct_wdcrop_data[npoi];
  char local_pct_wetland_data[npoi];
  char local_pct_nveg_data[npoi];
  char local_owner_type_data[npoi];

  int local_fips_data[npoi];
  int local_fips123[npoi];
  int local_serial_id[npoi];

  float local_cell_lat_data[npoi];
  float local_topo_data[npoi];
  float local_biomf_c_data[npoi];
  float local_bioms_c_data[npoi];
  float local_biomg_c_data[npoi];
  float local_nh4dep_data[npoi];
  float local_no3dep_data[npoi];
  float local_soilc_data[npoi];
  float local_nmmax_data[npoi];
  float local_deltat_norm_data[npoi];

  float matrix1_sand[npoi*6];
  float matrix1_clay[npoi*6];
  float matrix1_ph[npoi*6];

  float matrix2_wetd_norm[npoi*12];
  float matrix2_cld_norm[npoi*12];
  float matrix2_prec_norm[npoi*12];
  float matrix2_temp_norm[npoi*12];
  float matrix2_trange_norm[npoi*12];
  float matrix2_rhum_norm[npoi*12];
  float matrix2_wspd_norm[npoi*12];
  float matrix2_co2spa_norm[npoi*12];

  //float matrix3_prec_anorm[npoi*anomyears*12];
  //float matrix3_temp_anorm[npoi*anomyears*12];
  //float matrix3_trange_anorm[npoi*anomyears*12];
  float matrix3_prec_anorm1[npoi*scatter_years*12];
  float matrix3_prec_anorm2[npoi*scatter_years*12];
  float matrix3_prec_anorm3[npoi*scatter_years*12];
  float matrix3_prec_anorm4[npoi*scatter_years*12];
  float matrix3_prec_anorm5[npoi*scatter_years*12];
  float matrix3_prec_anorm6[npoi*scatter_years*12];
  float matrix3_prec_anorm7[npoi*scatter_years*12];
  float matrix3_prec_anorm8[npoi*scatter_years*12];
  float matrix3_prec_anorm9[npoi*scatter_years*12];
  float matrix3_prec_anorm10[npoi*scatter_years*12];
  float matrix3_temp_anorm1[npoi*scatter_years*12];
  float matrix3_temp_anorm2[npoi*scatter_years*12];
  float matrix3_temp_anorm3[npoi*scatter_years*12];
  float matrix3_temp_anorm4[npoi*scatter_years*12];
  float matrix3_temp_anorm5[npoi*scatter_years*12];
  float matrix3_temp_anorm6[npoi*scatter_years*12];
  float matrix3_temp_anorm7[npoi*scatter_years*12];
  float matrix3_temp_anorm8[npoi*scatter_years*12];
  float matrix3_temp_anorm9[npoi*scatter_years*12];
  float matrix3_temp_anorm10[npoi*scatter_years*12];
  float matrix3_trange_anorm1[npoi*scatter_years*12];
  float matrix3_trange_anorm2[npoi*scatter_years*12];
  float matrix3_trange_anorm3[npoi*scatter_years*12];
  float matrix3_trange_anorm4[npoi*scatter_years*12];
  float matrix3_trange_anorm5[npoi*scatter_years*12];
  float matrix3_trange_anorm6[npoi*scatter_years*12];
  float matrix3_trange_anorm7[npoi*scatter_years*12];
  float matrix3_trange_anorm8[npoi*scatter_years*12];
  float matrix3_trange_anorm9[npoi*scatter_years*12];
  float matrix3_trange_anorm10[npoi*scatter_years*12];

  float matrix4_base[npoi*30];

  float matrix5_lcc[npoi*lccyears];
  float matrix5_fire[npoi*lccyears];
  float matrix5_burnlf[npoi*lccyears];
  float matrix5_burnhf[npoi*lccyears];
  float matrix5_burnmf[npoi*lccyears];
  float matrix5_burnls[npoi*lccyears];
  float matrix5_burnhs[npoi*lccyears];
  float matrix5_burnms[npoi*lccyears];
  float matrix5_ndep[npoi*lccyears];

/* vector holding model state for restart simulation */
  float arraya[npoi*400];

/* for simulation control ibis.infile */
  int
  irestart,   //0: not a restart run  1: restart run
  iyear0,     //initial year of simulation (don't change for restart)
  nrun,       //number of years in this simulation (change for restart)
  iyranom,    //year to start reading anomalies (don't chng for restart)
  nanom,      //number of years in the anomaly files (ditto)
  iyrdaily,   //year to start reading daily data (ditto)
  soilcspin,  //0: no soil spinup, 1: acceleration procedure used
  iyearout,   //0: no yearly output, 1: yearly output
  imonthout,  //0: no monthly output, 1: monthly output
  idailyout,  //0: no daily output, 1: daily output
  isimveg,    //0: static veg, 1: dynamic veg, 2: dynamic veg-cold start
  isimfire,   //0: fixed fire, N: dynam fire starting year
  isimlcc,    //0: lcc maps (xdist)  1: lct that needs interpolation
  isimco2,    //0: fixed co2,  1: ramped co2
  dtime,      //time step in seconds
  idiag,      //0: no diagnostic output, 1-10 # of files to output
  cluster,    //if use JFD or polygon mask in simulation
  events,     //start year of LULCC events e.g. 1973; 0 = no LULCC
  snorth,     //northern latitude for subsetting in/ouput
  ssouth,     //southern latitude for subsetting in/ouput
  swest,      //western longitude for subsetting in/ouput
  seast,      //eastern longitude for subsetting in/ouput
  rowscale,   //row sampling interval (rowscale)
  colscale;   //column sampling interval (colscale)

  float
  co2init,    //initial co2 concentration in mol/mol (real)
  o2init;     //initial o2 concentration in mol/mol (real)

  int use_anom[1], use_lcc[1], use_fire[1], use_ndep[1], biom_reset[1];//some input switches

/* from compft.h, for reading parameters in paramsx.can */
  float 
  tau15,          // co2/o2 specificity ratio at 15 degrees C (dimensionless)
  kc15,           // co2 kinetic parameter (mol/mol)
  ko15,           // o2 kinetic parameter (mol/mol) 
  cimax,          // maximum value for ci (needed for model stability)

  alpha3,         // intrinsic quantum efficiency for C3 plants (dimensionless)
  beta3,          // photosynthesis coupling coefficient for C3 plants (dimensionless)
  theta3,         // photosynthesis coupling coefficient for C3 plants (dimensionless)
  alpha4,         // intrinsic quantum efficiency for C4 plants (dimensionless)
  beta4,          // photosynthesis coupling coefficient for C4 plants (dimensionless)
  theta4,         // photosynthesis coupling coefficient for C4 plants (dimensionless) 

  gammaub,        // leaf respiration coefficient
  coefmub,        // 'm' coefficient for stomatal conductance relationship
  coefbub,        // 'b' coefficient for stomatal conductance relationship
  gsubmin,        // absolute minimum stomatal conductance

  gammauc,        // leaf respiration coefficient
  coefmuc,        // 'm' coefficient for stomatal conductance relationship  
  coefbuc,        // 'b' coefficient for stomatal conductance relationship  
  gsucmin,        // absolute minimum stomatal conductance

  gammals,        // leaf respiration coefficient
  coefbls,        // 'b' coefficient for stomatal conductance relationship 
  coefmls,        // 'm' coefficient for stomatal conductance relationship 
  gslsmin,        // absolute minimum stomatal conductance

  gammal3,        // leaf respiration coefficient
  coefml3,        // 'm' coefficient for stomatal conductance relationship 
  coefbl3,        // 'b' coefficient for stomatal conductance relationship 
  gsl3min,        // absolute minimum stomatal conductance

  gammal4,        // leaf respiration coefficient
  coefml4,        // 'm' coefficient for stomatal conductance relationship
  coefbl4,        // 'b' coefficient for stomatal conductance relationship
  gsl4min,        // absolute minimum stomatal conductance

  gammac4,        // leaf respiration coefficient
  coefmc4,        // 'm' coefficient for stomatal conductance relationship
  coefbc4,        // 'b' coefficient for stomatal conductance relationship
  gsc4min,        // absolute minimum stomatal conductance

  gammac3,        // leaf respiration coefficient
  coefmc3,        // 'm' coefficient for stomatal conductance relationship
  coefbc3,        // 'b' coefficient for stomatal conductance relationship
  gsc3min,        // absolute minimum stomatal conductance

  chifuz,         // upper canopy leaf orientation factor
  chiflz,         // lower canopy leaf orientation factor

  vmax_pft[npft], // nominal vmax of top leaf at 15 C (mol-co2/m**2/s) [not used]
  tauleaf[npft],  // foliar biomass turnover time constant (years)
  tauroot[npft],  // fine root biomass turnover time constant (years)
  tauwood0[npft], // normal (unstressed) turnover time for wood biomass (years)

/* from compft.h, for reading parameters in paramsx.can */
  TminL[npft],    // Absolute minimum temperature -- lower limit (upper canopy PFTs)
  TminU[npft],    // Absolute minimum temperature -- upper limit (upper canopy PFTs)
  Twarm[npft],    // Temperature of warmest month (lower canopy PFTs)
  GDD[npft],      // minimum GDD needed (base 5 C for upper canopy PFTs, 
                  // base 0 C for lower canopy PFTs)
  plai_init[4][15], // initial total LAI for each vegtype (used in iniveg)
  plaiupper,      // Potental LAI of upper canopy (uniform initial vegetation)
  plailower,      // Potental LAI of lower canopy (uniform initial vegetation)
  xminlai,        // Minimum LAI for each existing PFT
  sapfrac_init,   // Initial value of sapwood fraction used for all woody PFTs
  beta1,          // parameter for Jackson rooting profile, lower canopy
  beta2;          // parameter for Jackson rooting profile, upper canopy

/* from compft.h, variables */
  float
  tauwood[npft];  // wood biomass turnover time constant (years)

/* from comveg.h, for reading paramsx.can */
  float
  specla[npft],       // specific leaf area (m**2/kg)
  aleaf[npoi][npft],  // carbon allocation fraction to leaves
  aroot[npoi][npft],  // carbon allocation fraction to fine roots
  awood[npoi][npft],  // carbon allocation fraction to wood
  woodnorm,           // value of woody biomass for upper canopy closure (ie when wood = woodnorm fu = 1.0) (kg_C m-2)
  tauveg[nband][2],   // transmittance of an average leaf/stem
  dleaf[2],           // typical linear leaf dimension in aerodynamic transfer coefficient (m)
  dstem[2],           // typical linear stem dimension in aerodynamic transfer coefficient (m)
  alaimu,             // upper canopy leaf & stem area (2 sided) for normalization of drag coefficient (m2 m-2)
  alaiml,             // lower canopy leaf & stem maximum area (2 sided) for normalization of drag coefficient (m2 m-2)
  cleaf,              // empirical constant in upper canopy leaf-air aerodynamic transfer coefficient (m s-0.5) (A39a Pollard & Thompson 95)
  cstem,              // empirical constant in upper canopy stem-air aerodynamic transfer coefficient (m s-0.5) (A39a Pollard & Thompson 95)
  cgrass,             // empirical constant in lower canopy-air aerodynamic transfer coefficient (m s-0.5) (A39a Pollard & Thompson 95)
  chs,                // heat capacity of upper canopy stems per unit stem area (J kg-1 m-2)
  chu,                // heat capacity of upper canopy leaves per unit leaf area (J kg-1 m-2)
  chl,                // heat capacity of lower canopy leaves & stems per unit leaf/stem area (J kg-1 m-2)
  wliqumax,           // maximum intercepted water on a unit upper canopy leaf area (kg m-2)
  wliqsmax,           // maximum intercepted water on a unit upper canopy stem area (kg m-2)
  wliqlmax,           // maximum intercepted water on a unit lower canopy stem & leaf area (kg m-2)
  wsnoumax,           // intercepted snow capacity for upper canopy leaves (kg m-2)
  wsnosmax,           // intercepted snow capacity for upper canopy stems (kg m-2)
  wsnolmax,           // intercepted snow capacity for lower canopy leaves & stems (kg m-2)
  tdripu,             // decay time for dripoff of liquid intercepted by upper canopy leaves (sec)
  tdrips,             // decay time for dripoff of liquid intercepted by upper canopy stems (sec)
  tdripl,             // decay time for dripoff of liquid intercepted by lower canopy leaves & stem (sec)
  tblowu,             // decay time for blowoff of snow intercepted by upper canopy leaves (sec)
  tblows,             // decay time for blowoff of snow intercepted by upper canopy stems (sec)
  tblowl;             // decay time for blowoff of snow intercepted by lower canopy leaves & stems (sec)

/* from comveg.h, for reading paramsx.veg */
  float
  cnmnpl[npft],       //min c:n ratio of plant leaf,             I1
  cnmnpw[npft],       //min c:n ratio of plant wood,             I1
  cnmnpr[npft],       //min c:n ratio of plant root,             I1
  cnmxpl[npft],       //max c:n ratio of plant leaf,             I1
  cnmxpw[npft],       //max c:n ratio of plant wood,             I1
  cnmxpr[npft];       //max c:n ratio of plant root,             I1
  float
  cnmnll[npft],       //min c:n ratio of leaf litter,            I1
  cnmnlw[npft],       //min c:n ratio of wood litter,            I1
  cnmnlr[npft],       //min c:n ratio of root litter,            I1
  cnmxll[npft],       //max c:n ratio of leaf litter,            I1
  cnmxlw[npft],       //max c:n ratio of wood litter,            I1
  cnmxlr[npft];       //max c:n ratio of root litter,            I1
  float
  r1pstore[npft],     // ratio of C&N storage production in plant stem/shoot
  r1rstore[npft],     // ratio of C&N storage production in plant stem/shoot
  r2pstore[npft],     // ratio of C&N storage usage in plant stem/shoot
  r2rstore[npft],     // ratio of C&N storage usage in plant root system
  remroot[npft],      //root removal/harvest ratio 0-1
  remshoot[npft],     //shoot removal/harvest ratio 0-1
  rthining[npft],     //selective cutting ratio 0-1
  ferttree[npft];     //non-crop vegetation fertilizqation level 0-1

/* from comveg.h, for reading paramsx.soi */
  float
  cnleaf[npoi],       //c:n ratio of averaged leaf litterfall,   I2,I3
  cnroot[npoi],       //c:n ratio of averaged root turnover,     I2,I3
  cnwood[npoi],       //c:n ratio of averaged woody debris,      I2,I3
  nmmax,              //mineral N level above which no N limitation will occur, (g_N m-2),  I2
  kp[npoi],           //modifier for n uptake from soil,          I2
  kl[npoi],           //modifier for n absorb in soil,            I2
  ks[npoi],           //modifier for n release in soil,           I2
  cnrmin[8],          //min c:n ratio of litter and SOM,         I1
  cnrmax[8];          //max c:n ratio of litter and SOM,         I1

/* from comveg.h, for reading paramsx.crp */
  float
  cropcomp[ncrop],          //crop composition cumulative probabilities, read from table 0-1
  gindex[ncrop],            //growth modifier to C3/C3 photosynthesis rate, 0-1
  hindex[ncrop],            //harvest index of crop 0-1
  strawrem[ncrop],          //propotion of straw removed/burned after harvesting
  fertcrop[ncrop];          //crop fertilization level

/* from comveg.h, for variables */
  float
  wliqmin,            // minimum intercepted water on unit vegetated area (kg m-2)
  wsnomin,            // minimum intercepted snow on unit vegetated area (kg m-2)
  q12[npoi],          // specific humidity of air at z12
  q34[npoi],          // specific humidity of air at z34
  sl[npoi],           // air-vegetation transfer coefficients (*rhoa) for lower canopy leaves & stems (m s-1*kg m-3) (A39a Pollard & Thompson 1995)
  ss[npoi],           // air-vegetation transfer coefficients (*rhoa) for upper canopy stems (m s-1 * kg m-3) (A39a Pollard & Thompson 1995)
  su[npoi],           // air-vegetation transfer coefficients (*rhoa) for upper canopy leaves (m s-1 * kg m-3) (A39a Pollard & Thompson 1995)
  topparl[npoi],      // total photosynthetically active raditaion absorbed by top leaves of lower canopy (W m-2)
  topparu[npoi],      // total photosynthetically active raditaion absorbed by top leaves of upper canopy (W m-2)
  tl[npoi],           // temperature of lower canopy leaves & stems(K)
  ts[npoi],           // temperature of upper canopy stems (K)
  tu[npoi],           // temperature of upper canopy leaves (K)
  tlsub[npoi],        // temperature of lower canopy vegetation buried by snow (K)
  t12[npoi],          // air temperature at z12 (K)
  t34[npoi],          // air temperature at z34 (K)
  wliql[npoi],        // intercepted liquid h2o on lower canopy leaf and stem area (kg m-2)
  wliqs[npoi],        // intercepted liquid h2o on upper canopy stem area (kg m-2)
  wliqu[npoi],        // intercepted liquid h2o on upper canopy leaf area (kg m-2)
  wsnol[npoi],        // intercepted frozen h2o (snow) on lower canopy leaf & stem area (kg m-2)
  wsnos[npoi],        // intercepted frozen h2o (snow) on upper canopy stem area (kg m-2)
  wsnou[npoi];        // intercepted frozen h2o (snow) on upper canopy leaf area (kg m-2)
  float
  agcub[npoi],        // canopy average gross photosynthesis rate - broadleaf  (mol_co2 m-2 s-1)
  agcuc[npoi],        // canopy average gross photosynthesis rate - conifer    (mol_co2 m-2 s-1)
  agcls[npoi],        // canopy average gross photosynthesis rate - shrubs     (mol_co2 m-2 s-1)
  agcl3[npoi],        // canopy average gross photosynthesis rate - c3 grasses (mol_co2 m-2 s-1)
  agcl4[npoi],        // canopy average gross photosynthesis rate - c4 grasses (mol_co2 m-2 s-1)
  agcc4[npoi],        // canopy average gross photosynthesis rate - c4 crop (mol_co2 m-2 s-1)    C4crop 2012-05-29
  agcc3[npoi],        // canopy average gross photosynthesis rate - c3 crop (mol_co2 m-2 s-1)    C3crop 2012-05-29
  ancub[npoi],        // canopy average net photosynthesis rate - broadleaf    (mol_co2 m-2 s-1)
  ancuc[npoi],        // canopy average net photosynthesis rate - conifer      (mol_co2 m-2 s-1)
  ancls[npoi],        // canopy average net photosynthesis rate - shrubs       (mol_co2 m-2 s-1)
  ancl3[npoi],        // canopy average net photosynthesis rate - c3 grasses   (mol_co2 m-2 s-1)
  ancl4[npoi],        // canopy average net photosynthesis rate - c4 grasses   (mol_co2 m-2 s-1)
  ancc4[npoi],        // canopy average net photosynthesis rate - c4 crop   (mol_co2 m-2 s-1)    C4crop 2012-05-29
  ancc3[npoi],        // canopy average net photosynthesis rate - c3 crop   (mol_co2 m-2 s-1)    C3crop 2012-05-29
  totcondub[npoi],    //
  totconduc[npoi],    //
  totcondls[npoi],    //
  totcondl3[npoi],    //
  totcondl4[npoi],    //
  totcondc4[npoi],    //  C4crop 2012-05-29
  totcondc3[npoi];    //  C3crop 2012-05-29
  float
  ciub[npoi],         // intercellular co2 concentration - broadleaf (mol_co2/mol_air)
  ciuc[npoi],         // intercellular co2 concentration - conifer   (mol_co2/mol_air)
  cils[npoi],         // intercellular co2 concentration - shrubs    (mol_co2/mol_air)
  cil3[npoi],         // intercellular co2 concentration - c3 plants (mol_co2/mol_air)
  cil4[npoi],         // intercellular co2 concentration - c4 plants (mol_co2/mol_air)
  cic4[npoi],         // intercellular co2 concentration - c4 crop (mol_co2/mol_air)  C4crop 2012-05-29
  cic3[npoi],         // intercellular co2 concentration - c3 crop (mol_co2/mol_air)  C3crop 2012-05-29
  csub[npoi],         // leaf boundary layer co2 concentration - broadleaf (mol_co2/mol_air)
  csuc[npoi],         // leaf boundary layer co2 concentration - conifer   (mol_co2/mol_air)
  csls[npoi],         // leaf boundary layer co2 concentration - shrubs    (mol_co2/mol_air)
  csl3[npoi],         // leaf boundary layer co2 concentration - c3 plants (mol_co2/mol_air)
  csl4[npoi],         // leaf boundary layer co2 concentration - c4 plants (mol_co2/mol_air)
  csc4[npoi],         // leaf boundary layer co2 concentration - c4 crop (mol_co2/mol_air)    C4crop 2012-05-29
  csc3[npoi],         // leaf boundary layer co2 concentration - c3 crop (mol_co2/mol_air)    C3crop 2012-05-29
  gsub[npoi],         // upper canopy stomatal conductance - broadleaf  (mol_co2 m-2 s-1)
  gsuc[npoi],         // upper canopy stomatal conductance - conifer    (mol_co2 m-2 s-1)
  gsls[npoi],         // lower canopy stomatal conductance - shrubs     (mol_co2 m-2 s-1)
  gsl3[npoi],         // lower canopy stomatal conductance - c3 grasses (mol_co2 m-2 s-1)
  gsl4[npoi],         // lower canopy stomatal conductance - c4 grasses (mol_co2 m-2 s-1)
  gsc4[npoi],         // lower canopy stomatal conductance - c4 crop (mol_co2 m-2 s-1)    C4crop 2012-05-29
  gsc3[npoi];         // lower canopy stomatal conductance - c3 crop (mol_co2 m-2 s-1)    C3crop 2012-05-29
  float
  agddl[npoi],        // annual accumulated growing degree days for bud burst, lower canopy (day-degrees)
  agddu[npoi],        // annual accumulated growing degree days for bud burst, upper canopy (day-degrees)
  fl[npoi],           // fraction of snow-free area covered by lower  canopy
  fu[npoi],           // fraction of overall area covered by upper canopy
  fuprev[npoi],       // previous year fraction of overall area covered by upper canopy
  gdd0[npoi],         // growing degree days > 0C
  gdd0this[npoi],     // annual total growing degree days for current year
  gdd5[npoi],         // growing degree days > 5C
  gdd5this[npoi],     // annual total growing degree days for current year
  sapfrac[npoi],      // fraction of woody biomass that is in sapwood
  tc[npoi],           // coldest monthly temperature (C)
  tcthis[npoi],       // coldest monthly temperature of current year (C)
  tcmin[npoi],        // coldest daily temperature of current year (C)
  totlail[npoi],      // total leaf area index for the lower canopy
  totlaiu[npoi],      // total leaf area index for the upper canopy
  totbiol[npoi],      // total biomass in the lower canopy (kg_C m-2)
  totbiou[npoi],      // total biomass in the upper canopy (kg_C m-2)
  tw[npoi],           // warmest monthly temperature (C)
  twthis[npoi],       // warmest monthly temperature of current year (C)
  disturbf[npoi],     // annual fire disturbance regime (m2/m2/yr)
  disturbo[npoi],     // fraction of biomass pool lost every year to disturbances other than fire
  firefac[npoi],      // factor that respresents the annual average fuel dryness of a grid cell, and hence characterizes the readiness to burn
  tco2mic[npoi],      // instantaneous microbial co2 flux from soil (mol-CO2 / m-2 / second)
  tco2root[npoi],     // instantaneous fine co2 flux from soil (mol-CO2 / m-2 / second)
  tneetot[npoi],      // instantaneous net ecosystem exchange of co2 per timestep (kg_C m-2/timestep)
  tnmin[npoi],        // instantaneous nitrogen mineralization (kg_N m-2/timestep)
  tnpptot[npoi],      // instantaneous npp (mol-CO2 / m-2 / second)
  tgpptot[npoi],      // instantaneous gpp (mol-CO2 / m-2 / second)
  totalit[npoi],      // total standing aboveground litter (kg_C m-2)
  totanlit[npoi],     // total standing aboveground nitrogen in litter (kg_N m-2)
  totcmic[npoi],      // total carbon residing in microbial pools (kg_C m-2)
  totcsoi[npoi],      // total carbon in all soil pools (kg_C m-2)
  totfall[npoi],      // total litterfall and root turnover (kg_C m-2/year)
  totlit[npoi],       // total carbon in all litter pools (kg_C m-2)
  totnlit[npoi],      // total nitrogen in all litter pools (kg_N m-2)
  totnmic[npoi],      // total nitrogen residing in microbial pool (kg_N m-2)
  totnsoi[npoi],      // total nitrogen in soil (kg_N m-2)
  totrlit[npoi],      // total root litter carbon belowground (kg_C m-2)
  totrnlit[npoi],     // total root litter nitrogen belowground (kg_N m-2)
  tempu[npoi],        // cold-phenology trigger for trees (non-dimensional)
  templ[npoi],        // cold-phenology trigger for grasses/shrubs (non-dimensional)
  dropu[npoi],        // drought-phenology trigger for trees (non-dimensional)
  dropls[npoi],       // drought-phenology trigger for shrubs (non-dimensional)
  dropl4[npoi],       // drought-phenology trigger for c4 grasses (non-dimensional)
  dropl3[npoi],       // drought-phenology trigger for c3 grasses (non-dimensional)
  dropc4[npoi],       // drought-phenology trigger for c4 crop (non-dimensional)   //14 C4crop  2012-06-09
  dropc3[npoi],       // drought-phenology trigger for c3 crop (non-dimensional)   //15 C3crop  2012-06-09
  vegtype0[npoi];     // annual vegetation type - ibis classification
  float
  cbiol[npoi][npft],  // carbon in leaf biomass pool (kg_C m-2)
  cbior[npoi][npft],  // carbon in fine root biomass pool (kg_C m-2)
  cbiow[npoi][npft],  // carbon in woody biomass pool (kg_C m-2)
  cpstore[npoi][npft],// carbon storage in plant stem/shoot system (kg_C m-2)
  crstore[npoi][npft],// carbon storage in plant root system (kg_C m-2)
  cpstoretot[npoi],   // sum C storage in plant stem/shoot
  crstoretot[npoi],   // sum C storage in plant root,
  harvctot[npoi],     // annual total harvest from C storage (above&below ground)
  harvntot[npoi];     // annual total harvest from N storage (above&below ground)
  float
  clitll[npoi],       // carbon in leaf litter pool - lignin          (kg_C m-2)
  clitlm[npoi],       // carbon in leaf litter pool - metabolic       (kg_C m-2)
  clitls[npoi],       // carbon in leaf litter pool - structural      (kg_C m-2)
  clitrl[npoi],       // carbon in fine root litter pool - lignin     (kg_C m-2)
  clitrm[npoi],       // carbon in fine root litter pool - metabolic  (kg_C m-2)
  clitrs[npoi],       // carbon in fine root litter pool - structural (kg_C m-2)
  clitwl[npoi],       // carbon in woody litter pool - lignin         (kg_C m-2)
  clitwm[npoi],       // carbon in woody litter pool - metabolic      (kg_C m-2)
  clitws[npoi],       // carbon in woody litter pool - structural     (kg_C m-2)
  csoipas[npoi],      // carbon in soil - passive humus               (kg_C m-2)
  csoislo[npoi],      // carbon in soil - slow humus                  (kg_C m-2)
  csoislon[npoi],     // carbon in soil - slow nonprotected humus     (kg_C m-2)
  csoislop[npoi],     // carbon in soil - slow protected humus        (kg_C m-2)
  decompl[npoi],      // litter decomposition factor                  (dimensionless)
  decomps[npoi],      // soil organic matter decomposition factor     (dimensionless)
  falll[npoi],        // annual leaf litter fall c                     (kg_C m-2/year)
  fallr[npoi],        // annual root litter input c                    (kg_C m-2/year)
  fallw[npoi],        // annual wood litter fall c                     (kg_C m-2/year)
  cdisturb[npoi],     // annual amount of vegetation carbon lost to atmosphere due to fire  (biomass burning) (kg_C m-2/year)
  cpasold[npoi];      // carbon in soil - passive humus, former step  (kg_C m-2)
  float
  biomass[npoi][npft],// total biomass of each plant functional type  (kg_C m-2)
  frac[npoi][npft],   // fraction of canopy occupied by each plant functional type
  plai[npoi][npft],   // total leaf area index of each plant functional type
  plaiold[npoi][npft],// total leaf area index of each plant functional type previous year
  tnpp[npoi][npft],   // instantaneous NPP for each pft (mol-CO2 / m-2 / second)
  tgpp[npoi][npft],   // instantaneous GPP for each pft (mol-CO2 / m-2 / second)
  pfrac[npoi][npft],  // fraction of land occupied by each plant functional type
  pplai[npoi][npft];  // real-time (daily-monthly) plai
  float
  lai[npoi][2],       // canopy single-sided leaf area index (area leaf/area veg)
  sai[npoi][2],       // current single-sided stem area index
  zbot[npoi][2],      // height of lowest branches above ground (m)
  ztop[npoi][2],      // height of plant top above ground (m)
  ztopmx[npoi][2];    // maximum annual height of plant top above ground (m)
  float
  orieh[2],           // fraction of leaf/stems with horizontal orientation
  oriev[2];           // fraction of leaf/stems with vertical
  float
  rhoveg[nband][2],    // reflectance of an average leaf/stem
  froot[npoi][nsoilay][2],    // fraction of root in soil layer
  exist[npoi][npft],   // probability of existence of each plant functional type in a gridcell
  cnvmax[npft],        //leaf c:n ratio at which Vmax is reached, I2
  cnleafavg[npoi];     //c:n of averaged total living leaf,       I2,I3
  float
  cnnpl[npoi][npft],   //c:n ratio of new plant leaf,             I2,I4
  cnnpw[npoi][npft],   //c:n ratio of new plant wood,             I2,I4
  cnnpr[npoi][npft],   //c:n ratio of new plant root,             I2,I4
  cnnlitl[npoi][npft], //c:n ratio of new leaf litter,            I2,I3
  cnnlitw[npoi][npft], //c:n ratio of new wood litter,            I2,I3
  cnnlitr[npoi][npft]; //c:n ratio of new root litter,            I2,I3
  float
  cnbiol[npoi][npft],  //c:n ratio of averaged plant leaf,        I2,I4
  cnbiow[npoi][npft],  //c:n ratio of averaged plant wood,        I2,I4
  cnbior[npoi][npft];  //c:n ratio of averaged plant root,        I2,I4
  float
  cnmove[npoi],        //cn ratio of SOM flux between soil pools,    I2
  cnmoveb[npoi],       //cn ratio of SOM flux to microbe pool,       I2
  cnmovep[npoi],       //cn ratio of SOM flux to protected pool,     I2
  cnmoven[npoi],       //cn ratio of SOM flux to non-protected pool, I2
  cnmoves[npoi];       //cn ratio of SOM flux to passive pool,       I2
  float
  cnlitlm,             //c:n ratio of leaf litter lignin material, cnr(7), constant,  I2
  cnlitls,             //c:n ratio of leaf litter lignin material, cnr(6), constant,  I2
  cnlitll,             //c:n ratio of leaf litter lignin material, cnr(5), constant,  I2
  cnlitrm,             //c:n ratio of leaf litter lignin material, cnr(7), constant,  I2
  cnlitrs,             //c:n ratio of leaf litter lignin material, cnr(6), constant,  I2
  cnlitrl,             //c:n ratio of leaf litter lignin material, cnr(5), constant,  I2
  cnlitwm,             //c:n ratio of leaf litter lignin material, cnr(7), constant,  I2
  cnlitws,             //c:n ratio of leaf litter lignin material, cnr(8), constant,  I2
  cnlitwl,             //c:n ratio of leaf litter lignin material, cnr(8), constant,  I2
  cnmicrobe[npoi],     //c:n ratio of microbe SOM pool,       cnrmin(1) -- cnrmax(1), I2
  cnsoipas[npoi],      //c:n ratio of passive SOM pool,       cnrmin(2) -- cnrmax(2), I2
  cnsoislop[npoi],     //c:n ratio of protected SOM pool,     cnrmin(3) -- cnrmax(3), I2
  cnsoislon[npoi];     //c:n ratio of non-protected SOM pool, cnrmin(4) -- cnrmax(4), I2

  float
  nm[npoi],           //soil mineral N, (g_N m-2),                I2,I3
  nlimitratio[npoi];  //N limitation ratio,                       I2
  float               // litter and SOM related
  nlitll[npoi],       // nitrogen in leaf litter pool - lignin,           I2
  nlitlm[npoi],       // nitrogen in leaf litter pool - metabolic,        I2
  nlitls[npoi],       // nitrogen in leaf litter pool - structural,       I2
  nlitrl[npoi],       // nitrogen in fine root litter pool - lignin,      I2
  nlitrm[npoi],       // nitrogen in fine root litter pool - metabolic,   I2
  nlitrs[npoi],       // nitrogen in fine root litter pool - structural,  I2
  nlitwl[npoi],       // nitrogen in woody litter pool - lignin,          I2
  nlitwm[npoi],       // nitrogen in woody litter pool - metabolic,       I2
  nlitws[npoi],       // nitrogen in woody litter pool - structural,      I2
  nsoipas[npoi],      // nitrogen in soil - passive humus,                I2
  nsoislo[npoi],      // nitrogen in soil - slow humus,                   I2
  nsoislon[npoi],     // nitrogen in soil - slow nonprotected humus,      I2
  nsoislop[npoi];     // nitrogen in soil - slow protected humus,         I2

  float
  npstore[npoi][npft],// N storage in plant,                       I2,I3,I4
  nrstore[npoi][npft],// N storage in plant root,                  I2,I3,I4
  npstoretot[npoi],   // sum N storage in plant stem/shoot      I2,I3,I4
  nrstoretot[npoi],   // sum N storage in plant root,           I2,I3,I4

  rawlitc[npoi],      //C in raw litter of each npoi,             I2,I3
  falllitc[npoi],     //C in natural litterfall
  firelitc[npoi],     //C in fire induced litter
  lcclitc[npoi],      //C in lcc induced litter
  deadwdc[npoi],      //C in dead wood,
  stdwdc[npoi],       //C in dead wood,
  cbiotot[npoi],      //C in biomass of each npoi,                I2
  totceco[npoi],      //C in ecosystem of each npoi,              I2
  rawlitn[npoi],      //N in raw litter of each npoi,             I2,I3
  falllitn[npoi],     //N in natural litterfall
  firelitn[npoi],     //N in fire induced litter
  lcclitn[npoi],      //N in lcc induced litter
  deadwdn[npoi],      //N in dead wood,
  stdwdn[npoi],       //N in dead wood,
  nbiotot[npoi],      //N in biomass of each npoi,                I2
  totneco[npoi],      //N in ecosystem of each npoi,              I2

  cbiolold[npoi][npft], //internal C in leaf,                      I2,I3
  cbiowold[npoi][npft], //internal C in wood,                      I2,I3
  cbiorold[npoi][npft], //internal C in root,                      I2,I3
  nbiolold[npoi][npft], //internal N in leaf,                      I2,I3
  nbiowold[npoi][npft], //internal N in wood,                      I2,I3
  nbiorold[npoi][npft], //internal N in root,                      I2,I3

  nbiol[npoi][npft],   //N in leaf,                                I2,I3,I4
  nbiow[npoi][npft],   //N in wood,                                I2,I3,I4
  nbior[npoi][npft],   //N in root,                                I2,I3,I4

  totnin[npoi];        //N daily input from raw litter to SOM,     I2
  float      // litterfall related
  falllc[npoi][npft],  //C of new leaf litter,                     I3
  fallwc[npoi][npft],  //C of new wood litter,                     I3
  fallrc[npoi][npft],  //C of new root litter,                     I3
  fallln[npoi][npft],  //N of new leaf litter,                     I3
  fallwn[npoi][npft],  //N of new wood litter,                     I3
  fallrn[npoi][npft],  //N of new root litter,                     I3

  falnl[npoi],        // annual leaf litter fall N,  (kg_C m-2 yr-1),   I2,I3
  falnr[npoi],        // annual root litter input N, (kg_C m-2 yr-1),   I2,I3
  falnw[npoi],        // annual wood litter fall N,  (kg_C m-2 yr-1),   I2,I3
  nfallyr[npoi];      //annual litterfall N,         (kg_N m-2 yr-1),   I2
  float      // NPP related
  adgpp[npoi][npft],  //daily gpp for each pft,         (kg_C m-2 d-1), I2,I4
  adgpptot[npoi],     //daily gpp for each land point,  (kg_C m-2 d-1), I2
  adnpp[npoi][npft],  //daily npp for each pft,         (kg_C m-2 d-1), I2,I4
  adnpptot[npoi],     //daily npp for each land point,  (kg_C m-2 d-1), I2
  darknpp[npoi][npft],//negtive NPP term, a pool,       (kg_C m-2),     I2,I4
  nused,              //daily N needed for daily npp,   (kg_N m-2 d-1), I4
  nuptake,            //daily N uptake by each pft,     (kg_N m-2 d-1), I2
  nuptot[npoi],       //daily N uptake by all pfts,     (kg_N m-2 d-1), I2,I4
  nuptotyr[npoi],     //annual N uptake by plant,       (kg_N m-2 yr-1),I2
  nppntot[npoi],      //N in npp term, yearly,          (kg_N m-2 yr-1),I2,I4
  nppnleaf[npoi][npft],//N in npp term, yearly,         (kg_N m-2 yr-1),I2,I4
  nppnwood[npoi][npft],//N in npp term, yearly,         (kg_N m-2 yr-1),I2,I4
  nppnroot[npoi][npft],//N in npp term, yearly,         (kg_N m-2 yr-1),I2,I4
  nppleaf[npoi][npft], //C in npp term, yearly,         (kg_C m-2 yr-1),I2,I4
  nppwood[npoi][npft], //C in npp term, yearly,         (kg_C m-2 yr-1),I2,I4
  npproot[npoi][npft]; //C in npp term, yearly,         (kg_C m-2 yr-1),I2,I4

  float      // ecosystem N inpu/output
  nleach[npoi],       //original model defined variable in biogeochem.f
  ndep_ref[npoi],     // N deposition reference layer,  (g_N m-2 d-1),  I2
  ndep1984[npoi],     //1984 N deposition,              (g_N m-2 d-1),  I2
  nh4dep[npoi],       //N deposition,                   (kg_N ha-1 yr-1)
  no3dep[npoi],       //1984 N deposition,              (kg_N ha-1 yr-1)
  ndeptot[npoi],      //annual N depositio,             (g_N m-2 yr-1), I2
  nfixtot[npoi],      //annual N fixsation,             (g_N m-2 yr-1), I2
  nmleach,            //mineral N leached,              (g_N m-2 yr-1), I2
  nmleachtot[npoi],   //annual mineral N leaching       (g_N m-2 yr-1), I2
  nvolattot[npoi],    //N volatition,                   (g_N m-2 yr-1), I2
  ndisturb[npoi];     //N loss due to disturbance,      (kg_N m-2 yr-1),I3
  float
  soilcap[npoi],      //maximum soil C allowed on the pixel, (kg_C m-2),I2
  capafac[npoi],      //paremeter to increase decomposition if soil C too much
  nm3d[npoi],         // averaged/smoothed 3 day nm value
  prec10d[npoi],
  aytsoi3y[npoi],
  clossl[npoi],
  clossw[npoi],
  clossr[npoi],
  nlossl[npoi],
  nlossw[npoi],
  nlossr[npoi],
  cmortl[npoi],
  cmortr[npoi],
  cmortw[npoi],
  nmortl[npoi],
  nmortr[npoi],
  nmortw[npoi],
  aleafroot[npft],
  arootmax[npft],
  arootmin[npft],
  totwdu[npoi],       //total wood upper layer
  totlfu[npoi],       //total leaf upper layer
  totrtu[npoi],       //total root upper layer
  totwdl[npoi],       //total wood lower layer
  totlfl[npoi],       //total leaf lower layer
  totrtl[npoi];       //total root lower layer
  int
  cropid[npoi];       //up to 10 crop types

  float
  c4crop[npoi],             //composition of c4 crops
  c4gindex[npoi],           //weighted average of gindex for C4 crops
  c4hindex[npoi],           //weighted average of hindex for C4 crops
  c4straw[npoi],            //weighted average of straw removal ratio for C4 crops
  c3crop[npoi],             //composition of c3 crops
  c3gindex[npoi],           //weighted average of gindex for C3 crops
  c3hindex[npoi],           //weighted average of hindex for C3 crops
  c3straw[npoi],            //weighted average of straw removal ratio for C3 crops
  c3c4frac[npoi],           //ralative fraction between C3 and C4 crops
  cgrain[npoi],             //grain C production/removal each year
  ngrain[npoi],             //grain N production/removal each year
  strawc[npoi],             //straw C production/removal each year
  strawn[npoi],             //straw N production/removal each year
  ferttot[npoi],            //N fertilization amount each year
  fertin[npoi],             //manual N fertilization amount each year
  aufert;                   //ratio of auto fertilization, a proportion to N uptake

  float
  tbgindex[npoi],           //broadleaf tree gindex
  tcgindex[npoi],           //conifer tree gindex
  sbgindex[npoi],           //shrub gindex
  g4gindex[npoi],           //C4 grass gindex
  g3gindex[npoi],           //C3 grass gindex
  wtnindex[npoi],           //wood turnover rate index
  socindex[npoi];           //soil carbon change index

  float
  livc2std[npoi], // live woody to standing dead wood pool, annual rate
  livc2down[npoi],// live woody to down dead wood pool, annual rate
  raw2lit[npoi],  // raw litter c transfered to litter pool
  down2lit[npoi], // down deadwood c transfered to litter pool
  outlit[npoi],   // total litter c transfered out from litter pool
  lit2soc[npoi],  // litter c transfered to soc
  lit2co2[npoi],  // co2 emission from litter
  outsoc[npoi],   // total soc transfered out from soc pool, including internal transfer
  soc2soc[npoi],  // soc internal c transfer
  soc2co2[npoi];  // co2 emission from soc

/* from comsoi.h, for reading parameters in paramsx.soi */
  float
  hsoi[nsoilay+1],         // soil layer thickness (m)
  bperm,                   // lower b.c. for soil profile drainage
  wpudmax,                 // normalization constant for puddles (kg m-2)
  zwpmax;                  // assumed maximum fraction of soil surface

/* from comsoi.h, for variables*/
  float
  fleach;                  // fraction of soil water leached (daily)
  float
  wpud[npoi],              // liquid content of puddles per soil area (kg m-2)
  wipud[npoi],             // ice content of puddles per soil area (kg m-2)
  z0soi[npoi],             // roughness length of soil surface (m)
  albsav[npoi],            // saturated soil surface albedo (visible waveband)
  albsan[npoi],            // saturated soil surface albedo (near-ir waveband)
  stresstl[npoi],          // sum of stressl over all 6 soil layers (dimensionless)
  stresstu[npoi],          // sum of stressu over all 6 soil layers (dimensionless)
  heati[npoi],             // net heat flux into snow surface (W m-2)
  heatg[npoi],             // net heat flux into soil surface (W m-2)
  hvasug[npoi],            // latent heat of vap/subl, for soil surface (J kg-1)
  hvasui[npoi],            // latent heat of vap/subl, for snow surface (J kg-1)
  tg[npoi],                // soil skin temperature (K)
  ti[npoi];                // snow skin temperature (K)
  int
  totlyr[npoi];            // actual total soil layer, maximum = nsoilay
  float
  tsoi[npoi][nsoilay],      // soil temperature for each layer (K)
  wsoi[npoi][nsoilay],      // fraction of soil pore space containing liquid water
  wisoi[npoi][nsoilay],     // fraction of soil pore space containing ice
  consoi[npoi][nsoilay],    // thermal conductivity of each soil layer (W m-1 K-1)
  csoi[npoi][nsoilay],      // specific heat of soil, no pore spaces (J kg-1 deg-1)
  hydraul[npoi][nsoilay],   // saturated hydraulic conductivity (m/s)
  suction[npoi][nsoilay],   // saturated matric potential (m-h2o)
  bex[npoi][nsoilay],       // exponent "b" in soil water potential
  sfield[npoi][nsoilay],    // field capacity soil moisture value (fraction of pore space)
  swilt[npoi][nsoilay],     // wilting soil moisture value (fraction of pore space)
  rhosoi[npoi][nsoilay],    // soil density (without pores, not bulk) (kg m-3)
  poros[npoi][nsoilay],     // porosity (mass of h2o per unit vol at sat / rhow)
  porosflo[npoi][nsoilay],  // porosity after reduction by ice content
  sandpct[npoi][nsoilay],   // percent sand of soil from input file
  claypct[npoi][nsoilay],   // percent clay of soil from input file
  sand[npoi][nsoilay],      // percent sand of soil
  clay[npoi][nsoilay],      // percent clay of soil
  stressl[npoi][nsoilay],   // soil moisture stress factor for the lower canopy (dimensionless)
  stressu[npoi][nsoilay],   // soil moisture stress factor for the upper canopy (dimensionless)
  upsoiu[npoi][nsoilay],    // soil water uptake from transpiration (kg_h2o m-2 s-1)
  upsoil[npoi][nsoilay];    // soil water uptake from transpiration (kg_h2o m-2 s-1)
  float
  hflo[npoi][nsoilay+1];    // downward heat transport through soil layers (W m-2)
  int
  ibex[npoi][nsoilay];      // nint(bex), used for cpu speed
  float
  qglif[npoi][4];           // 1: fraction of soil evap (fvapg) from soil liquid

/* from comtex.h, for reading parameters in paramsx.soi */
  float
  texdat[3][ndat],  // sand/silt/clay fractions
  porosdat[ndat],   // porosity volume fraction
  sfielddat[ndat],  // field capacity volume fraction
  swiltdat[ndat],   // wilting point volume fraction
  bexdat[ndat],     // Campbell moisture-release b exponent
  suctiondat[ndat], // Air entry potential (m-H20)
  hydrauldat[ndat]; // saturated hydraulic conductivity (m s-1)

/* from combgc.h, for reading parameters in paramsx.soi */
  float
  lig_frac,   // split of lignified litter material between protected/non-protected slow OM pools
  fbsom,      // protected biomass as a fraction of total soil organic C from Verberne et al., 1990
  effac,      // efficiency of microbial biomass reincorporated into biomass pool.
  cnr[10],    // C:N ratios of substrate pools and biomass for leaves and roots.
  ffmax,       // maximum fraction allowed in resistant fraction (Verbene 1997)
  rconst;     // constant defined as 1200 (from Verbene 1997 equations)

  float
  klm,          // leaf metabolic litter
  kls,          // leaf structural litter
  kll,          // leaf lignin
  krm,          // root metabolic litter
  krs,          // root structural litter
  krl,          // root lignin
  kwm,          // woody metabolic litter
  kws,          // woody structural litter
  kwl,          // wood  lignin

  kbn,          // microbial biomass --> nonprotected om
  kbp,          // microbial biomass --> protected om
  knb,          // nonprotected om   --> biomass
  kns,          // nonprotected om   --> passive c
  kpb,          // protected om      --> biomass
  kps,          // protected om      --> passive c
  ksb;          // passive c         --> biomass

  float
  ylm,          // leaf metabolic litter decomposition
  yrm,          // root metabolic litter decomposition
  ywm,          // woody metabolic litter decomposition
  yls,          // leaf structural litter decomposition
  yrs,          // root structural litter decomposition
  yws,          // woody structural litter decomposition
  yll,          // leaf lignin
  yrl,          // root lignin
  ywl,          // wood lignin

  ybn,          // microbial biomass to nonprotected om
  ybp,          // microbial biomass to protected om
  yps,          // protected om to passive c
  yns,          // nonprotected om to passive  c
  ysb,          // passive c to biomass
  ypb,          // protected om to biomass
  ynb;          // nonprotected om to biomass

/* from comfire.h, for reading parameters in params.dis */
  float
  combsoil[5][4],  //MTBS soil combustion level 0-x1-x2-100, three classes
  comblev[6][4],   //MTBS veg combustion level 0-x1-x2-100, three classes
  mortlev[4][4],   //MTBS veg mortality factor 0-x1-x2-100, three classes
  forharv[12][5],  //forest harvest ratio by ecoregion and year
  defor[12][5];     //deforestation ratio by ecoregion and year

/* from comfire.h, for variables */
  float
  moe[npft],       // PFT moisture of extinction parameters...
  combust[ndist][npft][npart],      //combustion factor
  mortlity[ndist][npft][npart],     //mortality factor
  vegcomb[npoi],   //vegetation combustion amount kg/m2/yr
  litcomb[npoi],   //soil litter combustion amount kg/m2/yr
  miccomb[npoi],   //soil imicrobe pool combustion amount kg/m2/yr
  sloncomb[npoi],  //soil slow non-protected pool combustion amount kg/m2/yr
  slopcomb[npoi],  //soil slow protected pool combustion amount kg/m2/yr
  pascomb[npoi],   //soil passive pool combustion amount kg/m2/yr
  soilcomb[npoi],  //total soil combustion amount kg/m2/yr
  soilncomb[npoi], //total soil nitrogen combustion amount kg/m2/yr
  firemort[npoi],  //mortality of trees in carbon kg/m2/yr
  charcoal[npoi],  //charcoal production from fire kg/m2/yr
  fireyear[npoi],  //number of years after fire event
  deleyyear[npoi], //number of years deleyed for regeneration after fire event
  stdwcloss[npoi], //standing dead wood C falling down rate to down dead wood
  stdwnloss[npoi], //standing dead wood N falling down rate to down dead wood
  lccmort[npoi],   //land cover change induced mortality carbon kg/m2/yr
  thining[npoi],   //thinging carbon removal kg/m2/yr
  logging[npoi],   //rotational logging carbon loss kg/m2/yr
  loggyear[npoi],  //number of years after stand-replacing log/harvest event
  deforsg[npoi],   //forest to shrub and grass carbon loss kg/m2/yr
  deforag[npoi],   //forest to agriculture carbon loss kg/m2/yr
  furban[npoi],    //forest to urban-barran carbon loss kg/m2/yr
  sgurban[npoi];   //shrub-grass to urban-barran carbon loss kg/m2/yr
  int
  bamboo1[npoi],   //bamboo map value at time x1
  bamboo2[npoi],   //bamboo map value at time x2
  bamboo[npoi];    //flag, bamboo true=1, false=0

/* from compar.h, for reading parameters in paramsx.map */
  int 
  map1ncol, map1nrow,  // hi-res map columns and rows
  map2ncol, map2nrow,  // coarse map columns and rows
  map3ncol, map3nrow,  // coarse map columns and rows
  map4ncol, map4nrow,  // coarse map columns and rows
  map5ncol, map5nrow;  // coarse map columns and rows

int
  map1res, map1left, map1right, map1upper, map1lower, //hi-res map coordinates
  map2res, map2left, map2right, map2upper, map2lower, //coarse map coordinates
  map3res, map3left, map3right, map3upper, map3lower, //coarse map coordinates
  map4res, map4left, map4right, map4upper, map4lower, //coarse map coordinates
  map5res, map5left, map5right, map5upper, map5lower; //coarse map coordinates

/* from compar.h, for variables */
  float
  epsilon,       // small quantity to avoid zero-divides
  //dtime,         // model timestep (seconds)
  zweight,
  stef,          // stefan-boltzmann constant (W m-2 K-4)
  vonk,          // von karman constant (dimensionless)
  grav,          // gravitational acceleration (m s-2)
  tmelt,         // freezing point of water (K)
  hfus,          // latent heat of fusion of water (J kg-1)
  hvap,          // latent heat of vaporization of water (J kg-1)
  hsub,          // latent heat of sublimation of ice (J kg-1)
  ch2o,          // specific heat of liquid water (J deg-1 kg-1)
  cice,          // specific heat of ice (J deg-1 kg-1)
  cair,          // specific heat of dry air at constant pressure (J deg-1 kg-1)
  cvap,          // specific heat of water vapor at constant pressure (J deg-1 kg-1)
  rair,          // gas constant for dry air (J deg-1 kg-1)
  rvap,          // gas constant for water vapor (J deg-1 kg-1)
  cappa,         // rair/cair
  rhow,          // density of liquid water (all types) (kg m-3)
  startlon,      // base location
  startlat,      // base location
  endlon,        // base location
  endlat;        // base location

  float
  garea[npoi],   // area of each gridcell (m**2)
  vzero[npoi],   // a real array of zeros, of length npoi
  landcl[npoi];  // a real array to hold landclass info.c

  int
  ndaypy,        // number of days per year
  nlonsub,       // number of longitude points for subsetting
  nlatsub,       // number of latitude points for subsetting
  nlonsubs,      // number of longitude points for subsetting, by scale
  nlatsubs,      // number of latitude points for subsetting, by scale
  nclust,        // number of cluster, no larger then npoi
  cluster,       // flag indicating polygon simulation
  events,        // starting year of LULCC/disturbance, 0 = no LULCC
  lccfrom[npoi], // land cover change from (which type)
  lccto[npoi],   // land cover change to (which type)
  lcctime[npoi], // land cover change to (which type)
  lcclen[npoi],  // time length to keep the change (then merge to other type)
  lccflag[npoi], // a lcc flag
  rowscale,      // sampling interval by row, 1=wall-to-wall
  colscale,      // sampling interval by col, 1=wall-to-wall
  istart[4],     // map1 start, e.g. 250m map
  icount[4],     // map1 count
  istartx[4],    // map2 start, e.g. 10km map
  icountx[4],    // map2 count
  map1area,      // land cover map area
  map2area,      // soil map area
  map3area,      // climate map area
  map4area,      // climate/other map area
  map5area;      // cliamte/other map area

  int
  ndaypm[12],    // number of days per month
  idies,         // netcdf file indice
  istat,         // netcdf error flag
  nyears,        // this is the nth year since simulation
  mstep;         // this is time step for netcdf file
  char cdate[10];        // date to use in history attribute in files
  char tdate[10];        // character date for time step
  char tunits[21];       // time units

/* from combcs.h, for reading parameters in paramsx.scl */
  int 
  fipscode[nfips];

/* from comghg.h, for reading parameters in paramsx.ghg */
  float  
  RBOX,
  FD,
  MUEMAX,
  AMAX,
  AMAXX,
  KNI,
  EFFAC_D,
  rcnb;

  float
  MUE_NO3,
  MUE_NO2,
  MUE_NO,
  MUE_N2O,
  MNO3,
  MNO2;

  float
  MNO,
  MN2O,
  EFF_NO3,
  EFF_NO2,
  EFF_NO,
  EFF_N2O,
  KICE,
  KCI;

  float
  D_O2,
  LH,
  SD,
  F_aerenchyma,
  Atm_CH4;

/* from comghg.h, for variables */
  float
  B_RiceWet[npoi],  // bool variable to identify the grid is rice paddy, wetland or not
  WetlandFra[npoi]; // wetland fraction in each pixel

#endif

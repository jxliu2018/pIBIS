rm *.o
rm outfile*
rm *.dat
rm *.nc
rm sum_*.txt
rm *temp.txt
ls -lrt


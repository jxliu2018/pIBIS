#### convert netcdf_m.data to raw binery_m.data
go xcovmax_m.nc xcovmax covmax.dat
go ecoreg_m.nc ecoreg ecoreg.dat
go fips_m.nc fips fips.dat
go fu_m.nc fu fu.dat
#### do region summary
fipsum_ibis_102615 covmax_m.nc covmax ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 fu_m.nc fu ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 cbiotot_m.nc cbiotot ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 totbiou_m.nc totbiou ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 totcsoi_m.nc totcsoi ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 stddown_m.nc stddown ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 cgrain_m.nc cgrain ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 vegtype0_m.nc vegtype0 ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 aynpptot_m.nc aynpptot ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6 

fipsum_ibis_102615 totlit_m.nc totlit ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 ayneetot_m.nc ayneetot ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 aynbp_m.nc aynbp ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6 
fipsum_ibis_102615 ayCH4_m.nc ayCH4 ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6 
fipsum_ibis_102615 ayn2oflux_m.nc ayn2oflux ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6 
fipsum_ibis_102615 gdd5this_m.nc gdd5this ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 ayprcp_m.nc ayprcp ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 totceco_m.nc totceco ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 yrleach_m.nc yrleach ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6

fipsum_ibis_102615 xdist_m.nc xdist ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 logging_m.nc logging ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 soilcomb_m.nc soilcomb ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 vegcomb_m.nc vegcomb ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 strawc_m.nc strawc ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 deadcrem_m.nc deadcrem ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 livecrem_m.nc livecrem ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 cdisturb_m.nc cdisturb ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 totwdl_m.nc totwdl ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 stdwdc_m.nc stdwdc ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6

fipsum_ibis_102615 rawlitc_m.nc rawlitc ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 fallw_m.nc fallw ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 livc2std_m.nc livc2std ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 livc2down_m.nc livc2down ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 stdwcloss_m.nc stdwcloss ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 down2lit_m.nc down2lit ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 lit2co2_m.nc lit2co2 ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 lit2soc_m.nc lit2soc ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 soc2co2_m.nc soc2co2 ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
fipsum_ibis_102615 raw2lit_m.nc raw2lit ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6

sum_all_10000 p_list_sum_all_CONUSx.asc
tar czf sum_covmax6.tar.gz sum_*.txt 

#fipsum_ibis_102615 aynpptotu_m.nc aynpptotu ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 charcoal_m.nc charcoal ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 cmortw_m.nc cmortw ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 deadwdc_m.nc deadwdc ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 deforag_m.nc deforag ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 deforsg_m.nc deforsg ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 firemort_m.nc firemort ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 fl_m.nc fl ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 furban_m.nc furban ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 gdd5_m.nc gdd5 ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 lcchist_m.nc lcc ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 lccmort_m.nc lccmort ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 loggyear_m.nc loggyear ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 outlit_m.nc outlit ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 outsoc_m.nc outsoc ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 raw2lit_m.nc raw2lit ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 sgurban_m.nc sgurban ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 soc2soc_m.nc soc2soc ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 tcmin_m.nc tcmin ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 totbiol_m.nc totbiol ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 totlail_m.nc totlail ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 totlaiu_m.nc totlaiu ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 totwdu_m.nc totwdu ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 falllitc_m.nc falllitc ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 firelitc_m.nc firelitc ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 lcclitc_m.nc lcclitc ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 cfruit_m.nc cfruit ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6
#fipsum_ibis_102615 csoislow_m.nc csoislow ecoreg.dat float 1018 1608 1 115 covmax.dat 6 6

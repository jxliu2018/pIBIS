sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc fips.nc fips fips_m.nc
#tar czf fips_m.nc.tar.gz fips_m.nc 
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc ecoreg.nc ecoreg ecoreg_m.nc
#tar czf ecoreg_m.nc.tar.gz ecoreg_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc xcovmax.nc xcovmax xcovmax_m.nc
tar czf xcovmax_m.nc.tar.gz xcovmax_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc fu.nc fu fu_m.nc
tar czf fu_m.nc.tar.gz fu_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc vegtype0.nc vegtype0 vegtype0_m.nc
tar czf vegtype0_m.nc.tar.gz vegtype0_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc cbiotot.nc cbiotot cbiotot_m.nc
tar czf cbiotot_m.nc.tar.gz cbiotot_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc totbiou.nc totbiou totbiou_m.nc
tar czf totbiou_m.nc.tar.gz totbiou_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc totcsoi.nc totcsoi totcsoi_m.nc
tar czf totcsoi_m.nc.tar.gz totcsoi_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc stddown.nc stddown stddown_m.nc
tar czf stddown_m.nc.tar.gz stddown_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc cgrain.nc cgrain cgrain_m.nc
tar czf cgrain_m.nc.tar.gz cgrain_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc aynpptot.nc aynpptot aynpptot_m.nc
tar czf aynpptot_m.nc.tar.gz aynpptot_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc totlit.nc totlit totlit_m.nc
tar czf totlit_m.nc.tar.gz totlit_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc ayneetot.nc ayneetot ayneetot_m.nc
tar czf ayneetot_m.nc.tar.gz ayneetot_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc aynbp.nc aynbp aynbp_m.nc
tar czf aynbp_m.nc.tar.gz aynbp_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc ayCH4.nc ayCH4 ayCH4_m.nc
tar czf ayCH4_m.nc.tar.gz ayCH4_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc ayn2oflux.nc ayn2oflux ayn2oflux_m.nc
tar czf ayn2oflux_m.nc.tar.gz ayn2oflux_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc gdd5this.nc gdd5this gdd5this_m.nc
tar czf gdd5this_m.nc.tar.gz gdd5this_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc ayprcp.nc ayprcp ayprcp_m.nc
tar czf ayprcp_m.nc.tar.gz ayprcp_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc totceco.nc totceco totceco_m.nc
tar czf totceco_m.nc.tar.gz totceco_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc yrleach.nc yrleach yrleach_m.nc
tar czf yrleach_m.nc.tar.gz yrleach_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc xdist.nc xdist xdist_m.nc
tar czf xdist_m.nc.tar.gz xdist_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc logging.nc logging logging_m.nc
tar czf logging_m.nc.tar.gz logging_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc soilcomb.nc soilcomb soilcomb_m.nc
tar czf soilcomb_m.nc.tar.gz soilcomb_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc vegcomb.nc vegcomb vegcomb_m.nc
tar czf vegcomb_m.nc.tar.gz vegcomb_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc strawc.nc strawc strawc_m.nc
tar czf strawc_m.nc.tar.gz strawc_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc deadcrem.nc deadcrem deadcrem_m.nc
tar czf deadcrem_m.nc.tar.gz deadcrem_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc livecrem.nc livecrem livecrem_m.nc
tar czf livecrem_m.nc.tar.gz livecrem_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc cdisturb.nc cdisturb cdisturb_m.nc
tar czf cdisturb_m.nc.tar.gz cdisturb_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc totwdl.nc totwdl totwdl_m.nc
tar czf totwdl_m.nc.tar.gz totwdl_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc stdwdc.nc stdwdc stdwdc_m.nc
tar czf stdwdc_m.nc.tar.gz stdwdc_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc rawlitc.nc rawlitc rawlitc_m.nc
tar czf rawlitc_m.nc.tar.gz rawlitc_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc fallw.nc fallw fallw_m.nc
tar czf fallw_m.nc.tar.gz fallw_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc livc2std.nc livc2std livc2std_m.nc
tar czf livc2std_m.nc.tar.gz livc2std_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc livc2down.nc livc2down livc2down_m.nc
tar czf livc2down_m.nc.tar.gz livc2down_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc stdwcloss.nc stdwcloss stdwcloss_m.nc
tar czf stdwcloss_m.nc.tar.gz stdwcloss_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc down2lit.nc down2lit down2lit_m.nc
tar czf down2lit_m.nc.tar.gz down2lit_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc lit2co2.nc lit2co2 lit2co2_m.nc
tar czf lit2co2_m.nc.tar.gz lit2co2_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc lit2soc.nc lit2soc lit2soc_m.nc
tar czf lit2soc_m.nc.tar.gz lit2soc_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc soc2co2.nc soc2co2 soc2co2_m.nc
tar czf soc2co2_m.nc.tar.gz soc2co2_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc raw2lit.nc raw2lit raw2lit_m.nc
tar czf raw2lit_m.nc.tar.gz raw2lit_m.nc


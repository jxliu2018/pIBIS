#### convert netcdf_m.data to raw binery_m.data
go fips.nc fips fips.dat
go ecoreg.nc ecoreg ecoreg.dat
go xcovmax.nc xcovmax covmax.dat
go fu.nc fu fu.dat

#### for calibration purpose
# nc_interp_samp conus_pct_agr960m_schar.nc pct_agr p_list_nc_interp_local.asc
# mv conus_pct_agr960m_schar.nc_x.dat local_pct_agr960m_schar.datx

cp -p cgrain.nc cgrain_m_calib.nc
cp -p aynpptot.nc aynpptot_m_calib.nc
cp -p totbiou.nc totbiou_m_calib.nc
cp -p stddown.nc stddown_m_calib.nc

fipsum_ibis_pct_112015 cgrain_m_calib.nc cgrain fips.dat float 226 180 1 115 covmax.dat 2 2 local_pct_agr960m_schar.datx 11 100
fipsum_biom_ibis_102615 totbiou_m_calib.nc totbiou fips.dat float 226 180 1 115 fu.dat 0.5 1.0
fipsum_biom_ibis_102615 stddown_m_calib.nc stddown fips.dat float 226 180 1 115 fu.dat 0.5 1.0

#fipsum_ibis_pct_112015 cgrain_m_calib.nc cgrain ecoreg.dat float 226 180 1 115 covmax.dat 2 2 local_pct_agr960m_schar.datx 11 100
#fipsum_biom_ibis_102615 totbiou_m_calib.nc totbiou ecoreg.dat float 226 180 1 115 fu.dat 0.5 1.0
#fipsum_biom_ibis_102615 stddown_m_calib.nc stddown ecoreg.dat float 226 180 1 115 fu.dat 0.5 1.0

fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot fips.dat float 226 180 1 115 fu.dat 0.5 1.0
mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.f
fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot fips.dat float 226 180 1 115 covmax.dat 3 3
mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.s
fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot fips.dat float 226 180 1 115 covmax.dat 4 4
mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.g
fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot fips.dat float 226 180 1 115 covmax.dat 2 2
mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.c

#fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot ecoreg.dat float 226 180 1 115 fu.dat 0.5 1.0
#mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.f
#fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot ecoreg.dat float 226 180 1 115 covmax.dat 3 3
#mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.s
#fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot ecoreg.dat float 226 180 1 115 covmax.dat 4 4
#mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.g
#fipsum_ibis_102615 aynpptot_m_calib.nc aynpptot ecoreg.dat float 226 180 1 115 covmax.dat 2 2
#mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.c

#cp -p paramsx.scl.conus84.base CONUS_scalers.txt
#cp -p CONUS_scalers_base.txt CONUS_scalers.txt
cp -p paramsx.scl CONUS_scalers.txt
scalers_ibis.120216 p_list_scalers_local.asc
tar czf calib_x.tar.gz *_temp.txt *m_calib.nc.txt* ibis.infile paramsx.scl
 



#ifndef nc_interp_sampH
#define nc_interp_sampH
#include "netcdf.h"

//called from main.c
void interp_samp_float(float *, float *, float *, int, int);
void interp_samp_int(int *, float *, float *, int, int);
void interp_samp_char(char *, float *, float *, int, int);
void writeDat(float *, char *, int, int);
void writex4(float *, char *, char *, char *, char *, char names[][100], int *dim_data[], size_t *startx, size_t *countx);

//called from io-netcdf.c
void GetNCInfo(char *ncfilename);
void CreateNCFile(char *ncfilename, char names[][100], size_t *start, size_t *count, int *dim_data[]);
void CreateNCVar(char *ncfilename, char *ncvarname, nc_type nctype, int ndims, char ncvar_dimnames[][100]);
void WriteNCVara(char *ncfilename, char *ncvarname, nc_type nctype, size_t *start, size_t *count, void *tp);
void ReadNCVara(char *ncfilename, char *ncvarname, nc_type nctype, size_t *start, size_t *count, void *tp);
void SetNCAttribute(char *ncfilename, char *ncvarname, char *attname, nc_type nctype, char *att, float floatval);

/* variables used in ncvar.c*/
  size_t start_g[4], count_g[4];
  int offrow, offrowx, offcol, offcolx; 
  int array_size1, array_size, array_size_interp, array_size_samp;
  int layers;

  size_t start_g1[4], count_g1[4];
  int *map1_id;
  int *map2_id;
  int *map3_id;
  int *map4_id;

/* netcdf read-in related variables */
  char *data_char;
  int *data_int;
  float *data_float;

/* common data array */
  float *data_interp;
  float *data_samp;

/* several global scope variables*/
  char nc_variable[50], nc_infile[200], nc_outfile[200], dat_outfile[200];
  int totrows, totcols, total_npoi;
  int total_segment, segment_id, segment_npoi, start_loc, start_loc_new;
  int layerx, remx, map1size, map2size, map3size, map4size, mapSsize;

/* for simulation control ibis.infile */
  int
  snorth,     //northern latitude for subsetting in/ouput
  ssouth,     //southern latitude for subsetting in/ouput
  swest,      //western longitude for subsetting in/ouput
  seast,      //eastern longitude for subsetting in/ouput
  rowscale,   //row sampling interval (rowscale)
  colscale;   //column sampling interval (colscale)

/* from compar.h, for reading parameters in paramsx.map */
  int 
  map1ncol, map1nrow,  // hi-res map columns and rows
  map2ncol, map2nrow,  // coarse map columns and rows
  map3ncol, map3nrow,  // coarse map columns and rows
  map4ncol, map4nrow;  // coarse map columns and rows

int
  map1res, map1left, map1right, map1upper, map1lower, //hi-res map coordinates
  map2res, map2left, map2right, map2upper, map2lower, //coarse map coordinates
  map3res, map3left, map3right, map3upper, map3lower, //coarse map coordinates
  map4res, map4left, map4right, map4upper, map4lower; //coarse map coordinates

/* from compar.h, for variables */
int
  startlon,
  startlat,
  endlon,
  endlat,
  nlonsub,
  nlatsub,
  nlonsubs,
  nlatsubs,
  istart[4],     // map1 start, e.g. 250m map
  icount[4],     // map1 count
  istartx[4],    // map2 start, e.g. 10km map
  icountx[4],    // map2 count
  map1area,      // land cover map area
  map2area,      // soil map area
  map3area,      // climate map area
  map4area;      // climate/other map area

#endif

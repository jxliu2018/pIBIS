sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc fips.nc fips fips_m.nc
#tar czf fips_m.nc.tar.gz fips_m.nc 
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc ecoreg.nc ecoreg ecoreg_m.nc
#tar czf ecoreg_m.nc.tar.gz ecoreg_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc xcovmax.nc xcovmax xcovmax_m.nc
tar czf xcovmax_m.nc.tar.gz xcovmax_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc fu.nc fu fu_m.nc
tar czf fu_m.nc.tar.gz fu_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc vegtype0.nc vegtype0 vegtype0_m.nc
tar czf vegtype0_m.nc.tar.gz vegtype0_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc cbiotot.nc cbiotot cbiotot_m.nc
tar czf cbiotot_m.nc.tar.gz cbiotot_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc totbiou.nc totbiou totbiou_m.nc
tar czf totbiou_m.nc.tar.gz totbiou_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc totcsoi.nc totcsoi totcsoi_m.nc
tar czf totcsoi_m.nc.tar.gz totcsoi_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc stddown.nc stddown stddown_m.nc
tar czf stddown_m.nc.tar.gz stddown_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc cgrain.nc cgrain cgrain_m.nc
tar czf cgrain_m.nc.tar.gz cgrain_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc aynpptot.nc aynpptot aynpptot_m.nc
tar czf aynpptot_m.nc.tar.gz aynpptot_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc totlit.nc totlit totlit_m.nc
tar czf totlit_m.nc.tar.gz totlit_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc ayneetot.nc ayneetot ayneetot_m.nc
tar czf ayneetot_m.nc.tar.gz ayneetot_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc aynbp.nc aynbp aynbp_m.nc
tar czf aynbp_m.nc.tar.gz aynbp_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc ayCH4.nc ayCH4 ayCH4_m.nc
tar czf ayCH4_m.nc.tar.gz ayCH4_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc ayn2oflux.nc ayn2oflux ayn2oflux_m.nc
tar czf ayn2oflux_m.nc.tar.gz ayn2oflux_m.nc

sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc gdd5this.nc gdd5this gdd5this_m.nc
tar czf gdd5this_m.nc.tar.gz gdd5this_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc ayprcp.nc ayprcp ayprcp_m.nc
tar czf ayprcp_m.nc.tar.gz ayprcp_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc totceco.nc totceco totceco_m.nc
tar czf totceco_m.nc.tar.gz totceco_m.nc
sub_region_N_blocks_merge_alcf p_list_sub_region_N_blocks_merge_comp.asc yrleach.nc yrleach yrleach_m.nc
tar czf yrleach_m.nc.tar.gz yrleach_m.nc


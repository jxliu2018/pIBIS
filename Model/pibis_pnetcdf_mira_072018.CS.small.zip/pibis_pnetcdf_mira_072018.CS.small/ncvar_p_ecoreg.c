/*
 _ __   _____   ____ _ _ __ ___ 
| '_ \ / __\ \ / / _` | '__/ __|
| | | | (__ \ V / (_| | | | (__ 
|_| |_|\___| \_/ \__,_|_|(_)___|

*/
//ncvar.c
//Wanjing Wei, pnetcdf processes
//Jinxun Liu, updated 7/6/2017
//jxliu@usgs.gov

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "netcdf.h"
#include "ibis_common_p.h"

void set_init_value_int(int* array, int value, int len ) {
  int i;
  for(i = 0; i < len; i++) array[i] = value;
}
void set_init_value_char(char* array, char value, int len ) {
  int i;
  for(i = 0; i < len ; i++) array[i] = value;
}
void set_init_value(float* array, float value, int len ) {
  int i;
  for(i = 0; i < len ; i++) array[i] = value;
}
void ncread0(int first){//pre-processing for map readings
  int i, j, k;
  int callocsize = sizeof(float);
  int callocerror = 0;

    if(ssouth >= snorth && seast >= swest){
      nlatsub = ssouth - snorth + 1;       //subregion rows
      nlonsub = seast - swest + 1;         //subregion columns
      nlatsubs = (nlatsub-1)/rowscale + 1; //subregion rows, by sampling
      nlonsubs = (nlonsub-1)/colscale + 1; //subregion columns, by sampling
      startlon = map1left + (swest - 1) * map1res;
      startlat = map1upper - (snorth - 1) * map1res;
      endlon = startlon + nlonsub * map1res - 1;
      endlat = startlat - nlatsub * map1res + 1;

      total_npoi = nlatsub * nlonsub;

      //map1, base resolution, 1 layer maps, e.g mask, veg, biomass, fips
      start_g1[0] = 0;
      start_g1[1] = 0;
      start_g1[2] = snorth - 1;
      start_g1[3] = swest - 1;
      count_g1[0] = 1;
      count_g1[1] = 1;
      count_g1[2] = ssouth - snorth + 1;;
      count_g1[3] = seast - swest + 1;

      time_length1 = count_g1[0];
      layers1 = count_g1[1];
      rows1 = count_g1[2];
      columns1 = count_g1[3];
      array_size1 = count_g1[0]*count_g1[1]*count_g1[2]*count_g1[3];
      offrow1 = map1upper - startlat;
      offrow1x = offrow1/map1res;
      offcol1 = startlon - map1left;
      offcol1x = offcol1/map1res;

      //map2, base resolution, multilayer maps, e.g. soil texture
      start_g2[0] = 0;
      start_g2[1] = 0;
      start_g2[2] = (map2upper - startlat)/map2res;
      start_g2[3] = (startlon - map2left)/map2res;
      count_g2[0] = 1;
      count_g2[1] = nsoilay;
      count_g2[2] = 1 + (int)((map2upper - endlat)/map2res) - (int)((map2upper - startlat)/map2res);
      count_g2[3] = 1 + (int)((endlon - map2left)/map2res) - (int)((startlon - map2left)/map2res);

      time_length2 = count_g2[0];
      layers2 = count_g2[1];
      rows2 = count_g2[2];
      columns2 = count_g2[3];
      array_size2 = count_g2[0]*count_g2[1]*count_g2[2]*count_g2[3];
      offrow2 = map2upper - startlat;
      offrow2x = offrow2/map2res;
      offcol2 = startlon - map2left;
      offcol2x = offcol2/map2res;

      //map3, scaled resolution, multilayer maps, e.g average climate data
      start_g3[0] = 0;
      start_g3[1] = 0;
      start_g3[2] = (map3upper - startlat)/map3res;
      start_g3[3] = (startlon - map3left)/map3res;
      count_g3[0] = 12;
      count_g3[1] = 1;
      count_g3[2] = 1 + (int)((map3upper - endlat)/map3res) - (int)((map3upper - startlat)/map3res);
      count_g3[3] = 1 + (int)((endlon - map3left)/map3res) - (int)((startlon - map3left)/map3res);

      time_length3 = count_g3[0];
      layers3 = count_g3[1];
      rows3 = count_g3[2];
      columns3 = count_g3[3];
      array_size3 = count_g3[0]*count_g3[1]*count_g3[2]*count_g3[3];
      offrow3 = map3upper - startlat;
      offrow3x = offrow3/map3res;
      offcol3 = startlon - map3left;
      offcol3x = offcol3/map3res;

      //map4, scaled resolution, multilayer maps, e.g anormly climate data
      start_g4[0] = 0;
      start_g4[1] = 0;
      start_g4[2] = (map4upper - startlat)/map4res;
      start_g4[3] = (startlon - map4left)/map4res;
      count_g4[0] = anomyears*12;
      count_g4[1] = 1;
      count_g4[2] = 1 + (int)((map4upper - endlat)/map4res) - (int)((map4upper - startlat)/map4res);
      count_g4[3] = 1 + (int)((endlon - map4left)/map4res) - (int)((startlon - map4left)/map4res);

      time_length4 = count_g4[0];
      layers4 = count_g4[1];
      rows4 = count_g4[2];
      columns4 = count_g4[3];
      array_size4 = count_g4[0]*count_g4[1]*count_g4[2]*count_g4[3];
      offrow4 = map4upper - startlat;
      offrow4x = offrow4/map4res;
      offcol4 = startlon - map4left;
      offcol4x = offcol4/map4res;

      //map5, base resolution multilayer maps, e.g lcc maps
      start_g5[0] = 0;
      start_g5[1] = 0;
      start_g5[2] = snorth - 1;
      start_g5[3] = swest - 1;
      count_g5[0] = lccyears;
      count_g5[1] = 1;
      count_g5[2] = ssouth - snorth + 1;;
      count_g5[3] = seast - swest + 1;

      time_length5 = count_g5[0];
      layers5 = count_g5[1];
      rows5 = count_g5[2];
      columns5 = count_g5[3];
      array_size5 = count_g5[0]*count_g5[1]*count_g5[2]*count_g5[3];
      offrow5 = map1upper - startlat;
      offrow5x = offrow1/map1res;
      offcol5 = startlon - map1left;
      offcol5x = offcol1/map1res;

      //arrange relative spatial map_ids
      callocsize = sizeof(int);
      callocerror = 0;
      if((map1_id = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc map1_id.", -1);
      if((map2_id = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc map2_id.", -1);
      if((map3_id = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc map3_id.", -1);
      if((map4_id = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc map4_id.", -1);
      if((map5_id = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc map5_id.", -1);

      int iii, jjj, loc1, loc2, loc3, loc4;
      int remainder_row, remainder_col;
      k = 0;
      for(i=0; i<count_g1[2]; i++){
        remainder_row = i%rowscale;
        for(j=0; j<count_g1[3]; j++){
          remainder_col = j%colscale;

          loc1 = i*count_g1[3] + j;
          map1_id[k] = loc1;
          map5_id[k] = loc1;//map5 has the same spatial reference as map1 

          if(remainder_row==0 && remainder_col==0){
            iii = (i*map1res + offrow2)/map2res - offrow2x;
            jjj = (j*map1res + offcol2)/map2res - offcol2x;
            loc2 = iii*count_g2[3] + jjj;
            map2_id[k] = loc2;

            iii = (i*map1res + offrow3)/map3res - offrow3x;
            jjj = (j*map1res + offcol3)/map3res - offcol3x;
            loc3 = iii*count_g3[3] + jjj;
            map3_id[k] = loc3;

            iii = (i*map1res + offrow4)/map4res - offrow4x;
            jjj = (j*map1res + offcol4)/map4res - offcol4x;
            loc4 = iii*count_g4[3] + jjj;
            map4_id[k] = loc4;
          }
          else{
            map2_id[k] = -1;
            map3_id[k] = -1;
            map4_id[k] = -1;
          }

          k = k + 1;
        }
      }

      //malloc common interpolation and sampling data array (for 2D,3D,4D)
      array_size1_interp = count_g1[0]*count_g1[1]*count_g1[2]*count_g1[3];
      array_size1_samp = nlatsubs * nlonsubs;
      callocsize = sizeof(char);
          if (first) {
      if((surta_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc surta_data.", -1);
      ReadNCVara(infilen[0], invarn[0], NC_BYTE, start_g1, count_g1, surta_data);
      //ReadNCVara("./input/nlcd_2006_land_mask10_960m_schar.nc", "surta", NC_BYTE, start_g1, count_g1, surta_data);
      calc_valid_seg(); //calculate valid segment
          }//if (first)
    }//if(ssouth >= snorth && seast >= swest){

  return;
}//ncread0()

void ncread1(int first){//read single layer maps
  int i, j, k;
  int callocsize = sizeof(float);
  int callocerror = 0;

    if(ssouth >= snorth && seast >= swest){
      //arrange relative spatial map_ids

      //malloc common interpolation and sampling data array (for 2D,3D,4D)
      array_size1_interp = count_g1[0]*count_g1[1]*count_g1[2]*count_g1[3];
      array_size2_interp = count_g2[0]*count_g2[1]*count_g1[2]*count_g1[3];
      array_size3_interp = count_g3[0]*count_g3[1]*count_g1[2]*count_g1[3];
      array_size4_interp = count_g4[0]*count_g4[1]*count_g1[2]*count_g1[3];
      array_size5_interp = count_g5[0]*count_g5[1]*count_g1[2]*count_g1[3];
      array_size1_samp = nlatsubs * nlonsubs;
      array_size2_samp = nlatsubs * nlonsubs * nsoilay;
      array_size3_samp = nlatsubs * nlonsubs * 12;
      array_size4_samp = nlatsubs * nlonsubs * 12 * anomyears;
      array_size5_samp = nlatsubs * nlonsubs * lccyears;

      array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
      array_size4_interp_x = count_g1[2] * count_g1[3] * 12 * scatter_years;

      //Read single layer netcdf data, 8+8+9 netcdf variables
      callocsize = sizeof(char);
      if((surta_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc surta_data.", -1);

          if (first) {
      if((cell_area_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc cell_area_data.", -1);
      if((vegtype0_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc vegtype0_data.", -1);
      if((ecoreg_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc ecoreg_data.", -1);
      if((wetland_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc wetland_data.", -1);
      callocsize = sizeof(float);
      if((cell_lat_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc cell_lat_data.", -1);
      if((topo_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc topo_data.", -1);
      if((fips_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc fips_data.", -1);
      ReadNCVara(infilen[0], invarn[0], NC_BYTE, start_g1, count_g1, surta_data);
      ReadNCVara(infilen[1], invarn[1], NC_FLOAT, start_g1, count_g1, cell_lat_data);
      ReadNCVara(infilen[2], invarn[2], NC_BYTE, start_g1, count_g1, cell_area_data);
      ReadNCVara(infilen[3], invarn[3], NC_FLOAT, start_g1, count_g1, topo_data);
      ReadNCVara(infilen[4], invarn[4], NC_BYTE, start_g1, count_g1, vegtype0_data);
      ReadNCVara(infilen[5], invarn[5], NC_BYTE, start_g1, count_g1, ecoreg_data);
      ReadNCVara(infilen[6], invarn[6], NC_INT, start_g1, count_g1, fips_data);
      ReadNCVara(infilen[7], invarn[7], NC_BYTE, start_g1, count_g1, wetland_data);
      //ReadNCVara("./input/nlcd_2006_land_mask10_960m_schar.nc", "surta", NC_BYTE, start_g1, count_g1, surta_data);
      //ReadNCVara("./input/conus_cell_lat_960m.nc", "cell_lat", NC_FLOAT, start_g1, count_g1, cell_lat_data);
      //ReadNCVara("./input/conus_all_one_960m_schar.nc", "val_one", NC_BYTE, start_g1, count_g1, cell_area_data);
      //ReadNCVara("./input/conus_gtopo30_960m.nc", "topo", NC_FLOAT, start_g1, count_g1, topo_data);
      //ReadNCVara("./input/conus_all_one_960m_schar.nc", "val_one", NC_BYTE, start_g1, count_g1, vegtype0_data);
      //ReadNCVara("./input/conus_ecoreg_960m_schar.nc", "ecoreg", NC_BYTE, start_g1, count_g1, ecoreg_data);
      //ReadNCVara("./input/conus_county_fips_960m_int.nc", "fips", NC_INT, start_g1, count_g1, fips_data);
      //ReadNCVara("./input/esturine_palustrine_1996_960m_schar.nc", "wetland", NC_BYTE, start_g1, count_g1, wetland_data);

      callocsize = sizeof(float);
      if((biomf_c_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc biomf_c_data.", -1);
      if((bioms_c_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc bioms_c_data.", -1);
      if((biomg_c_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc biomg_c_data.", -1);
      if((nh4dep_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc nh4dep_data.", -1);
      if((no3dep_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc no3dep_data.", -1);
      callocsize = sizeof(char);
      if((burnlow_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc burnlow_data.", -1);
      if((burnmix_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc burnmix_data.", -1);
      if((burnhigh_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc burnhigh_data.", -1);
      ReadNCVara(infilen[8], invarn[8], NC_FLOAT, start_g1, count_g1, biomf_c_data);
      ReadNCVara(infilen[9], invarn[9], NC_FLOAT, start_g1, count_g1, bioms_c_data);
      ReadNCVara(infilen[10], invarn[10], NC_FLOAT, start_g1, count_g1, biomg_c_data);
      ReadNCVara(infilen[11], invarn[11], NC_FLOAT, start_g1, count_g1, nh4dep_data);
      ReadNCVara(infilen[12], invarn[12], NC_FLOAT, start_g1, count_g1, no3dep_data);
      ReadNCVara(infilen[13], invarn[13], NC_BYTE, start_g1, count_g1, burnlow_data);
      ReadNCVara(infilen[14], invarn[14], NC_BYTE, start_g1, count_g1, burnmix_data);
      ReadNCVara(infilen[15], invarn[15], NC_BYTE, start_g1, count_g1, burnhigh_data);
      //ReadNCVara("./input/conus_biom_for960m_075.nc", "biomf_c", NC_FLOAT, start_g1, count_g1, biomf_c_data);
      //ReadNCVara("./input/conus_biom_shr960m_075.nc", "bioms_c", NC_FLOAT, start_g1, count_g1, bioms_c_data);
      //ReadNCVara("./input/conus_biom_gra960m_075.nc", "biomg_c", NC_FLOAT, start_g1, count_g1, biomg_c_data);
      //ReadNCVara("./input/conus_nh4_960m.nc", "nh4dep", NC_FLOAT, start_g1, count_g1, nh4dep_data);
      //ReadNCVara("./input/conus_no3_960m.nc", "no3dep", NC_FLOAT, start_g1, count_g1, no3dep_data);
      //ReadNCVara("./input/conus_burnl_for960m_schar.nc", "burnlow", NC_BYTE, start_g1, count_g1, burnlow_data);
      //ReadNCVara("./input/conus_burnm_for960m_schar.nc", "burnmix", NC_BYTE, start_g1, count_g1, burnmix_data);
      //ReadNCVara("./input/conus_burnh_for960m_schar.nc", "burnhigh", NC_BYTE, start_g1, count_g1, burnhigh_data);

      callocsize = sizeof(char);
      if((pct_for_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc pct_for_data.", -1);
      if((pct_shr_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc pct_shr_data.", -1);
      if((pct_gra_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc pct_gra_data.", -1);
      if((pct_agr_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc pct_agr_data.", -1);
      if((pct_c3crop_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc pct_c3crop_data.", -1);
      if((pct_nveg_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc pct_nveg_data.", -1);
      if((pct_wdcrop_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc pct_wdcrop_data.", -1);
      if((pct_wetland_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc pct_wetland_data.", -1);
      callocsize = sizeof(float);
      if((soilc_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc soilc_data.", -1);
      if((nmmax_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc nmmax_data.", -1);
      ReadNCVara(infilen[16], invarn[16], NC_BYTE, start_g1, count_g1, pct_for_data);
      ReadNCVara(infilen[17], invarn[17], NC_BYTE, start_g1, count_g1, pct_shr_data);
      ReadNCVara(infilen[18], invarn[18], NC_BYTE, start_g1, count_g1, pct_gra_data);
      ReadNCVara(infilen[19], invarn[19], NC_BYTE, start_g1, count_g1, pct_agr_data);
      ReadNCVara(infilen[20], invarn[20], NC_BYTE, start_g1, count_g1, pct_c3crop_data);
      ReadNCVara(infilen[21], invarn[21], NC_BYTE, start_g1, count_g1, pct_wdcrop_data);
      ReadNCVara(infilen[22], invarn[22], NC_BYTE, start_g1, count_g1, pct_wetland_data);
      ReadNCVara(infilen[23], invarn[23], NC_BYTE, start_g1, count_g1, pct_nveg_data);
      ReadNCVara(infilen[24], invarn[24], NC_FLOAT, start_g1, count_g1, soilc_data);
      ReadNCVara(infilen[25], invarn[25], NC_FLOAT, start_g1, count_g1, nmmax_data);
      //ReadNCVara("./input/nlcd_2006_for_pct_960m_schar.nc", "pct_for", NC_BYTE, start_g1, count_g1, pct_for_data);
      //ReadNCVara("./input/conus_nlcd_pct_shr960m_schar.nc", "pct_shr", NC_BYTE, start_g1, count_g1, pct_shr_data);
      //ReadNCVara("./input/conus_nlcd_pct_gra960m_schar.nc", "pct_gra", NC_BYTE, start_g1, count_g1, pct_gra_data);
      //ReadNCVara("./input/nlcd_2006_agr_pct_960m_schar.nc", "pct_agr", NC_BYTE, start_g1, count_g1, pct_agr_data);
      //ReadNCVara("./input/conus_all_zero_960m_schar.nc", "val_zero", NC_BYTE, start_g1, count_g1, pct_c3crop_data);
      //ReadNCVara("./input/conus_ca_woody_crop_960m_schar.nc", "wdcrop", NC_BYTE, start_g1, count_g1, pct_wdcrop_data);
      //ReadNCVara("./input/nlcd_2006_wet_pct_960m_schar.nc", "pct_wet", NC_BYTE, start_g1, count_g1, pct_wetland_data);
      //ReadNCVara("./input/nlcd_2006_nveg_pct_960m_schar.nc", "pct_nveg", NC_BYTE, start_g1, count_g1, pct_nveg_data);
      //ReadNCVara("./input/conus_soc_focal_960m.nc", "soc", NC_FLOAT, start_g1, count_g1, soilc_data);
      //ReadNCVara("./input/conus_nmmax_960m.nc", "nmmax", NC_FLOAT, start_g1, count_g1, nmmax_data);

      callocsize = sizeof(char);
      if((owner_type_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc owner_type_data.", -1);
      ReadNCVara(infilen[26], invarn[26], NC_BYTE, start_g1, count_g1, owner_type_data);
      //ReadNCVara("./input/conus_for_ownership_960m_schar.nc", "owner", NC_BYTE, start_g1, count_g1, owner_type_data);

      callocsize = sizeof(int);
      //--- a single layer map to be generated in rdscaler()
      if((fips123 = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc fips123.", -1);
      //--- a single layer map to be generated in interp()
      if((serial_id_samp = calloc(array_size1_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc serial_id_samp.", -1);

      callocsize = sizeof(float);
      //--- a single layer map to be generated in interp()
      if((deltat_norm_data_interp = calloc(array_size3_interp,callocsize)) == NULL) callocerror = errmsg("failed calloc fips123.", -1);
      //--- deltat is a coarse resolution single layer map, need to interpolate
      if((deltat_norm_data = calloc(array_size3,callocsize)) == NULL) callocerror = errmsg("failed calloc deltat_norm_data.", -1);
      if((deltat_norm_data_scatter = calloc(array_size3_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc deltat_norm_data.", -1);
      count_g3[0] = 1;
      ReadNCVara(infilen[27], invarn[27], NC_FLOAT, start_g3, count_g3, deltat_norm_data);
      //ReadNCVara("./input/reprj_prism_deltat.nc", "deltat", NC_FLOAT, start_g3, count_g3, deltat_norm_data);

          }//if (first)

      count_g3[0] = 12;
          if (first) {
      rdscaler();  //read scalers for the simulation window
      rdlanduse();  //read landuse table
      interp();   //interpolate single layer data to base resolution then sampling
          }//if (first)
    }//if(ssouth >= snorth && seast >= swest){

  return;
}//ncread1()


void ncread2(int first){//for 6 layer soil data
  int i, j, k;
  int callocsize = sizeof(float);
  int callocerror = 0;

    if(ssouth >= snorth && seast >= swest){
      //Read multi-layer netcdf data, 3 variables
      array_size2_interp = count_g2[0]*count_g2[1]*count_g1[2]*count_g1[3];
      array_size2_samp = nlatsubs * nlonsubs * nsoilay;

          if (first) {
      callocsize = sizeof(float);
      if((soil_data_interp = calloc(array_size2_interp,callocsize)) == NULL) callocerror = errmsg("failed calloc soil_data_interp.", -1);
      if((soil_data_samp = calloc(array_size2_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc soil_data_samp.", -1);
      callocsize = sizeof(char);
      if((sand_data = calloc(array_size2,callocsize)) == NULL) callocerror = errmsg("failed calloc sand_data.", -1);
      if((clay_data = calloc(array_size2,callocsize)) == NULL) callocerror = errmsg("failed calloc clay_data.", -1);
      if((ph_data = calloc(array_size2,callocsize)) == NULL) callocerror = errmsg("failed calloc ph_data.", -1);
      callocsize = sizeof(float);
      if((sand_data_scatter = calloc(array_size2_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc sand_data_scatter.", -1);
      if((clay_data_scatter = calloc(array_size2_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc clay_data_scatter.", -1);
      if((ph_data_scatter = calloc(array_size2_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc ph_data_scatter.", -1);

      ReadNCVara(infilen[28], invarn[28], NC_BYTE, start_g2, count_g2, sand_data);
      ReadNCVara(infilen[29], invarn[29], NC_BYTE, start_g2, count_g2, clay_data);
      ReadNCVara(infilen[30], invarn[30], NC_BYTE, start_g2, count_g2, ph_data);
      //ReadNCVara("./input/conus_sand_focal_960m_schar.nc", "sandpct", NC_BYTE, start_g2, count_g2, sand_data);
      //ReadNCVara("./input/conus_clay_focal_960m_schar.nc", "claypct", NC_BYTE, start_g2, count_g2, clay_data);
      //ReadNCVara("./input/conus_ph7_960m.nc", "ph", NC_BYTE, start_g2, count_g2, ph_data);
      interp_samp_char(sand_data, soil_data_interp, soil_data_samp, sand_data_scatter, 2);
      free(sand_data);
      interp_samp_char(clay_data, soil_data_interp, soil_data_samp, clay_data_scatter, 2);
      free(clay_data);
      interp_samp_char(ph_data, soil_data_interp, soil_data_samp, ph_data_scatter, 2);
      free(ph_data);
      free(soil_data_interp);
      free(soil_data_samp);
          }//if (first)
    }//if(ssouth >= snorth && seast >= swest){

  return;
}//ncread2()


void ncread3(int first){//for reading average cliamte data
  float *climate_norm_interp;
  float *climate_norm_samp;
  int callocsize = sizeof(float);
  int callocerror = 0;

    if(ssouth >= snorth && seast >= swest){
      //Read multi-layer average climate data, 9 netcdf variables
      array_size3_interp = count_g3[0]*count_g3[1]*count_g1[2]*count_g1[3];
      array_size3_samp = nlatsubs * nlonsubs * 12;
          if (first) {
      if((climate_norm_interp = calloc(array_size3_interp,callocsize)) == NULL) callocerror = errmsg("failed calloc climate_norm_interp.", -1);
      if((climate_norm_samp = calloc(array_size3_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc climate_norm_samp.", -1);

      if((wetd_norm_data = calloc(array_size3,callocsize)) == NULL) callocerror = errmsg("failed calloc wetd_norm_data.", -1);
      if((cld_norm_data = calloc(array_size3,callocsize)) == NULL) callocerror = errmsg("failed calloc cld_norm_data.", -1);
      if((prec_norm_data = calloc(array_size3,callocsize)) == NULL) callocerror = errmsg("failed calloc prec_norm_data.", -1);
      if((temp_norm_data = calloc(array_size3,callocsize)) == NULL) callocerror = errmsg("failed calloc temp_norm_data.", -1);
      if((trange_norm_data = calloc(array_size3,callocsize)) == NULL) callocerror = errmsg("failed calloc trange_norm_data.", -1);
      if((rhum_norm_data = calloc(array_size3,callocsize)) == NULL) callocerror = errmsg("failed calloc rhum_norm_data.", -1);
      if((wspd_norm_data = calloc(array_size3,callocsize)) == NULL) callocerror = errmsg("failed calloc wspd_norm_data.", -1);
      if((co2spa_norm_data = calloc(array_size3,callocsize)) == NULL) callocerror = errmsg("failed calloc co2spa_norm_data.", -1);

      if((wetd_norm_data_scatter = calloc(array_size3_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc wetd_norm_data_scatter.", -1);
      if((cld_norm_data_scatter = calloc(array_size3_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc cld_norm_data_scatter.", -1);
      if((prec_norm_data_scatter = calloc(array_size3_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc prec_norm_data_scatter.", -1);
      if((temp_norm_data_scatter = calloc(array_size3_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc temp_norm_data_scatter.", -1);
      if((trange_norm_data_scatter = calloc(array_size3_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc trange_norm_data_scatter.", -1);
      if((rhum_norm_data_scatter = calloc(array_size3_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc rhum_norm_data_scatter.", -1);
      if((wspd_norm_data_scatter = calloc(array_size3_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc wspd_norm_data_scatter.", -1);
      if((co2spa_norm_data_scatter = calloc(array_size3_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc co2spa_norm_data_scatter.", -1);

      ReadNCVara(infilen[31], invarn[31], NC_FLOAT, start_g3, count_g3, wetd_norm_data);
      ReadNCVara(infilen[32], invarn[32], NC_FLOAT, start_g3, count_g3, cld_norm_data);
      ReadNCVara(infilen[33], invarn[33], NC_FLOAT, start_g3, count_g3, prec_norm_data);
      ReadNCVara(infilen[34], invarn[34], NC_FLOAT, start_g3, count_g3, temp_norm_data);
      ReadNCVara(infilen[35], invarn[35], NC_FLOAT, start_g3, count_g3, trange_norm_data);
      ReadNCVara(infilen[36], invarn[36], NC_FLOAT, start_g3, count_g3, rhum_norm_data);
      ReadNCVara(infilen[37], invarn[37], NC_FLOAT, start_g3, count_g3, wspd_norm_data);
      ReadNCVara(infilen[38], invarn[38], NC_FLOAT, start_g3, count_g3, co2spa_norm_data);
      //ReadNCVara("./input/conus_wetd_4km.nc", "wetd", NC_FLOAT, start_g3, count_g3, wetd_norm_data);
      //ReadNCVara("./input/hist_cld_norm_out_4km_float.nc", "cld", NC_FLOAT, start_g3, count_g3, cld_norm_data);
      //ReadNCVara("./input/hist_prec_norm_out_4km.nc", "prec", NC_FLOAT, start_g3, count_g3, prec_norm_data);
      //ReadNCVara("./input/hist_temp_norm_out_4km.nc", "temp", NC_FLOAT, start_g3, count_g3, temp_norm_data);
      //ReadNCVara("./input/hist_trange_norm_out_4km.nc", "trange", NC_FLOAT, start_g3, count_g3, trange_norm_data);
      //ReadNCVara("./input/hist_rhum_norm_out_4km.nc", "rhum", NC_FLOAT, start_g3, count_g3, rhum_norm_data);
      //ReadNCVara("./input/hist_wspd_norm_out_4km.nc", "wspd", NC_FLOAT, start_g3, count_g3, wspd_norm_data);
      //ReadNCVara("./input/conus_co2sp.nc", "co2sp", NC_FLOAT, start_g3, count_g3, co2spa_norm_data);

      interp_samp_float(wetd_norm_data, climate_norm_interp, climate_norm_samp, wetd_norm_data_scatter, 3);
      free(wetd_norm_data);
      interp_samp_float(cld_norm_data, climate_norm_interp, climate_norm_samp, cld_norm_data_scatter, 3);
      free(cld_norm_data);
      interp_samp_float(prec_norm_data, climate_norm_interp, climate_norm_samp, prec_norm_data_scatter, 3);
      free(prec_norm_data);
      interp_samp_float(temp_norm_data, climate_norm_interp, climate_norm_samp, temp_norm_data_scatter, 3);
      free(temp_norm_data);
      interp_samp_float(trange_norm_data, climate_norm_interp, climate_norm_samp, trange_norm_data_scatter, 3);
      free(trange_norm_data);
      interp_samp_float(rhum_norm_data, climate_norm_interp, climate_norm_samp, rhum_norm_data_scatter, 3);
      free(rhum_norm_data);
      interp_samp_float(wspd_norm_data, climate_norm_interp, climate_norm_samp, wspd_norm_data_scatter, 3);
      free(wspd_norm_data);
      interp_samp_float(co2spa_norm_data, climate_norm_interp, climate_norm_samp, co2spa_norm_data_scatter, 3);
      free(co2spa_norm_data);

      free(climate_norm_interp);
      free(climate_norm_samp);
          }//if (first)
    }//if(ssouth >= snorth && seast >= swest){

  return;
}//ncread3()


void ncread4(int first){//for precip anom
  return;
}//ncread4()

void ncread4_1(int first){//for precip anom
  int callocsize = sizeof(float);
  int callocerror = 0;

  int array_size4_interp = count_g1[2] * count_g1[3] * 12 * scatter_years;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;

  if (first) {
  if((prec_anorm_data = calloc(array_size4,callocsize)) == NULL) callocerror = errmsg("failed calloc prec_anorm_data.", -1);
  if((climate_anorm_interp_prec = calloc(array_size4_interp,callocsize)) == NULL) callocerror = errmsg("failed calloc climate_anorm_interp_prec.", -1);
  if((prec_anorm_data_scatter1 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc prec_anorm_data_scatter1.", -1);

  ReadNCVara(infilen[39], invarn[39], NC_FLOAT, start_g4, count_g4, prec_anorm_data);
  //ReadNCVara("./input/reprj_conus_PRISM_prec_1971-2015.nc", "prec", NC_FLOAT, start_g4, count_g4, prec_anorm_data);
  if(rowscale == 1){
    interp_float(prec_anorm_data, climate_anorm_interp_prec, prec_anorm_data_scatter1, 4, 1);
  }
  else{
    if((climate_anorm_samp = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc climate_anorm_samp.", -1);
    interp_samp_float_anom(prec_anorm_data, climate_anorm_interp_prec, climate_anorm_samp, prec_anorm_data_scatter1, 4, 1);
  }
  }//if (first)

  return;
}
void ncread4_2(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;

  if (first) {
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if((prec_anorm_data_scatter2 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc prec_anorm_data_scatter2.", -1);
  if(rowscale == 1){
    interp_float(prec_anorm_data, climate_anorm_interp_prec, prec_anorm_data_scatter2, 4, 2);
  }
  else{
    interp_samp_float_anom(prec_anorm_data, climate_anorm_interp_prec, climate_anorm_samp, prec_anorm_data_scatter2, 4, 2);
  }
  }//if (first)

  return;
}
void ncread4_3(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;

  if (first) {
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if((prec_anorm_data_scatter3 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc prec_anorm_data_scatter3.", -1);
  if(rowscale == 1){
    interp_float(prec_anorm_data, climate_anorm_interp_prec, prec_anorm_data_scatter3, 4, 3);
  }
  else{
    interp_samp_float_anom(prec_anorm_data, climate_anorm_interp_prec, climate_anorm_samp, prec_anorm_data_scatter3, 4, 3);
  }
  }//if (first)

  return;
}
void ncread4_4(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;

  if (first) {
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if((prec_anorm_data_scatter4 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc prec_anorm_data_scatter4.", -1);
  if(rowscale == 1){
    interp_float(prec_anorm_data, climate_anorm_interp_prec, prec_anorm_data_scatter4, 4, 4);
  }
  else{
    interp_samp_float_anom(prec_anorm_data, climate_anorm_interp_prec, climate_anorm_samp, prec_anorm_data_scatter4, 4, 4);
  }
  }//if (first)

  return;
}
void ncread4_5(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;

  if (first) {
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if((prec_anorm_data_scatter5 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc prec_anorm_data_scatter5.", -1);
  if(rowscale == 1){
    interp_float(prec_anorm_data, climate_anorm_interp_prec, prec_anorm_data_scatter5, 4, 5);
  }
  else{
    interp_samp_float_anom(prec_anorm_data, climate_anorm_interp_prec, climate_anorm_samp, prec_anorm_data_scatter5, 4, 5);
  }
  }//if (first)

  return;
}
void ncread4_6(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;

  if (first) {
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if((prec_anorm_data_scatter6 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc prec_anorm_data_scatter6.", -1);
  if(rowscale == 1){
    interp_float(prec_anorm_data, climate_anorm_interp_prec, prec_anorm_data_scatter6, 4, 6);
  }
  else{
    interp_samp_float_anom(prec_anorm_data, climate_anorm_interp_prec, climate_anorm_samp, prec_anorm_data_scatter6, 4, 6);
  }
  }//if (first)

  return;
}
void ncread4_7(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;

  if (first) {
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if((prec_anorm_data_scatter7 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc prec_anorm_data_scatter7.", -1);
  if(rowscale == 1){
    interp_float(prec_anorm_data, climate_anorm_interp_prec, prec_anorm_data_scatter7, 4, 7);
  }
  else{
    interp_samp_float_anom(prec_anorm_data, climate_anorm_interp_prec, climate_anorm_samp, prec_anorm_data_scatter7, 4, 7);
  }
  }//if (first)

  return;
}
void ncread4_8(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;

  if (first) {
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if((prec_anorm_data_scatter8 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc prec_anorm_data_scatter8.", -1);
  if(rowscale == 1){
    interp_float(prec_anorm_data, climate_anorm_interp_prec, prec_anorm_data_scatter8, 4, 8);
  }
  else{
    interp_samp_float_anom(prec_anorm_data, climate_anorm_interp_prec, climate_anorm_samp, prec_anorm_data_scatter8, 4, 8);
  }
  }//if (first)

  return;
}
void ncread4_9(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;

  if (first) {
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if((prec_anorm_data_scatter9 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc prec_anorm_data_scatter9.", -1);
  if(rowscale == 1){
    interp_float(prec_anorm_data, climate_anorm_interp_prec, prec_anorm_data_scatter9, 4, 9);
  }
  else{
    interp_samp_float_anom(prec_anorm_data, climate_anorm_interp_prec, climate_anorm_samp, prec_anorm_data_scatter9, 4, 9);
  }
  }//if (first)

  return;
}
void ncread4_10(int first){
  return;
}


void ncread5(int first){//for temprature anom
  return;
}//ncread5()

void ncread5_1(int first){//for temprature anom
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp = count_g1[2] * count_g1[3] * 12 * scatter_years;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;

  if (first) {
  if((temp_anorm_data = calloc(array_size4,callocsize)) == NULL) callocerror = errmsg("failed calloc temp_anorm_data.", -1);
  if((climate_anorm_interp_temp = calloc(array_size4_interp,callocsize)) == NULL) callocerror = errmsg("failed calloc climate_anorm_interp_temp.", -1);
  if((temp_anorm_data_scatter1 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc temp_anorm_data_scatter1.", -1);

  ReadNCVara(infilen[40], invarn[40], NC_FLOAT, start_g4, count_g4, temp_anorm_data);
  //ReadNCVara("./input/reprj_conus_PRISM_temp_1971-2015.nc", "temp", NC_FLOAT, start_g4, count_g4, temp_anorm_data);
  if(rowscale == 1){
    interp_float(temp_anorm_data, climate_anorm_interp_temp, temp_anorm_data_scatter1, 4, 1);
  }
  else{
    interp_samp_float_anom(temp_anorm_data, climate_anorm_interp_temp, climate_anorm_samp, temp_anorm_data_scatter1, 4, 1);
  }
  }//if (first)

  return;
}
void ncread5_2(int first){//for temprature anom
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;

  if (first) {
  if((temp_anorm_data_scatter2 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc temp_anorm_data_scatter2.", -1);
  if(rowscale == 1){
    interp_float(temp_anorm_data, climate_anorm_interp_temp, temp_anorm_data_scatter2, 4, 2);
  }
  else{
    interp_samp_float_anom(temp_anorm_data, climate_anorm_interp_temp, climate_anorm_samp, temp_anorm_data_scatter2, 4, 2);
  }
  }//if (first)

  return;
}
void ncread5_3(int first){//for temprature anom
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;

  if (first) {
  if((temp_anorm_data_scatter3 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc temp_anorm_data_scatter3.", -1);
  if(rowscale == 1){
    interp_float(temp_anorm_data, climate_anorm_interp_temp, temp_anorm_data_scatter3, 4, 3);
  }
  else{
    interp_samp_float_anom(temp_anorm_data, climate_anorm_interp_temp, climate_anorm_samp, temp_anorm_data_scatter3, 4, 3);
  }
  }//if (first)

  return;
}
void ncread5_4(int first){//for temprature anom
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;

  if (first) {
  if((temp_anorm_data_scatter4 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc temp_anorm_data_scatter4.", -1);
  if(rowscale == 1){
    interp_float(temp_anorm_data, climate_anorm_interp_temp, temp_anorm_data_scatter4, 4, 4);
  }
  else{
    interp_samp_float_anom(temp_anorm_data, climate_anorm_interp_temp, climate_anorm_samp, temp_anorm_data_scatter4, 4, 4);
  }
  }//if (first)

  return;
}
void ncread5_5(int first){//for temprature anom
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;

  if (first) {
  if((temp_anorm_data_scatter5 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc temp_anorm_data_scatter5.", -1);
  if(rowscale == 1){
    interp_float(temp_anorm_data, climate_anorm_interp_temp, temp_anorm_data_scatter5, 4, 5);
  }
  else{
    interp_samp_float_anom(temp_anorm_data, climate_anorm_interp_temp, climate_anorm_samp, temp_anorm_data_scatter5, 4, 5);
  }
  }//if (first)

  return;
}
void ncread5_6(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;

  if (first) {
  if((temp_anorm_data_scatter6 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc temp_anorm_data_scatter6.", -1);
  if(rowscale == 1){
    interp_float(temp_anorm_data, climate_anorm_interp_temp, temp_anorm_data_scatter6, 4, 6);
  }
  else{
    interp_samp_float_anom(temp_anorm_data, climate_anorm_interp_temp, climate_anorm_samp, temp_anorm_data_scatter6, 4, 6);
  }
  }//if (first)

  return;
}
void ncread5_7(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;

  if (first) {
  if((temp_anorm_data_scatter7 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc temp_anorm_data_scatter7.", -1);
  if(rowscale == 1){
    interp_float(temp_anorm_data, climate_anorm_interp_temp, temp_anorm_data_scatter7, 4, 7);
  }
  else{
    interp_samp_float_anom(temp_anorm_data, climate_anorm_interp_temp, climate_anorm_samp, temp_anorm_data_scatter7, 4, 7);
  }
  }//if (first)

  return;
}
void ncread5_8(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;

  if (first) {
  if((temp_anorm_data_scatter8 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc temp_anorm_data_scatter8.", -1);
  if(rowscale == 1){
    interp_float(temp_anorm_data, climate_anorm_interp_temp, temp_anorm_data_scatter8, 4, 8);
  }
  else{
    interp_samp_float_anom(temp_anorm_data, climate_anorm_interp_temp, climate_anorm_samp, temp_anorm_data_scatter8, 4, 8);
  }
  }//if (first)

  return;
}
void ncread5_9(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;

  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;

  if (first) {
  if((temp_anorm_data_scatter9 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc temp_anorm_data_scatter9.", -1);
  if(rowscale == 1){
    interp_float(temp_anorm_data, climate_anorm_interp_temp, temp_anorm_data_scatter9, 4, 9);
  }
  else{
    interp_samp_float_anom(temp_anorm_data, climate_anorm_interp_temp, climate_anorm_samp, temp_anorm_data_scatter9, 4, 9);
  }
  }//if (first)

  return;
}

void ncread5_10(int first){
  return;
}


void ncread6(int first){//trange anom
  return;
}//ncread6()

void ncread6_1(int first){//for temprature range
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp = count_g1[2] * count_g1[3] * 12 * scatter_years;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;

  if (first) {
  if((trange_anorm_data = calloc(array_size4,callocsize)) == NULL) callocerror = errmsg("failed calloc trange_anorm_data.", -1);
  if((climate_anorm_interp_trange = calloc(array_size4_interp,callocsize)) == NULL) callocerror = errmsg("failed calloc climate_anorm_interp_trange.", -1);
  if((trange_anorm_data_scatter1 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc trange_anorm_data_scatter1.", -1);

  ReadNCVara(infilen[41], invarn[41], NC_FLOAT, start_g4, count_g4, trange_anorm_data);
  //ReadNCVara("./input/reprj_conus_PRISM_trange_1971-2015.nc", "trange", NC_FLOAT, start_g4, count_g4, trange_anorm_data);
  if(rowscale == 1){
    interp_float(trange_anorm_data, climate_anorm_interp_trange, trange_anorm_data_scatter1, 4, 1);
  }
  else{
    interp_samp_float_anom(trange_anorm_data, climate_anorm_interp_trange, climate_anorm_samp, trange_anorm_data_scatter1, 4, 1);
  }
  }//if (first)

  return;
}
void ncread6_2(int first){//for temprature range
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if (first) {
  if((trange_anorm_data_scatter2 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc trange_anorm_data_scatter2.", -1);
  if(rowscale == 1){
    interp_float(trange_anorm_data, climate_anorm_interp_trange, trange_anorm_data_scatter2, 4, 2);
  }
  else{
    interp_samp_float_anom(trange_anorm_data, climate_anorm_interp_trange, climate_anorm_samp, trange_anorm_data_scatter2, 4, 2);
  }
  }//if (first)
  return;
}
void ncread6_3(int first){//for temprature range
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if (first) {
  if((trange_anorm_data_scatter3 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc trange_anorm_data_scatter3.", -1);
  if(rowscale == 1){
    interp_float(trange_anorm_data, climate_anorm_interp_trange, trange_anorm_data_scatter3, 4, 3);
  }
  else{
    interp_samp_float_anom(trange_anorm_data, climate_anorm_interp_trange, climate_anorm_samp, trange_anorm_data_scatter3, 4, 3);
  }
  }//if (first)
  return;
}
void ncread6_4(int first){//for temprature range
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if (first) {
  if((trange_anorm_data_scatter4 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc trange_anorm_data_scatter4.", -1);
  if(rowscale == 1){
    interp_float(trange_anorm_data, climate_anorm_interp_trange, trange_anorm_data_scatter4, 4, 4);
  }
  else{
    interp_samp_float_anom(trange_anorm_data, climate_anorm_interp_trange, climate_anorm_samp, trange_anorm_data_scatter4, 4, 4);
  }
  }//if (first)
  return;
}
void ncread6_5(int first){//for temprature range
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if (first) {
  if((trange_anorm_data_scatter5 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc trange_anorm_data_scatter5.", -1);
  if(rowscale == 1){
    interp_float(trange_anorm_data, climate_anorm_interp_trange, trange_anorm_data_scatter5, 4, 5);
  }
  else{
    interp_samp_float_anom(trange_anorm_data, climate_anorm_interp_trange, climate_anorm_samp, trange_anorm_data_scatter5, 4, 5);
  }
  }//if (first)
  return;
}
void ncread6_6(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if (first) {
  if((trange_anorm_data_scatter6 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc trange_anorm_data_scatter6.", -1);
  if(rowscale == 1){
    interp_float(trange_anorm_data, climate_anorm_interp_trange, trange_anorm_data_scatter6, 4, 6);
  }
  else{
    interp_samp_float_anom(trange_anorm_data, climate_anorm_interp_trange, climate_anorm_samp, trange_anorm_data_scatter6, 4, 6);
  }
  }//if (first)
  return;
}
void ncread6_7(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if (first) {
  if((trange_anorm_data_scatter7 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc trange_anorm_data_scatter7.", -1);
  if(rowscale == 1){
    interp_float(trange_anorm_data, climate_anorm_interp_trange, trange_anorm_data_scatter7, 4, 7);
  }
  else{
    interp_samp_float_anom(trange_anorm_data, climate_anorm_interp_trange, climate_anorm_samp, trange_anorm_data_scatter7, 4, 7);
  }
  }//if (first)
  return;
}
void ncread6_8(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if (first) {
  if((trange_anorm_data_scatter8 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc trange_anorm_data_scatter8.", -1);
  if(rowscale == 1){
    interp_float(trange_anorm_data, climate_anorm_interp_trange, trange_anorm_data_scatter8, 4, 8);
  }
  else{
    interp_samp_float_anom(trange_anorm_data, climate_anorm_interp_trange, climate_anorm_samp, trange_anorm_data_scatter8, 4, 8);
  }
  }//if (first)
  return;
}
void ncread6_9(int first){
  int callocsize = sizeof(float);
  int callocerror = 0;
  int array_size4_interp_s = nlatsubs * nlonsubs * 12 * scatter_years;
  if (first) {
  if((trange_anorm_data_scatter9 = calloc(array_size4_interp_s,callocsize)) == NULL) callocerror = errmsg("failed calloc trange_anorm_data_scatter9.", -1);
  if(rowscale == 1){
    interp_float(trange_anorm_data, climate_anorm_interp_trange, trange_anorm_data_scatter9, 4, 9);
  }
  else{
    interp_samp_float_anom(trange_anorm_data, climate_anorm_interp_trange, climate_anorm_samp, trange_anorm_data_scatter9, 4, 9);
  }
  }//if (first)
  return;
}
void ncread6_10(int first){
  return;
}

void ncread7(int first){
  float *lcc_interp_local;
  float *lcc_samp_local;
  int callocsize = sizeof(float);
  int callocerror = 0;

  array_size5_interp = count_g5[0]*count_g5[1]*count_g1[2]*count_g1[3];
  array_size5_samp = nlatsubs * nlonsubs * lccyears;

  if((lcc_interp_local = calloc(array_size5_interp,callocsize)) == NULL) callocerror = errmsg("failed calloc lcc_interp_local.", -1);
  if((lcc_samp_local = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc lcc_samp_local.", -1);
  if((lcc_data_scatter = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc lcc_data_scatter.", -1);
  callocsize = sizeof(char);
  if((lcc_data = calloc(array_size5,callocsize)) == NULL) callocerror = errmsg("failed calloc lcc_data.", -1);

  ReadNCVara(infilen[42], invarn[42], NC_BYTE, start_g5, count_g5, lcc_data);
  //ReadNCVara("./input/conus_lcc_71_10.nc", "lcc", NC_BYTE, start_g5, count_g5, lcc_data);
  interp_samp_char(lcc_data, lcc_interp_local, lcc_samp_local, lcc_data_scatter, 5);
  free(lcc_data);
  free(lcc_interp_local);
  free(lcc_samp_local);

  return;
}//ncread7()


void ncread8(int first){
  return;
}//ncread8()

void ncread8_1(int first){//for fire data
  float *fire_interp_local;
  float *fire_samp_local;
  int callocsize = sizeof(float);
  int callocerror = 0;

  array_size5_interp = count_g5[0]*count_g5[1]*count_g1[2]*count_g1[3];
  array_size5_samp = nlatsubs * nlonsubs * lccyears;

  if((fire_interp_local = calloc(array_size5_interp,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_interp_local.", -1);
  if((fire_samp_local = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_samp_local.", -1);
  if((fire_data_scatter = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_data_scatter.", -1);
  callocsize = sizeof(char);
  if((fire_data = calloc(array_size5,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_data.", -1);

  count_g5[0] = fireyears; //fire data is short, 27 years only
  ReadNCVara(infilen[43], invarn[43], NC_BYTE, start_g5, count_g5, fire_data);
  //ReadNCVara("./input/conus_mtbs8410_960m_schar.nc", "mtbs", NC_BYTE, start_g5, count_g5, fire_data);
  count_g5[0] = lccyears; //change back to lcc data length, 40 years

  interp_samp_char(fire_data, fire_interp_local, fire_samp_local, fire_data_scatter, 5);
  free(fire_data);
  free(fire_interp_local);
  free(fire_samp_local);

  return;
}

void ncread8_2(int first){//for fire data
  float *fire_interp_local;
  float *fire_samp_local;
  int callocsize = sizeof(float);
  int callocerror = 0;

  array_size5_interp = count_g5[0]*count_g5[1]*count_g1[2]*count_g1[3];
  array_size5_samp = nlatsubs * nlonsubs * lccyears;

  if((fire_interp_local = calloc(array_size5_interp,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_interp_local.", -1);
  if((fire_samp_local = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_samp_local.", -1);
  if((burnlf_data_scatter = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc burnlf_data_scatter.", -1);
  callocsize = sizeof(char);
  if((burnlf_data = calloc(array_size5,callocsize)) == NULL) callocerror = errmsg("failed calloc burnlf_data.", -1);

  count_g5[0] = fireyears; //fire data is short, 32 years only
  ReadNCVara(infilen[44], invarn[44], NC_BYTE, start_g5, count_g5, burnlf_data);
  //ReadNCVara("./input/mtbs_burnl_1984_2015_forest_960m.nc", "burnlow", NC_BYTE, start_g5, count_g5, burnlf_data);
  count_g5[0] = lccyears; //change back to lcc data length, 40 years

  interp_samp_char(burnlf_data, fire_interp_local, fire_samp_local, burnlf_data_scatter, 5);
  free(burnlf_data);
  free(fire_interp_local);
  free(fire_samp_local);
  return;
}

void ncread8_3(int first){//for fire data
  float *fire_interp_local;
  float *fire_samp_local;
  int callocsize = sizeof(float);
  int callocerror = 0;

  array_size5_interp = count_g5[0]*count_g5[1]*count_g1[2]*count_g1[3];
  array_size5_samp = nlatsubs * nlonsubs * lccyears;

  if((fire_interp_local = calloc(array_size5_interp,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_interp_local.", -1);
  if((fire_samp_local = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_samp_local.", -1);
  if((burnhf_data_scatter = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc burnhf_data_scatter.", -1);
  callocsize = sizeof(char);
  if((burnhf_data = calloc(array_size5,callocsize)) == NULL) callocerror = errmsg("failed calloc burnhf_data.", -1);

  count_g5[0] = fireyears; //fire data is short, 32 years only
  ReadNCVara(infilen[45], invarn[45], NC_BYTE, start_g5, count_g5, burnhf_data);
  //ReadNCVara("./input/mtbs_burnh_1984_2015_forest_960m.nc", "burnhigh", NC_BYTE, start_g5, count_g5, burnhf_data);
  count_g5[0] = lccyears; //change back to lcc data length, 40 years

  interp_samp_char(burnhf_data, fire_interp_local, fire_samp_local, burnhf_data_scatter, 5);
  free(burnhf_data);
  free(fire_interp_local);
  free(fire_samp_local);
  return;
}

void ncread8_4(int first){//for fire data
  float *fire_interp_local;
  float *fire_samp_local;
  int callocsize = sizeof(float);
  int callocerror = 0;

  array_size5_interp = count_g5[0]*count_g5[1]*count_g1[2]*count_g1[3];
  array_size5_samp = nlatsubs * nlonsubs * lccyears;

  if((fire_interp_local = calloc(array_size5_interp,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_interp_local.", -1);
  if((fire_samp_local = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_samp_local.", -1);
  if((burnmf_data_scatter = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc burnmf_data_scatter.", -1);
  callocsize = sizeof(char);
  if((burnmf_data = calloc(array_size5,callocsize)) == NULL) callocerror = errmsg("failed calloc burnmf_data.", -1);

  count_g5[0] = fireyears; //fire data is short, 32 years only
  ReadNCVara(infilen[46], invarn[46], NC_BYTE, start_g5, count_g5, burnmf_data);
  //ReadNCVara("./input/mtbs_burnm_1984_2015_forest_960m.nc", "burnmix", NC_BYTE, start_g5, count_g5, burnmf_data);
  count_g5[0] = lccyears; //change back to lcc data length, 40 years

  interp_samp_char(burnmf_data, fire_interp_local, fire_samp_local, burnmf_data_scatter, 5);
  free(burnmf_data);
  free(fire_interp_local);
  free(fire_samp_local);
  return;
}

void ncread8_5(int first){//for fire data
  float *fire_interp_local;
  float *fire_samp_local;
  int callocsize = sizeof(float);
  int callocerror = 0;

  array_size5_interp = count_g5[0]*count_g5[1]*count_g1[2]*count_g1[3];
  array_size5_samp = nlatsubs * nlonsubs * lccyears;

  if((fire_interp_local = calloc(array_size5_interp,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_interp_local.", -1);
  if((fire_samp_local = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_samp_local.", -1);
  if((burnls_data_scatter = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc burnls_data_scatter.", -1);
  callocsize = sizeof(char);
  if((burnls_data = calloc(array_size5,callocsize)) == NULL) callocerror = errmsg("failed calloc burnls_data.", -1);

  count_g5[0] = fireyears; //fire data is short, 27 years only
  ReadNCVara(infilen[47], invarn[47], NC_BYTE, start_g5, count_g5, burnls_data);
  //ReadNCVara("./input/mtbs_burnl_1984_2010_shrub_960m.nc", "burnlow", NC_BYTE, start_g5, count_g5, burnls_data);
  count_g5[0] = lccyears; //change back to lcc data length, 40 years

  interp_samp_char(burnls_data, fire_interp_local, fire_samp_local, burnls_data_scatter, 5);
  free(burnls_data);
  free(fire_interp_local);
  free(fire_samp_local);
  return;
}

void ncread8_6(int first){//for fire data
  float *fire_interp_local;
  float *fire_samp_local;
  int callocsize = sizeof(float);
  int callocerror = 0;

  array_size5_interp = count_g5[0]*count_g5[1]*count_g1[2]*count_g1[3];
  array_size5_samp = nlatsubs * nlonsubs * lccyears;

  if((fire_interp_local = calloc(array_size5_interp,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_interp_local.", -1);
  if((fire_samp_local = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_samp_local.", -1);
  if((burnhs_data_scatter = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc burnhs_data_scatter.", -1);
  callocsize = sizeof(char);
  if((burnhs_data = calloc(array_size5,callocsize)) == NULL) callocerror = errmsg("failed calloc burnhs_data.", -1);

  count_g5[0] = fireyears; //fire data is short, 27 years only
  ReadNCVara(infilen[48], invarn[48], NC_BYTE, start_g5, count_g5, burnhs_data);
  //ReadNCVara("./input/mtbs_burnh_1984_2010_shrub_960m.nc", "burnhigh", NC_BYTE, start_g5, count_g5, burnhs_data);
  count_g5[0] = lccyears; //change back to lcc data length, 40 years

  interp_samp_char(burnhs_data, fire_interp_local, fire_samp_local, burnhs_data_scatter, 5);
  free(burnhs_data);
  free(fire_interp_local);
  free(fire_samp_local);
  return;
}

void ncread8_7(int first){//for fire data
  float *fire_interp_local;
  float *fire_samp_local;
  int callocsize = sizeof(float);
  int callocerror = 0;

  array_size5_interp = count_g5[0]*count_g5[1]*count_g1[2]*count_g1[3];
  array_size5_samp = nlatsubs * nlonsubs * lccyears;

  if((fire_interp_local = calloc(array_size5_interp,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_interp_local.", -1);
  if((fire_samp_local = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc fire_samp_local.", -1);
  if((burnms_data_scatter = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc burnms_data_scatter.", -1);
  callocsize = sizeof(char);
  if((burnms_data = calloc(array_size5,callocsize)) == NULL) callocerror = errmsg("failed calloc burnms_data.", -1);

  count_g5[0] = fireyears; //fire data is short, 27 years only
  ReadNCVara(infilen[49], invarn[49], NC_BYTE, start_g5, count_g5, burnms_data);
  //ReadNCVara("./input/mtbs_burnm_1984_2010_shrub_960m.nc", "burnmix", NC_BYTE, start_g5, count_g5, burnms_data);
  count_g5[0] = lccyears; //change back to lcc data length, 40 years

  interp_samp_char(burnms_data, fire_interp_local, fire_samp_local, burnms_data_scatter, 5);
  free(burnms_data);
  free(fire_interp_local);
  free(fire_samp_local);

  return;
}

void ncread8_8(int first){//for fire data
  return;
}

void ncread8_9(int first){//for fire data
  return;
}

void ncread8_10(int first){//for fire data
  return;
}

void ncread9(int first){//for nitrogen deposition data
  float *ndep_interp_local;
  float *ndep_samp_local;
  int callocsize = sizeof(float);
  int callocerror = 0;

  count_g5[0] = lccyears; //lcc/ndep data length, 40 years
  array_size5_interp = count_g5[0]*count_g5[1]*count_g1[2]*count_g1[3];
  array_size5_samp = nlatsubs * nlonsubs * lccyears;

  if((ndep_interp_local = calloc(array_size5_interp,callocsize)) == NULL) callocerror = errmsg("failed calloc ndep_interp_local.", -1);
  if((ndep_samp_local = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc ndep_samp_local.", -1);
  if((ndep_data_scatter = calloc(array_size5_samp,callocsize)) == NULL) callocerror = errmsg("failed calloc ndep_data_scatter.", -1);
  callocsize = sizeof(char);
  if((ndep_data = calloc(array_size5,callocsize)) == NULL) callocerror = errmsg("failed calloc ndep_data.", -1);

  count_g5[0] = ndepyears; //ndep data is short, 40 years, lcc 45 years
  ReadNCVara(infilen[50], invarn[50], NC_BYTE, start_g5, count_g5, ndep_data);
  //ReadNCVara("./input/ndep1970_2009_scale_10_char.nc", "ndep", NC_BYTE, start_g5, count_g5, ndep_data);
  count_g5[0] = lccyears; //change back to lcc data length, 45 years
  interp_samp_char(ndep_data, ndep_interp_local, ndep_samp_local, ndep_data_scatter, 5);
  free(ndep_data);
  free(ndep_interp_local);
  free(ndep_samp_local);

  return;
}

////////////////////

void ncwrite(){
    int i, j, k;

    /*Create primary NetCDF files for holding output variables*/
    char targetfile[100], variablename[10];
    char dim_name[10][10], var_dim_name[10][10];
    int *dim1, *dim2, *dim3, *dim4, *dim_data[4];
    size_t startx[4], countx[4];
    int row, col;
    int ndims;
    nc_type nctype;
    float missing_value;

    strcpy( dim_name[0], "time" );
    strcpy( dim_name[1], "level" );
    strcpy( dim_name[2], "latitude" );
    strcpy( dim_name[3], "longitude" );
    strcpy( dim_name[4], "" );
    strcpy( var_dim_name[0], "time" );
    strcpy( var_dim_name[1], "level" );
    strcpy( var_dim_name[2], "latitude" );
    strcpy( var_dim_name[3], "longitude" );
    strcpy( var_dim_name[4], "" );
    if(1){
      startx[0] = 0;
      startx[1] = 0;
      startx[2] = 0;
      startx[3] = 0;
      countx[0] = saveyears;
      countx[1] = 1;
      //countx[2] = count_g1[2];
      //countx[3] = count_g1[3];
      countx[2] = nlatsubs;
      countx[3] = nlonsubs;
      row = countx[2];
      col = countx[3];

      dim1 = (int*) malloc(sizeof(float)*countx[0]);
      dim2 = (int*) malloc(sizeof(float)*countx[1]);
      dim3 = (int*) malloc(sizeof(float)*countx[2]);
      dim4 = (int*) malloc(sizeof(float)*countx[3]);

      dim4[0]= 1;
      for(i=1;i<countx[3];i++){
        dim4[i]=dim4[i-1]+1;
      }
      dim3[0]= countx[2];
      for(i=1;i<countx[2];i++){
        dim3[i]=dim3[i-1]-1;
      }
      dim2[0]= 1;
      for(i=1;i<countx[1];i++){
        dim2[i]=dim2[i-1]+1;
      }
      dim1[0]= 1;
      for(i=1;i<countx[0];i++){
        dim1[i]=dim1[i-1]+1;
      }

      dim_data[0] = dim1;
      dim_data[1] = dim2;
      dim_data[2] = dim3;
      dim_data[3] = dim4;

      if(out0single == 1){
        writex4(invert_0, "aynpptot.nc", "Annual total NPP", "aynpptot", "kg C/m2/yr", 
              dim_name, dim_data, startx, countx);
      }
      else{
        writex4(invert_aynpptot, "aynpptot.nc", "Annual total NPP", "aynpptot", "kg C/m2/yr", 
              dim_name, dim_data, startx, countx);
      }

      free (dim1);
      free (dim2);
      free (dim3);
      free (dim4);
    }

  return;
}

void writex4(float *var4, char *targetfile, char *title, char *varname, char *units, char dim_name[][10], int *dim_data[], size_t *startx, size_t *countx){

    /*Create primary NetCDF files for holding output variables*/
    if(1){
      CreateNCFile(targetfile, dim_name, startx, countx, dim_data);
      CreateNCVar(targetfile, varname, NC_FLOAT, 4, dim_name);
      //SetNCAttribute(targetfile, "", "title", NC_CHAR, title, 0);
      SetNCAttribute(targetfile, "time", "units", NC_CHAR, "year", 0);
      SetNCAttribute(targetfile, "level", "units", NC_CHAR, "none", 0);
      SetNCAttribute(targetfile, "latitude", "units", NC_CHAR, "1km", 0);
      SetNCAttribute(targetfile, "longitude", "units", NC_CHAR, "1km", 0);
      SetNCAttribute(targetfile, varname, "units", NC_CHAR, units, 0);
      SetNCAttribute(targetfile, varname, "missing_value", NC_FLOAT, "", -9999);
      WriteNCVara(targetfile, varname, NC_FLOAT, startx, countx, var4);
      //free (var4);
    }

  return;
}

void rdscaler(){
  FILE *fp1;
  char msg[200];
  int i,j,k,l;

  /* read paramsx.scl */
  int nfipsa, fips1, region1, region2;
  float tempval[9];

  if ((fp1 = fopen(paramfn[7], "rt"))==NULL){
  //if ((fp1 = fopen("paramsx.scl", "rt"))==NULL){
    printf("paramsx.scl file not found! \n");
    return;
  }

  nfipsa = 0;
  for(i=0; i<nfips; i++){
    fipscode[i] = 0;
  }

  for(i=0; i<total_npoi; i++){
    //fips1 = fips_data[i];
    fips1 = (int)ecoreg_data[i];
    for(k=0; k<nfips; k++){
      if(fips1 == fipscode[k]){
        fips123[i] = k;
        break;
      }
      else{
        if(fipscode[k] == 0){
          nfipsa = nfipsa + 1;
          fipscode[k] = fips1;
          fips123[i] = k;
          break;
        }
      }
    }

  }

  k = 0;
  for(i=0; i<totfips; i++){
    fscanf(fp1,"%d%f%f%f%f%f%f%f%f%f", &region1,&tempval[0],&tempval[1],&tempval[2],
           &tempval[3],&tempval[4],&tempval[5],&tempval[6],&tempval[7],&tempval[8]);
    fgets(msg, 200, fp1);

    for(j=0; j<nfipsa; j++){
      if(region1 == fipscode[j]){
        for(l=0;l<9;l++){
          vectors[l+j*9] = tempval[l];
          //scalers[j][l] = tempval[l];
        }
        k = k + 1;
        break;
      }
    }
    if(k == nfipsa){
      break;
    }
  }

  fclose(fp1);
  return;
}

void rdlanduse(){
  FILE *fp1;
  char msg[200];
  int i,j,k,l;

  /* read paramsx.luc */
  int nfipsa, fips1, region1, region2;
  float tempval[9];

  if ((fp1 = fopen(paramfn[8], "rt"))==NULL){
  //if ((fp1 = fopen("paramsx.luc", "rt"))==NULL){
    printf("paramsx.luc file not found! \n");
    return;
  }

  nfipsa = 0;
  for(i=0; i<nfips; i++){
    fipscode[i] = 0;
  }

  for(i=0; i<total_npoi; i++){
    //fips1 = fips_data[i];     //when use county level data
    fips1 = (int)ecoreg_data[i];//when use ecoregion level data
    for(k=0; k<nfips; k++){
      if(fips1 == fipscode[k]){
        fips123[i] = k;
        break;
      }
      else{
        if(fipscode[k] == 0){
          nfipsa = nfipsa + 1;
          fipscode[k] = fips1;
          fips123[i] = k;
          break;
        }
      }
    }
  }

  k = 0;
  for(i=0; i<totfips; i++){
    fscanf(fp1,"%d%f%f%f%f%f%f%f%f%f", &region1,&tempval[0],&tempval[1],&tempval[2],
           &tempval[3],&tempval[4],&tempval[5],&tempval[6],&tempval[7],&tempval[8]);
    fgets(msg, 200, fp1);

    for(j=0; j<nfipsa; j++){
      if(region1 == fipscode[j]){
        for(l=0;l<9;l++){
          vectorl[l+j*9] = tempval[l];
          //scalers[j][l] = tempval[l];
        }
        k = k + 1;
        break;
      }
    }
    if(k == nfipsa){
      break;
    }
  }

  fclose(fp1);
  return;
}


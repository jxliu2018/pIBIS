/*                      
                 _                   ___   ___  _                           
 _ __ ___   __ _(_)_ __       _ __  / _ \ / _ \/ |    ___ _ __ __ _ _   _   
| '_ ` _ \ / _` | | '_ \     | '_ \| | | | | | | |   / __| '__/ _` | | | |  
| | | | | | (_| | | | | |    | |_) | |_| | |_| | |  | (__| | | (_| | |_| |_ 
|_| |_| |_|\__,_|_|_| |_|____| .__/ \___/ \___/|_|___\___|_|  \__,_|\__, (_)
                       |_____|_|                |_____|             |___/   
*/
//main_p001_cray.c ~ pibis parameter and 1-layer input maps pre-processing
//Wanjing Wei, pnetcdf procedures
//Jinxun Liu, updated 6/18/2019
//jxliu@usgs.gov

#define  EXTERN

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "netcdf.h"
#include "ibis_common_p.h"

const int dimcnt = 20;
int vectorp_len = 1200;
int vectors_len = nfips*9;
int vectorl_len = nfips*9;

char dimnames[][50] = {
"array_size1", "array_size1_samp", "array_size1_interp",
"array_size2", "array_size2_samp", "array_size2_interp",
"array_size3", "array_size3_samp", "array_size3_interp",
"array_size4", "array_size4_samp", "array_size4_interp",
"array_size5", "array_size5_samp", "array_size5_interp",
"vectorp_len", "vectors_len", "vectorl_len",
"array_size4_interp_s", "array_size4_interp_x"
};

int dimid[50];
int ncid0;
int ncid, varid[105];
int varcnt = 33;

char varnames[][105] = {
"vectorp", "vectors", "vectorl",
"surta_data", "serial_id_samp", "cell_lat_data", "cell_area_data", "topo_data",
"vegtype0_data", "ecoreg_data", "fips_data", "fips123", "wetland_data", "biomf_c_data",
"bioms_c_data", "biomg_c_data", "nh4dep_data", "no3dep_data", "burnlow_data",
"burnmix_data", "burnhigh_data", "pct_for_data", "pct_shr_data", "pct_gra_data",
"pct_agr_data", "pct_c3crop_data", "pct_wdcrop_data", "pct_wetland_data",
"pct_nveg_data", "soilc_data", "owner_type_data","nmmax_data", "deltat_norm_data_interp",
};

int vardimind[] = {
15,16,17,
0,1,0,0,0,//0 for one-layer map before sampling; 1 for serial ID after sampling
0,0,0,0,0,0,
0,0,0,0,0,
0,0,0,0,0,
0,0,0,0,
0,0,0,0,8,//8 for deltat interp?
};

nc_type vartypes[] = {
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_CHAR, NC_INT, NC_FLOAT, NC_CHAR, NC_FLOAT,
NC_CHAR, NC_CHAR, NC_INT, NC_INT, NC_CHAR, NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT, NC_FLOAT, NC_CHAR,
NC_CHAR, NC_CHAR, NC_CHAR, NC_CHAR, NC_CHAR,
NC_CHAR, NC_CHAR, NC_CHAR, NC_CHAR,
NC_CHAR, NC_FLOAT, NC_CHAR, NC_FLOAT, NC_FLOAT,  //non_veg, soilc, owner, nmmax, deltat
};

void data_init(int rank) {
  int flag = 1;
  if(rank == 0){
    readnames();//read netcdf and params file names
      printf("passed readnames()\n");
    rdinfile(); //read the control file
      printf("passed rdinfile()\n");
    rdparam();  //read all the fixed parameters
      printf("passed rdparam()\n");
    ncread0(flag);  //read map parameters for netcdf processing
      printf("passed ncread0()\n");
  }

}//data_init(int rank)

int main(int argc, char* argv[])
{
  if(argc > 1) {
    printf("global0.nc already exist, may not calcualte valid_segment\n");
    fprintf(stderr, "global0.nc already exist, may not calcualte valid_segment\n");
    exit(1);
  }

  data_init(0);
  return 0;
}

//------------------------------------------------------------------------
void calc_valid_seg(){
    FILE *fp2, *fp3, *fp4;

    int i, j, k, l, ii, jj, iii, jjj;
    int seg_all;
    int ecoreg_id, fips_id, valid_ecoreg, valid_fips;
    int total_ecoreg = 100;
    int total_fips = 3200;
    int ecoreg_list[100], fips_list[3200];

    if ((fp2 = fopen("valid_segments.txt", "wt"))==NULL){
      return;
    }
    if ((fp3 = fopen("valid_ecoreg.txt", "wt"))==NULL){
      return;
    }
    if ((fp4 = fopen("valid_fips.txt", "wt"))==NULL){
      return;
    }

    for(i=0;i<total_ecoreg;i++){
      ecoreg_list[i] = -1;
    }
    for(i=0;i<total_fips;i++){
      fips_list[i] = -1;
    }

    segment_npoi = 0;
    valid_segment = 0;
    l = 0;
    for(i=0;i<total_npoi;i++){ //sampling single layer maps
      ii = i/nlonsub;//original row
      jj = i%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = iii*nlonsubs + jjj; //serial id after sampling (k <= i)
        l = k/npoi; //segment_id after sampling

        if(surta_data[i] == 1)//be aware of integer promotion issue, -15 -> 222?
          segment_npoi = segment_npoi + 1; //add mask in segment

        if(k%npoi == npoi-1){
          valid_segment_npoi[l] = 0;
          if(segment_npoi > 0){
            valid_segment_npoi[l] = segment_npoi;
            valid_segment = valid_segment + 1;
          }
          seg_all = l+1;
          segment_npoi = 0;
        }

        if(surta_data[i] == 1){
	  ecoreg_id = ecoreg_data[i];
	  for(j=0;j<total_ecoreg;j++){
            if(ecoreg_id == ecoreg_list[j]){//i.e. this ecoreg is already counted
              break;
	    }
	    else{
              if(ecoreg_list[j] == -1){
		ecoreg_list[j] = ecoreg_id;
                valid_ecoreg = valid_ecoreg + 1;
                fprintf(fp3, "%d\n", ecoreg_id);
		break;
	      }
	      else{
		continue;
	      }
	    }
	  }

	  fips_id = fips_data[i];
	  for(j=0;j<total_fips;j++){
            if(fips_id == fips_list[j]){//i.e. this fips is already counted
              break;
            }
            else{
              if(fips_list[j] == -1){
                fips_list[j] = fips_id;
                valid_fips = valid_fips + 1;
                fprintf(fp4, "%d\n", fips_id);
                break;
              }
              else{
                continue;
              }
            }
	  }
        }
      }
    }

    if(valid_segment <= 0){
      printf("no valid segment, exit now!\n");
      exit(-1);
    }

    fprintf(fp2, "%d\n", nlatsubs);
    fprintf(fp2, "%d\n", nlonsubs);
    fprintf(fp2, "%d\n", npoi);
    fprintf(fp2, "%d\n", valid_segment);
    fprintf(fp2, "%d\n", saveyears);
    for(l=0; l<seg_all; l++){
      fprintf(fp2, "%d\n", valid_segment_npoi[l]);
    }

    fprintf(fp3, "total valid ecoreg: %d\n", valid_ecoreg);
    fprintf(fp4, "total valid fips: %d\n", valid_fips);

    fclose(fp2);
    fclose(fp3);
    fclose(fp4);

    return;
}

void interp_samp_char(char *sourcex, float *interpx, float *sampx, float *targetx, int group){
}

void interp_samp_float(float *sourcex, float *interpx, float *sampx, float *targetx, int group){
}

void interp_float(float *sourcex, float *interpx, float *targetx, int group, int group_s){
}

void interp_samp_float_anom(float *sourcex, float *interpx, float *sampx, float *targetx, int group, int group_s){
}

void interp(){
}

void datapack(){//do this on each rank after MPI_Scatter()
}

void invertp0(char *output_name){
}

void invertp(){
}

void invert_npp(){
}

void writeDat(float *var4, char *targetfile, int array_length, int elementsize){
}

int errmsg(const char *msg, int retval) {
    //fprintf(stderr, "%s\n", msg);
    printf("%s\n", msg);
    return retval;
}


/*
 _                        _          _  __
(_) ___        _ __   ___| |_ ___ __| |/ _| ___
| |/ _ \ _____| '_ \ / _ \ __/ __/ _` | |_ / __|
| | (_) |_____| | | |  __/ || (_| (_| |  _| (__
|_|\___/      |_| |_|\___|\__\___\__,_|_|(_)___|

*/
//io-netcdf.c
//Jinxun Liu, recently updated 05/23/2015
//jxliu@usgs.gov

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include "netcdf.h"

  char * ncfilename;
  int nc_id;
  int ndims;
  int nvars;
  int ngatts;
  int unlimdimid;

  char dim_name[10][10],var_dim_name[10][10];
  int dim_ids[10];
  size_t dim_lens[10];

  char var_names[10][10];
  int var_ids[10];
  int var_ndims[10];
  int var_dimids[10][10];
  int var_natts[10];
  nc_type var_type[10], nctype;

  char att_txt[10][10][100];
  char att_names[10][10][20];
  nc_type att_type[10][10];
  size_t  att_len;
  double att_val[10][10];
  int *dim1,*dim2,*dim3,*dim4;

  int ncvar_dimids[4]; //this is only for creatinting NC file, max var dim = 4
  char sourcefile[100], targetfile[100], variablename[10], variablenamet[10];

void GetNCInfo(char *ncfilename)
{
  //char * ncfilename;
  int nc_id;
  int ndims;
  int nvars;
  int ngatts;
  int unlimdimid;

  char dim_name[10][10],var_dim_name[10][10];
  int dim_ids[10];
  size_t dim_lens[10];

  char var_names[10][10];
  int var_ids[10];
  int var_ndims[10];
  int var_dimids[10][10];
  int var_natts[10];
  nc_type var_type[10], nctype;

  char att_txt[10][10][100];
  char att_names[10][10][20];
  nc_type att_type[10][10];
  size_t  att_len;
  double att_val[10][10];
  int *dim1,*dim2,*dim3,*dim4;

  int ncvar_dimids[4];
  char sourcefile[100], targetfile[100], variablename[10], variablenamet[10];

  int status;

  // create TXT file for writing NC infomation
  FILE *NCInfoFile;
  if ((NCInfoFile = fopen("nc_info.txt", "wt")) == NULL)
  {
     printf("Cannot open output file\n");
     return;
  }

  // open NC file for reading NC infomation
  status = nc_open(ncfilename,NC_NOWRITE,&nc_id);
  if(status != NC_NOERR) {
    printf("Error opening source NETCDF file: %s\n", ncfilename);
    return;
  }
  int i, j;

  // get general NC info
  status = nc_inq(nc_id, &ndims, &nvars, &ngatts, &unlimdimid);
  if(status != NC_NOERR) {
    printf("Error in nc_inq()\n");
    return;
  }
  if(unlimdimid>0){
    fprintf(NCInfoFile, "%s\n%s\n",ncfilename,"This NC file is likely created from FORTRAN program");
  }
  else if(unlimdimid==0){
    fprintf(NCInfoFile, "%s\n%s\n",ncfilename,"This NC file is likely created from C, C++ program");
  }
  else{
    fprintf(NCInfoFile, "%s\n%s\n",ncfilename,"This NC file is created from C, or C++ if time dimision ID is zero;");
    fprintf(NCInfoFile, "%s\n","Otherwise, it is created from FORTRAN");
  }
  fprintf(NCInfoFile, "\n%s\n","GENERAL");
  fprintf(NCInfoFile, "%-25s\t %d\n","total dimemsions:",ndims);
  fprintf(NCInfoFile, "%-25s\t %d\n","total variables:            ",nvars);
  fprintf(NCInfoFile, "%-25s\t %d\n","total global attributes:",ngatts);
  fprintf(NCInfoFile, "%-25s\t %d\n","unlimited dimention id:",unlimdimid);

  // get all dimension info
  fprintf(NCInfoFile, "\n%s\n","DIMENSIONS");
  fprintf(NCInfoFile, "%s\t%s\t%s\n","dim_id","legenth","dim_name");
  for(i = 0; i < ndims; i++) {
    status = nc_inq_dim(nc_id, i, dim_name[i], &dim_lens[i]);
    if(status != NC_NOERR) {
      printf("Error in nc_inq_dim()\n");
      return;
    }
    dim_ids[i] = i;
    fprintf(NCInfoFile, "%d\t%d\t%s\n",dim_ids[i],dim_lens[i],dim_name[i]);
  }

  // get all variable info
  fprintf(NCInfoFile, "\n%s\n","VARIABLES");
  fprintf(NCInfoFile, "%s\t%-10s\t%s\t%s\t%s\t%s\n","var_id","name","type","ndims","natts","dim_ids");
  for(i = 0; i < nvars; i++) {
    var_ids[i] = i;
    status = nc_inq_var(nc_id, i, var_names[i], &var_type[i], &var_ndims[i], var_dimids[i], &var_natts[i]);
    if(status != NC_NOERR) {
      printf("Error in nc_inq_var()\n");
      return;
    }
    fprintf(NCInfoFile, "%d\t%-10s\t%d\t%d\t%d\t",i,var_names[i],(int)var_type[i],var_ndims[i],var_natts[i]);
    for (j=0; j<var_ndims[i];j++){
      fprintf(NCInfoFile, "%d ",var_dimids[i][j]);
    }
    fprintf(NCInfoFile, "\n","");
  }
  fprintf(NCInfoFile, "\n%s\n","-- Valid NETCDF data types are:");
  fprintf(NCInfoFile,"-- 1. NC_BYTE, 2. NC_CHAR, 3. NC_SHORT, 4. NC_INT, 5. NC_FLOAT, 6. NC_DOUBLE\n");

  // get all attributes info
  fprintf(NCInfoFile, "\n%s\n","ATTRIBUTES");
  status = nc_inq_att(nc_id, NC_GLOBAL, "title", &att_type[9][0], &att_len);
  if(status != NC_NOERR) {
    printf("Error in nc_inq_att()\n");
    return;
  }
  if(att_len > 0) {
    strcpy(att_txt[9][0],"");
    nc_get_att_text(nc_id,NC_GLOBAL,"title", att_txt[9][0]);
    att_txt[9][0][att_len] = '\0';
    fprintf(NCInfoFile, "%s %s\n","global:",att_txt[9][0]);
  }
  else{
    fprintf(NCInfoFile, "%s\n","No global attribute");
  }
  fprintf(NCInfoFile,"\nVariable-Name: Attribute-Name = Attribute\t Attribute-Type\n\n");
  for(i = 0; i < nvars; i++) {
    for(j = 0; j < var_natts[i]; j++) {
      nc_inq_attname(nc_id, i, j, att_names[i][j]);
      nc_inq_atttype(nc_id, i, att_names[i][j], &att_type[i][j]);
      nc_inq_attlen (nc_id, i, att_names[i][j], &att_len);
      if(att_type[i][j] == 2){
        strcpy(att_txt[i][j],"");
        nc_get_att_text(nc_id, i, att_names[i][j], att_txt[i][j]);
        att_txt[i][j][att_len] = '\0';
        fprintf(NCInfoFile, "%-10s\t: %-15s\t = %10s\t %s\n",var_names[i],att_names[i][j],att_txt[i][j],"NC_CHAR, text");
      }
      else if(att_type[i][j] == 3){
        nc_get_att_double(nc_id, i, att_names[i][j], &att_val[i][j]);
        fprintf(NCInfoFile, "%-10s\t: %-15s\t = %10.2f\t %s\n",var_names[i],att_names[i][j],att_val[i][j],"NC_SHORT, value");
      }
      else if(att_type[i][j] == 4){
        nc_get_att_double(nc_id, i, att_names[i][j], &att_val[i][j]);
        fprintf(NCInfoFile, "%-10s\t: %-15s\t = %10.2f\t %s\n",var_names[i],att_names[i][j],att_val[i][j],"NC_INT, value");
      }
      else if(att_type[i][j] == 5){
        nc_get_att_double(nc_id, i, att_names[i][j], &att_val[i][j]);
        fprintf(NCInfoFile, "%-10s\t: %-15s\t = %10.2f\t %s\n",var_names[i],att_names[i][j],att_val[i][j],"NC_FLOAT, value");
      }
      else if(att_type[i][j] == 6){
        nc_get_att_double(nc_id, i, att_names[i][j], &att_val[i][j]);
        fprintf(NCInfoFile, "%-10s\t: %-15s\t = %10.2f\t %s\n",var_names[i],att_names[i][j],att_val[i][j],"NC_DOUBLE, value");
      }
    }
  }
  nc_close(nc_id);
  fclose(NCInfoFile);
}
//---------------------------------------------------------------------------

void CreateNCFile(char *ncfilename, char names[][10], size_t *start, size_t *count, int *dim_data[])
{
  int tmp_nc_id;
  int time_dimid, level_dimid, lat_dimid, lon_dimid, jfd_dimid;
  int time_id, level_id, lat_id, lon_id, jfd_id;
  int ndim = 0, ndim_id[4];
  int dim_id[4];
  int status, tmp_dim_id;
  int i;

  for(i=0; i<4; i++){
    if(names[i] != "") ndim++;
  }

  status = nc_open(ncfilename,NC_WRITE,&tmp_nc_id);
  if(status != NC_NOERR) {
    status = nc_create(ncfilename,NC_NOCLOBBER,&tmp_nc_id);
    if(status != NC_NOERR) {
      printf("Error in nc_create() %s\n", ncfilename);
      return;
    }
    for(i=0; i<ndim; i++){
      nc_def_dim(tmp_nc_id, names[i], count[i], &ndim_id[i]);
      nc_def_var(tmp_nc_id, names[i], NC_INT, 1, &ndim_id[i], &dim_id[i]);
    }
    nc_enddef(tmp_nc_id);

    for(i=0; i<ndim; i++){
      status = nc_put_var_int(tmp_nc_id,dim_id[i],dim_data[i]);
      if(status != NC_NOERR) {
        printf("Error in nc_put_var_int() %s\n", ncfilename);
        return;
      }
    }
    nc_close(tmp_nc_id);
  }
  else{
    for(i=0; i<ndim; i++){
      nc_redef(tmp_nc_id);
      status = nc_inq_dimid(tmp_nc_id, names[i], &tmp_dim_id);
      if(status != 0){
        nc_def_dim(tmp_nc_id, names[i], count[i], &ndim_id[i]);
        nc_def_var(tmp_nc_id, names[i], NC_INT, 1, &ndim_id[i], &dim_id[i]);
      }
    }
    nc_enddef(tmp_nc_id);

    for(i=0; i<ndim; i++){
      status = nc_put_var_int(tmp_nc_id,dim_id[i],dim_data[i]);
      if(status != NC_NOERR) {
        printf("Error in nc_put_var_int() %s\n", ncfilename);
        return;
      }
    }
    nc_close(tmp_nc_id);
  }
}
//---------------------------------------------------------------------------
void CreateNCVar(char *ncfilename, char *ncvarname, nc_type nctype,
                         int ndims, char ncvar_dimnames[][10])
{
  int tmp_nc_id;
  int tmp_var_id;
  int i;
  int status;

  status = nc_open(ncfilename,NC_WRITE,&tmp_nc_id);
  if(status != NC_NOERR) {
    printf("Error writing NC file %s\n", ncfilename);
    return;
  }
  for(i=0; i<ndims; i++){
    nc_inq_dimid(tmp_nc_id, ncvar_dimnames[i], &ncvar_dimids[i]);
  }
  nc_redef(tmp_nc_id);
  nc_def_var(tmp_nc_id, ncvarname, nctype, ndims, ncvar_dimids, &tmp_var_id);
  nc_enddef(tmp_nc_id);
  nc_close(tmp_nc_id);
}
//---------------------------------------------------------------------------

void WriteNCVara(char *ncfilename, char *ncvarname, nc_type nctype, size_t *start, size_t *count, void *tp)
{
  int tmp_nc_id, tmp_var_id;
  nc_type xtype;
  int status;

  status = nc_open(ncfilename,NC_WRITE,&tmp_nc_id);
  if(status != NC_NOERR) {
    printf("Error writing NC file %s\n", ncfilename);
    return;
  }
  status = nc_inq_varid(tmp_nc_id, ncvarname, &tmp_var_id);
  if(status != NC_NOERR) {
    printf("Error in nc_inq_varid()\n");
    return;
  }
  status = nc_inq_vartype(tmp_nc_id, tmp_var_id, &xtype);
  if(status != NC_NOERR) {
    printf("Error in nc_inq_vartype()\n");
    return;
  }

  if(xtype == NC_BYTE && nctype == 1){
    unsigned char * tpp = (unsigned char *) tp;
    nc_put_vara_uchar(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_BYTE && nctype == 2){ //add this for animating signed char data
    const signed char * tpp = (const signed char *) tp;
    nc_put_vara_schar(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_CHAR){//this char data can not be animated with its 'char nc type'
    const signed char * tpp = (const signed char *) tp;
    nc_put_vara_schar(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_SHORT){
    short * tpp = (short *) tp;
    nc_put_vara_short(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_INT){
    int * tpp = (int *) tp;
    nc_put_vara_int(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_FLOAT){
    float * tpp = (float *) tp;
    nc_put_vara_float(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_DOUBLE){
    double * tpp = (double *) tp;
    nc_put_vara_double(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else{
    printf("Wrong data type (not a nc_type 1~6)\n");
  }
  if(status != NC_NOERR) {
    printf("Error in nc_put_vara() for file %s\n",ncfilename);
    return;
  }
  nc_close(tmp_nc_id);
}
//---------------------------------------------------------------------------

void ReadNCVara(char *ncfilename, char *ncvarname, nc_type nctype, size_t *start, size_t *count, void *tp)
{
  int tmp_nc_id, tmp_var_id;
  nc_type xtype;
  int status;

  status = nc_open(ncfilename,NC_NOWRITE,&tmp_nc_id);
  if(status != NC_NOERR) {
    printf("Error opening NC file %s\n", ncfilename);
    return;
  }
  status = nc_inq_varid(tmp_nc_id, ncvarname, &tmp_var_id);
  if(status != NC_NOERR) {
    printf("Error in nc_inq_varid() %s, %s\n", ncfilename, ncvarname);
    return;
  }
  status = nc_inq_vartype(tmp_nc_id, tmp_var_id, &xtype);
  if(status != NC_NOERR) {
    printf("Error in nc_inq_vartype() %s, %s, %d\n", ncfilename, ncvarname, xtype);
    return;
  }

  if(xtype == NC_BYTE && nctype == 1){
    unsigned char * tpp = (unsigned char *) tp;
    status = nc_get_vara_uchar(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_BYTE && nctype == 2){ //add this for animating signed char data
    signed char * tpp = (signed char *) tp;
    status = nc_get_vara_schar(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_CHAR){//this char data can not be animated with its 'char nc type'
    signed char * tpp = (signed char *) tp;
    status = nc_get_vara_schar(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_SHORT){
    short * tpp = (short *) tp;
    status = nc_get_vara_short(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_INT){
    int * tpp = (int *) tp;
    status = nc_get_vara_int(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_FLOAT){
    float * tpp = (float *) tp;
    status = nc_get_vara_float(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_DOUBLE){
    double * tpp = (double *) tp;
    status = nc_get_vara_double(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else{
    printf("Wrong data type (not a nc_type 1~6)\n");
  }
  if(status != NC_NOERR) {
    printf("Error in nc_get_vara() for file %s, %s\n",ncfilename, ncvarname);
    return;
  }
  nc_close(tmp_nc_id);
}

void SetNCAttribute(char *ncfilename, char *ncvarname, char *attname, nc_type nctype, char *att, float attval)
{
  int tmp_nc_id, tmp_var_id, str_length, status;

  status = nc_open(ncfilename,NC_WRITE,&tmp_nc_id);
  if(status != NC_NOERR) {
    printf("Error opening NC file %s\n", ncfilename);
    return;
  }
  nc_redef(tmp_nc_id);

  str_length = strlen(att);

  if(strcmp(attname,"title") == 0){
    nc_put_att_text(tmp_nc_id, NC_GLOBAL, "title", str_length, att);
  }

  status = nc_inq_varid (tmp_nc_id, ncvarname, &tmp_var_id);
  if(status != NC_NOERR) {
    printf("Error in nc_inq_varid()\n");
    return;
  }

  if(nctype == NC_CHAR){
    nc_put_att_text(tmp_nc_id, tmp_var_id, attname, str_length, att);
  }
  else{
    nc_put_att_float(tmp_nc_id, tmp_var_id, attname, NC_FLOAT, 1, &attval);
  }
  nc_enddef(tmp_nc_id);
  nc_close(tmp_nc_id);
}

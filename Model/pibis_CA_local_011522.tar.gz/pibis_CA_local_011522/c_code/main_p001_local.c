/*                      
                 _                   ___   ___  _                           
 _ __ ___   __ _(_)_ __       _ __  / _ \ / _ \/ |    ___ _ __ __ _ _   _   
| '_ ` _ \ / _` | | '_ \     | '_ \| | | | | | | |   / __| '__/ _` | | | |  
| | | | | | (_| | | | | |    | |_) | |_| | |_| | |  | (__| | | (_| | |_| |_ 
|_| |_| |_|\__,_|_|_| |_|____| .__/ \___/ \___/|_|___\___|_|  \__,_|\__, (_)
                       |_____|_|                |_____|             |___/   
*/
//main_p001_cray.c ~ pibis parameter and 1-layer input maps pre-processing
//Wanjing Wei, pnetcdf procedures
//Jinxun Liu, updated 6/18/2019
//jxliu@usgs.gov

#define  EXTERN

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "netcdf.h"
#include "ibis_common_p.h"

const int dimcnt = 20;
int vectorp_len = 1200;
int vectors_len = nfips*9;
int vectorl_len = nfips*9;

char dimnames[][50] = {
"array_size1", "array_size1_samp", "array_size1_interp",
"array_size2", "array_size2_samp", "array_size2_interp",
"array_size3", "array_size3_samp", "array_size3_interp",
"array_size4", "array_size4_samp", "array_size4_interp",
"array_size5", "array_size5_samp", "array_size5_interp",
"vectorp_len", "vectors_len", "vectorl_len",
"array_size4_interp_s", "array_size4_interp_x"
};

int dimid[50];
int ncid0;
int ncid, varid[105];
int varcnt = 33;

char varnames[][105] = {
"vectorp", "vectors", "vectorl",
"surta_data", "serial_id_samp", "cell_lat_data", "cell_area_data", "topo_data",
"vegtype0_data", "ecoreg_data", "fips_data", "fips123", "wetland_data", "biomf_c_data",
"bioms_c_data", "biomg_c_data", "nh4dep_data", "no3dep_data", "burnlow_data",
"burnmix_data", "burnhigh_data", "pct_for_data", "pct_shr_data", "pct_gra_data",
"pct_agr_data", "pct_c3crop_data", "pct_wdcrop_data", "pct_wetland_data",
"pct_nveg_data", "soilc_data", "owner_type_data","nmmax_data", "deltat_norm_data_interp",
};

int vardimind[] = {
15,16,17,
0,1,0,0,0,//0 for one-layer map before sampling; 1 for serial ID after sampling
0,0,0,0,0,0,
0,0,0,0,0,
0,0,0,0,0,
0,0,0,0,
0,0,0,0,8,//8 for deltat interp?
};

nc_type vartypes[] = {
NC_FLOAT, NC_FLOAT, NC_FLOAT,
NC_CHAR, NC_INT, NC_FLOAT, NC_CHAR, NC_FLOAT,
NC_CHAR, NC_CHAR, NC_INT, NC_INT, NC_CHAR, NC_FLOAT,
NC_FLOAT, NC_FLOAT, NC_FLOAT, NC_FLOAT, NC_CHAR,
NC_CHAR, NC_CHAR, NC_CHAR, NC_CHAR, NC_CHAR,
NC_CHAR, NC_CHAR, NC_CHAR, NC_CHAR,
NC_CHAR, NC_FLOAT, NC_CHAR, NC_FLOAT, NC_FLOAT,  //non_veg, soilc, owner, nmmax, deltat
};
void data_init(int rank) {
  int flag = 0;
  int status;
  int i;
  if(rank == 0){
    status = nc_create("global0.nc", NC_NOCLOBBER, &ncid0);
        if (status == NC_NOERR) flag = 1;
    readnames();//read netcdf and params file names
      printf("passed readnames()\n");
    rdinfile(); //read the control file
      printf("passed rdinfile()\n");
    rdparam();  //read all the fixed parameters
      printf("passed rdparam()\n");
    ncread0(flag);  //read map parameters for netcdf processing
      printf("passed ncread0()\n");
    ncread1(flag);  //read single layer maps
      printf("passed ncread1() on rank 0  -- all single layer data\n");

    use_anom[0] = 1;
    use_lcc[0] = 1;
    use_fire[0] = 1;
    use_ndep[0] = 1;
    biom_reset[0] = 0;
    if(iyranom > iyear0 + nrun)
      use_anom[0] = 0;
    if(isimfire > iyear0 + nrun)
      use_fire[0] = 0;
    if(events > iyear0 + nrun)
      use_lcc[0] = 0;
    if(isimco2 == 0)
      use_ndep[0] = 0;
    if(idiag > 0)
      biom_reset[0] = idiag;
  }

  void* varpointers[] = {
  vectorp, vectors, vectorl,
  surta_data, serial_id_samp, cell_lat_data, cell_area_data, topo_data,
  vegtype0_data, ecoreg_data, fips_data, fips123, wetland_data, biomf_c_data,
  bioms_c_data, biomg_c_data, nh4dep_data, no3dep_data, burnlow_data,
  burnmix_data, burnhigh_data, pct_for_data, pct_shr_data, pct_gra_data,
  pct_agr_data, pct_c3crop_data, pct_wdcrop_data, pct_wetland_data,
  pct_nveg_data, soilc_data, owner_type_data, nmmax_data, deltat_norm_data_interp,
  };

  if (rank == 0) {
    if (flag) {
      int dimnums[] = {
        array_size1, array_size1_samp, array_size1_interp,
        array_size2, array_size2_samp, array_size2_interp,
        array_size3, array_size3_samp, array_size3_interp,
        array_size4, array_size4_samp, array_size4_interp,
        array_size5, array_size5_samp, array_size5_interp,
        vectorp_len, vectors_len, vectorl_len,
        array_size4_interp_s, array_size4_interp_x
      };
      for (i = 0; i < dimcnt; i++) {
        nc_def_dim(ncid0, dimnames[i], dimnums[i], &dimid[i]);
      }
      printf("passed nc def dim\n");
      for (i = 0; i < 3; i++) {
        nc_def_var(ncid0, varnames[i], vartypes[i], 1, &dimid[vardimind[i]], &varid[i]);
      }
      printf("passed nc def var\n");
      nc_enddef(ncid0);
      for (i = 0; i < 3; i++) {
        status = nc_put_var(ncid0, varid[i], varpointers[i]);
        if (status != NC_NOERR) printf("putvar %s error=%d\n", varnames[i], status);
      }
      nc_close(ncid0);
      printf("passed nc put value\n");
    }
  }

  if(rank == 0){
    if (flag) {
      free(surta_data);
      free(serial_id_samp);
      free(cell_lat_data);
      free(cell_area_data);
      free(topo_data);
      free(vegtype0_data);
      free(ecoreg_data);
      free(fips_data);
      free(fips123);
      free(wetland_data);
      free(biomf_c_data);
      free(bioms_c_data);
      free(biomg_c_data);
      free(nh4dep_data);
      free(no3dep_data);
      free(burnlow_data);
      free(burnmix_data);
      free(burnhigh_data);
      free(pct_for_data);
      free(pct_shr_data);
      free(pct_gra_data);
      free(pct_agr_data);
      free(pct_c3crop_data);
      free(pct_wdcrop_data);
      free(pct_wetland_data);
      free(pct_nveg_data);
      free(soilc_data);
      free(owner_type_data);
      free(nmmax_data);
      free(deltat_norm_data_interp);
      printf("passed free tmp arrays\n");
    }
  }

}//data_init(int rank)

int main(int argc, char* argv[])
{
  if(argc > 1) {
    printf("Usage on ALCF Vesta\n");
    printf("  submit_pibis.sh: qsub -A IBIS-USPED -t 10 -n 1 -O LOG --mode script ./jobscript.sh\n");
    printf("  jobscript.sh: runjob -p 16 --np 1 --block $COBALT_PARTNAME : pibis\n\n");
    printf("Usage on local workstation\n");
    printf("  mpirun -np 5 pibis\n");
    printf("  mpiexec -n 2 ddd pibis\n");
    exit(1);
  }

  //MPI_Status status;
  int ierr, nprocs, rank;
  double starttime, endtime; 
  int arraylength, callocsize, callocerror;
  int USE_GATHER = 0;
  int node_size = 0;
 
  rank = 0;

  /* ibis calculation procedures start from master node*/
  if(rank == 0){//mpi root process
    printf("***********************************************\n");
    printf("* IBIS: Integrated BIosphere Simulator        *\n");
    printf("* Jonathan A Forley:  Version 2.5             *\n");
    printf("* David T Price:      Version 2.5+ (CanIBIS)  *\n");
    printf("* Jinxun Liu:         N Cycle, Crop, LULCC    *\n");
    printf("* QiuAn Zhu:          GHG (CH4, N20, NO)      *\n");
    printf("* Jinxun Liu:         Open MPI paralell code  *\n");
    printf("***********************************************\n");

    printf("***********************************************\n");
    printf("* Model setup for parameters and 1-layer maps *\n");
    printf("***********************************************\n");
  }//if(rank == 0)

  data_init(rank);
  return 0;
}

void interp_samp_char(char *sourcex, float *interpx, float *sampx, float *targetx, int group){
  int i, j, k, l, ii, jj, iii, jjj;

  map1size = count_g1[2] * count_g1[3];
  map2size = count_g2[2] * count_g2[3];
  map3size = count_g3[2] * count_g3[3];
  map4size = count_g4[2] * count_g4[3];
  mapSsize = nlatsubs * nlonsubs;

  //step 1: interpolate coarse resolution data to base resolution
  if(group == 1){
    for(i=0;i<total_npoi;i++){ //interp single layer map3, deltat
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map3_id[ii] + layerx*map3size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 2){
    for(i=0;i<total_npoi*nsoilay;i++){ //interp 6 layer soil map2
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map2_id[ii] + layerx*map2size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 3){
    for(i=0;i<total_npoi*12;i++){ //interp 12 layer norm climate maps3
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map3_id[ii] + layerx*map3size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 4){
    for(i=0;i<total_npoi*12*saveyears;i++){ //interp 12*saveyears layer anorm climate map4
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map4_id[ii] + layerx*map4size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*lccyears;i++){ //interp lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map1_id[ii] + layerx*map1size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else{
    printf("interp_samp error1!\n");
    exit;
  }

  //Step 2: make sampling dataset from base and interpolated map
  if(group == 1){
    for(i=0;i<total_npoi;i++){ //sampling single layer maps
      ii = i/nlonsub;//original row
      jj = i%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = iii*nlonsubs + jjj; //serial id after sampling (k <= i)

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 2){
    for(i=0;i<total_npoi*nsoilay;i++){ //sampling interpolated 6 layer soil maps
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 3){
    for(i=0;i<total_npoi*12;i++){ //sampling interpolated 12 layer norm climate maps
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 4){
    for(i=0;i<total_npoi*12*saveyears;i++){ //sampling interpolated 12*saveyears layer anorm climate map
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*lccyears;i++){ //sampling interpolated lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else{
    printf("interp_samp error2!\n");
    exit(0);
  }

  //Step 3: rearrange multi-layer sampled data into segment for MPI_SCATTER
  total_segment = mapSsize/npoi; //sampling by rowscale and colscale

  l = 0;
  start_loc_new = 0;
  if(group == 1){
  }
  else if(group == 2){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*nsoilay;i++){ //rearrange 6 layer soil map2
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*nsoilay + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else if(group == 3){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*12;i++){ //rearrange 12 layer norm climate maps3
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*12 + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else if(group == 4){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*12*saveyears;i++){ //rearrange 12*saveyears layer anorm climate map4
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*12*saveyears + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else if(group == 5){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*lccyears;i++){ //rearrange lccyears layer lcc and disturb data
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*lccyears + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else{
    printf("interp_samp error2!\n");
    exit(0);
  }

  return;
}

//------------------------------------------------------------------------
void interp_samp_float(float *sourcex, float *interpx, float *sampx, float *targetx, int group){
  int i, j, k, l, ii, jj, iii, jjj;

  map1size = count_g1[2] * count_g1[3];
  map2size = count_g2[2] * count_g2[3];
  map3size = count_g3[2] * count_g3[3];
  map4size = count_g4[2] * count_g4[3];
  mapSsize = nlatsubs * nlonsubs;

  //step 1: interpolate coarse resolution data to base resolution
  if(group == 1){
    for(i=0;i<total_npoi;i++){ //interp single layer map3, deltat
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map3_id[ii] + layerx*map3size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 2){
    for(i=0;i<total_npoi*nsoilay;i++){ //interp 6 layer soil map2
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map2_id[ii] + layerx*map2size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 3){
    for(i=0;i<total_npoi*12;i++){ //interp 12 layer norm climate maps3
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map3_id[ii] + layerx*map3size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 4){
    for(i=0;i<total_npoi*12*anomyears;i++){ //interp 12*anomyears layer anorm climate map4
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map4_id[ii] + layerx*map4size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*lccyears;i++){ //interp lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map1_id[ii] + layerx*map1size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else{
    printf("interp_samp error1!\n");
    exit;
  }

  //Step 2: make sampling dataset from base and interpolated map
  if(group == 1){
    for(i=0;i<total_npoi;i++){ //sampling single layer maps
      ii = i/nlonsub;//original row
      jj = i%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = iii*nlonsubs + jjj; //serial id after sampling (k <= i)

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 2){
    for(i=0;i<total_npoi*nsoilay;i++){ //sampling interpolated 6 layer soil maps
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 3){
    for(i=0;i<total_npoi*12;i++){ //sampling interpolated 12 layer norm climate maps
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 4){
    for(i=0;i<total_npoi*12*anomyears;i++){ //sampling interpolated 12*anomyears layer anorm climate map
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*lccyears;i++){ //sampling interpolated lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else{
    printf("interp_samp error2!\n");
    exit(0);
  }

  //Step 3: rearrange multi-layer sampled data into segment for MPI_SCATTER
  total_segment = mapSsize/npoi; //sampling by rowscale and colscale

  l = 0;
  start_loc_new = 0;
  if(group == 1){
  }
  else if(group == 2){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*nsoilay;i++){ //rearrange 6 layer soil map2
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*nsoilay + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else if(group == 3){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*12;i++){ //rearrange 12 layer norm climate maps3
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*12 + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else if(group == 4){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*12*anomyears;i++){ //rearrange 12*anomyears layer anorm climate map4
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*12*anomyears + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else if(group == 5){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*lccyears;i++){ //rearrange lccyears layer lcc and disturb data
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*lccyears + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else{
    printf("interp_samp error2!\n");
    exit(0);
  }

  return;
}

//////////////////
void interp_float(float *sourcex, float *interpx, float *targetx, int group, int group_s){
  int i, j, k, l, ii, jj, iii, jjj;
  int offset_s;

  map1size = count_g1[2] * count_g1[3];
  map2size = count_g2[2] * count_g2[3];
  map3size = count_g3[2] * count_g3[3];
  map4size = count_g4[2] * count_g4[3];
  mapSsize = nlatsubs * nlonsubs;
  offset_s = scatter_years * 12 * (group_s - 1);

  //step 1: interpolate coarse resolution data to base resolution
  if(group == 1){
  }
  else if(group == 2){
  }
  else if(group == 3){
  }
  else if(group == 4){
    for(i=0;i<total_npoi*12*scatter_years;i++){ //interp 12*scatter_years layer anorm climate map4
      layerx = i/total_npoi + offset_s;
      remx = i%total_npoi;
      ii = remx;
      iii = map4_id[ii] + layerx*map4size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else if(group == 5){
    for(i=0;i<total_npoi*lccyears;i++){ //interp lccyears layer lcc and disturb data
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map1_id[ii] + layerx*map1size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else{
    printf("interp_samp error1!\n");
    exit;
  }

  //Step 2: make sampling dataset from base and interpolated map

  //Step 3: rearrange multi-layer sampled data into segment for MPI_SCATTER
  total_segment = mapSsize/npoi; //sampling by rowscale and colscale

  l = 0;
  start_loc_new = 0;
  if(group == 1){
  }
  else if(group == 2){
  }
  else if(group == 3){
  }
  else if(group == 4){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*12*scatter_years;i++){ //rearrange 12*scatter_years layer anorm climate map4
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*12*scatter_years + i;
        targetx[k] = interpx[iii];
      }
    }
  }
  else if(group == 5){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*lccyears;i++){ //rearrange lccyears layer lcc and disturb data
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*lccyears + i;
        targetx[k] = interpx[iii];
      }
    }
  }
  else{
    printf("interp_float error!\n");
    exit(0);
  }

  return;
}

void interp_samp_float_anom(float *sourcex, float *interpx, float *sampx, float *targetx, int group, int group_s){
  int i, j, k, l, ii, jj, iii, jjj;
  int offset_s;

  map1size = count_g1[2] * count_g1[3];
  map2size = count_g2[2] * count_g2[3];
  map3size = count_g3[2] * count_g3[3];
  map4size = count_g4[2] * count_g4[3];
  mapSsize = nlatsubs * nlonsubs;
  offset_s = scatter_years * 12 * (group_s - 1);

  //step 1: interpolate coarse resolution data to base resolution
  if(group == 4){
    for(i=0;i<total_npoi*12*scatter_years;i++){ //interp 12*scatter_years layer anorm climate map4
      layerx = i/total_npoi + offset_s;
      remx = i%total_npoi;
      ii = remx;
      iii = map4_id[ii] + layerx*map4size;

      k = i;
      if(iii >= 0){
        interpx[k] = sourcex[iii];
      }
      else{
        interpx[k] = 0;
      }
    }
  }
  else{
    printf("interp_samp_anom error1!\n");
    exit;
  }

  //Step 2: make sampling dataset from base and interpolated map
  if(group == 4){
    for(i=0;i<total_npoi*12*scatter_years;i++){ //sampling interpolated 12*anomyears layer anorm climate map
      layerx = i/total_npoi;
      ii = (i-layerx*total_npoi)/nlonsub;//original row
      jj = (i-layerx*total_npoi)%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = (iii*nlonsubs + jjj) + layerx*mapSsize; //serial id after sampling

        sampx[k] = interpx[i];
      }
    }
  }
  else{
    printf("interp_samp_anom error2!\n");
    exit(0);
  }

  //Step 3: rearrange multi-layer sampled data into segment for MPI_SCATTER
  total_segment = mapSsize/npoi; //sampling by rowscale and colscale

  l = 0;
  start_loc_new = 0;
  if(group == 4){
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi*12*scatter_years;i++){ //rearrange 12*scatter_years layer anorm climate map4
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new*12*scatter_years + i;
        targetx[k] = sampx[iii];
      }
    }
  }
  else{
    printf("interp_float_anom error!\n");
    exit(0);
  }

  return;
}
//////////////////

//------------------------------------------------------------------------
void calc_valid_seg(){
    FILE *fp2;

    int i, j, k, l, ii, jj, iii, jjj;
    int seg_all;

    if ((fp2 = fopen("valid_segments.txt", "wt"))==NULL){
      return;
    }

    segment_npoi = 0;
    valid_segment = 0;
    l = 0;
    for(i=0;i<total_npoi;i++){ //sampling single layer maps
      ii = i/nlonsub;//original row
      jj = i%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = iii*nlonsubs + jjj; //serial id after sampling (k <= i)
        l = k/npoi; //segment_id after sampling

        if(surta_data[i] == 1)//be aware of integer promotion issue, -15 -> 222?
          segment_npoi = segment_npoi + 1; //add mask in segment
        if(k%npoi == npoi-1){
          valid_segment_npoi[l] = 0;
          if(segment_npoi > 0){
            valid_segment_npoi[l] = segment_npoi;
            valid_segment = valid_segment + 1;
          }
          //fprintf(fp2, "%d\t%d\t%d\n", l, valid_segment_npoi[l], valid_segment);
          //fprintf(fp2, "%d\n", valid_segment_npoi[l]);
          seg_all = l+1;
          segment_npoi = 0;
        }
      }
    }

    if(valid_segment <= 0){
      printf("no valid segment, exit now!\n");
      exit(-1);
    }

    fprintf(fp2, "%d\n", nlatsubs);
    fprintf(fp2, "%d\n", nlonsubs);
    fprintf(fp2, "%d\n", npoi);
    fprintf(fp2, "%d\n", valid_segment);
    fprintf(fp2, "%d\n", saveyears);
    for(l=0; l<seg_all; l++){
      fprintf(fp2, "%d\n", valid_segment_npoi[l]);
    }
    fclose(fp2);

    return;
}


//------------------------------------------------------------------------
void interp(){
    int i, j, k, l, ii, jj, iii, jjj;

    map1size = count_g1[2] * count_g1[3];
    map2size = count_g2[2] * count_g2[3];
    map3size = count_g3[2] * count_g3[3];
    map4size = count_g4[2] * count_g4[3];
    mapSsize = nlatsubs * nlonsubs;

    //step 1: interpolate coarse resolution data to base resolution
    for(i=0;i<total_npoi;i++){ //interp single layer map3, deltat
      layerx = i/total_npoi;
      remx = i%total_npoi;
      ii = remx;
      iii = map3_id[ii] + layerx*map3size;

      k = i;
      if(iii >= 0){
        deltat_norm_data_interp[k] = deltat_norm_data[iii];
      }
      else{
        deltat_norm_data_interp[k] = 0;
      }
    }
    printf("  -- interp_step1 passed!\n");

    //Step 2: make sampling dataset from base and interpolated map
    for(i=0;i<total_npoi;i++){ //sampling single layer maps
      ii = i/nlonsub;//original row
      jj = i%nlonsub;//original column
      if(ii%rowscale == 0 && jj%colscale == 0){//a valid sampling point
        iii = ii/rowscale;//sampling row
        jjj = jj/colscale;//sampling column
        k = iii*nlonsubs + jjj; //serial id after sampling (k <= i)

        surta_data[k] = surta_data[i];
        cell_lat_data[k] = cell_lat_data[i];
        cell_area_data[k] = cell_area_data[i];
        topo_data[k] = topo_data[i];
        vegtype0_data[k] = vegtype0_data[i];
        ecoreg_data[k] = ecoreg_data[i];
        fips_data[k] = fips_data[i];
        wetland_data[k] = wetland_data[i];
        biomf_c_data[k] = biomf_c_data[i];
        bioms_c_data[k] = bioms_c_data[i];
        biomg_c_data[k] = biomg_c_data[i];
        nh4dep_data[k] = nh4dep_data[i];
        no3dep_data[k] = no3dep_data[i];
        burnlow_data[k] = burnlow_data[i];
        burnmix_data[k] = burnmix_data[i];
        burnhigh_data[k] = burnhigh_data[i];
        pct_for_data[k] = pct_for_data[i];
        pct_shr_data[k] = pct_shr_data[i];
        pct_gra_data[k] = pct_gra_data[i];
        pct_agr_data[k] = pct_agr_data[i];
        pct_c3crop_data[k] = pct_c3crop_data[i];
        pct_wdcrop_data[k] = pct_wdcrop_data[i];
        pct_wetland_data[k] = pct_wetland_data[i];
        pct_nveg_data[k] = pct_nveg_data[i];
        owner_type_data[k] = owner_type_data[i];
        soilc_data[k] = soilc_data[i];
        nmmax_data[k] = nmmax_data[i];

        deltat_norm_data_interp[k] = deltat_norm_data_interp[i];
        fips123[k] = fips123[i];
        serial_id_samp[k] = k;
      }
    }
    printf("  -- interp_step2 passed!\n");

    //Step 3: rearrange single-layer sampled data into segment for MPI_SCATTER
    total_segment = mapSsize/npoi; //sampling by rowscale and colscale

    l = 0;
    start_loc_new = 0;
    for(segment_id=0; segment_id<total_segment; segment_id++){
      start_loc = segment_id*npoi;
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      else{
        start_loc_new = l*npoi;
        l = l + 1;
      }
      for(i=0;i<npoi;i++){ //rearrange data on base map1
        layerx = i/npoi;
        remx = i%npoi;
        ii = start_loc + remx;
        iii = ii + layerx*mapSsize;

        k = start_loc_new + i;
        surta_data[k] = surta_data[iii];
        cell_lat_data[k] = cell_lat_data[iii];
        cell_area_data[k] = cell_area_data[iii];
        topo_data[k] = topo_data[iii];
        vegtype0_data[k] = vegtype0_data[iii];
        ecoreg_data[k] = ecoreg_data[iii];
        fips_data[k] = fips_data[iii];
        wetland_data[k] = wetland_data[iii];
        biomf_c_data[k] = biomf_c_data[iii];
        bioms_c_data[k] = bioms_c_data[iii];
        biomg_c_data[k] = biomg_c_data[iii];
        nh4dep_data[k] = nh4dep_data[iii];
        no3dep_data[k] = no3dep_data[iii];
        burnlow_data[k] = burnlow_data[iii];
        burnmix_data[k] = burnmix_data[iii];
        burnhigh_data[k] = burnhigh_data[iii];
        pct_for_data[k] = pct_for_data[iii];
        pct_shr_data[k] = pct_shr_data[iii];
        pct_gra_data[k] = pct_gra_data[iii];
        pct_agr_data[k] = pct_agr_data[iii];
        pct_c3crop_data[k] = pct_c3crop_data[iii];
        pct_wdcrop_data[k] = pct_wdcrop_data[iii];
        pct_wetland_data[k] = pct_wetland_data[iii];
        pct_nveg_data[k] = pct_nveg_data[iii];
        owner_type_data[k] = owner_type_data[iii];
        soilc_data[k] = soilc_data[iii];
        nmmax_data[k] = nmmax_data[iii];

        deltat_norm_data_interp[k] = deltat_norm_data_interp[iii];
        fips123[k] = fips123[iii];
        serial_id_samp[k] = serial_id_samp[iii];
      }
    }
    printf("  -- interp_step3 passed!\n");
}

//------------------------------------------------------------------------
void datapack(){//do this on each rank after MPI_Scatter()
    int i, j, k, l;
    int size_s, offset_s, offset_ss, offset_sss;

    for(i=0;i<npoi;i++){
      
      matrix4[0][i] = local_surta_data[i];
      matrix4[1][i] = local_cell_lat_data[i];
      matrix4[2][i] = local_cell_area_data[i];
      matrix4[3][i] = local_topo_data[i];
      matrix4[4][i] = local_vegtype0_data[i];
      matrix4[5][i] = local_ecoreg_data[i];
      matrix4[6][i] = local_fips_data[i];
      matrix4[7][i] = local_wetland_data[i];
      matrix4[8][i] = local_biomf_c_data[i];
      matrix4[9][i] = local_bioms_c_data[i];
      matrix4[10][i] = local_biomg_c_data[i];
      matrix4[11][i] = local_nh4dep_data[i];
      matrix4[12][i] = local_no3dep_data[i];
      matrix4[13][i] = local_burnlow_data[i];
      matrix4[14][i] = local_burnmix_data[i];
      matrix4[15][i] = local_burnhigh_data[i];
      matrix4[16][i] = local_pct_for_data[i];
      matrix4[17][i] = local_pct_shr_data[i];
      matrix4[18][i] = local_pct_gra_data[i];
      matrix4[19][i] = local_pct_agr_data[i];
      matrix4[20][i] = local_pct_c3crop_data[i];
      matrix4[21][i] = local_pct_wdcrop_data[i];
      matrix4[22][i] = local_pct_wetland_data[i];
      matrix4[23][i] = local_pct_nveg_data[i];
      matrix4[24][i] = local_soilc_data[i];

      matrix4[25][i]= local_deltat_norm_data[i];
      matrix4[26][i] = local_fips123[i];
      matrix4[27][i] = my_rank;
      matrix4[28][i] = local_nmmax_data[i];
      matrix4[29][i] = local_owner_type_data[i];
    }

    for(i=0;i<npoi*nsoilay;i++){
      matrix1[0][i] = matrix1_sand[i];
      matrix1[1][i] = matrix1_clay[i];
      matrix1[2][i] = matrix1_ph[i];
    }

    for(i=0;i<npoi*12;i++){
      matrix2[0][i] = matrix2_wetd_norm[i];
      matrix2[1][i] = matrix2_cld_norm[i];
      matrix2[2][i] = matrix2_prec_norm[i];
      matrix2[3][i] = matrix2_temp_norm[i];
      matrix2[4][i] = matrix2_trange_norm[i];
      matrix2[5][i] = matrix2_rhum_norm[i];
      matrix2[6][i] = matrix2_wspd_norm[i];
      matrix2[7][i] = matrix2_co2spa_norm[i];
    }

    for(k=0; k<anomyears; k++){
      size_s = npoi*12;
      offset_s = size_s*k;
      offset_ss = size_s * (k%scatter_years);
      offset_sss = k/scatter_years;

      for(j=0;j<size_s;j++){
        i = j + offset_s;
        l = j + offset_ss;

        if(offset_sss == 0){
          matrix3[0][i] = matrix3_prec_anorm1[l];
          matrix3[1][i] = matrix3_temp_anorm1[l];
          matrix3[2][i] = matrix3_trange_anorm1[l];
        }
        else if(offset_sss == 1){
          matrix3[0][i] = matrix3_prec_anorm2[l];
          matrix3[1][i] = matrix3_temp_anorm2[l];
          matrix3[2][i] = matrix3_trange_anorm2[l];
        }
        else if(offset_sss == 2){
          matrix3[0][i] = matrix3_prec_anorm3[l];
          matrix3[1][i] = matrix3_temp_anorm3[l];
          matrix3[2][i] = matrix3_trange_anorm3[l];
        }
        else if(offset_sss == 3){
          matrix3[0][i] = matrix3_prec_anorm4[l];
          matrix3[1][i] = matrix3_temp_anorm4[l];
          matrix3[2][i] = matrix3_trange_anorm4[l];
        }
        else if(offset_sss == 4){
          matrix3[0][i] = matrix3_prec_anorm5[l];
          matrix3[1][i] = matrix3_temp_anorm5[l];
          matrix3[2][i] = matrix3_trange_anorm5[l];
        }
        else if(offset_sss == 5){
          matrix3[0][i] = matrix3_prec_anorm6[l];
          matrix3[1][i] = matrix3_temp_anorm6[l];
          matrix3[2][i] = matrix3_trange_anorm6[l];
        }
        else if(offset_sss == 6){
          matrix3[0][i] = matrix3_prec_anorm7[l];
          matrix3[1][i] = matrix3_temp_anorm7[l];
          matrix3[2][i] = matrix3_trange_anorm7[l];
        }
        else if(offset_sss == 7){
          matrix3[0][i] = matrix3_prec_anorm8[l];
          matrix3[1][i] = matrix3_temp_anorm8[l];
          matrix3[2][i] = matrix3_trange_anorm8[l];
        }
        else if(offset_sss == 8){
          matrix3[0][i] = matrix3_prec_anorm9[l];
          matrix3[1][i] = matrix3_temp_anorm9[l];
          matrix3[2][i] = matrix3_trange_anorm9[l];
        }
        else if(offset_sss == 9){
          matrix3[0][i] = matrix3_prec_anorm10[l];
          matrix3[1][i] = matrix3_temp_anorm10[l];
          matrix3[2][i] = matrix3_trange_anorm10[l];
        }
        else{
          matrix3[0][i] = matrix3_prec_anorm1[l];
          matrix3[1][i] = matrix3_temp_anorm1[l];
          matrix3[2][i] = matrix3_trange_anorm1[l];
        }
      }
    }
/*
    for(i=0;i<npoi*12*anomyears;i++){
      years = i/(npoi*12)/scatter_years;
      if(years == 0){
      matrix3[0][i] = matrix3_prec_anorm1[i];
      matrix3[1][i] = matrix3_temp_anorm1[i];
      matrix3[2][i] = matrix3_trange_anorm1[i];
      }
      if(years == 1){
      }
      if(years == 2){
      }
      if(years == 3){
      }
      if(years == 4){
      }
    }
*/
    for(i=0;i<npoi*lccyears;i++){
      matrix5[0][i] = matrix5_lcc[i];
      matrix5[1][i] = matrix5_fire[i];
      matrix5[2][i] = matrix5_burnlf[i];
      matrix5[3][i] = matrix5_burnhf[i];
      matrix5[4][i] = matrix5_burnmf[i];
      matrix5[5][i] = matrix5_burnls[i];
      matrix5[6][i] = matrix5_burnhs[i];
      matrix5[7][i] = matrix5_burnms[i];
      matrix5[8][i] = matrix5_ndep[i];

      //avoid interger promotion issue on BG/Q Vesta
      if(matrix5[0][i] > 12) matrix5[0][i] = 0;
      if(matrix5[1][i] > 100) matrix5[1][i] = 0;
      if(matrix5[2][i] > 100) matrix5[2][i] = 0;
      if(matrix5[3][i] > 100) matrix5[3][i] = 0;
      if(matrix5[4][i] > 100) matrix5[4][i] = 0;
      if(matrix5[5][i] > 100) matrix5[5][i] = 0;
      if(matrix5[6][i] > 100) matrix5[6][i] = 0;
      if(matrix5[7][i] > 100) matrix5[7][i] = 0;
      if(matrix5[8][i] > 100) matrix5[8][i] = 0;
    }
  return;
}
//------------------------------------------------------------------------
void invertp0(char *output_name){
}

//------------------------------------------------------------------------
void invertp(){
}

//------------------------------------------------------------------------
void invert_npp(){
    int i, j, kk, array_length;
    //float ncfill  = -9999.0;
    float ncfill = 9.9692099683868690e+36;

    mapSsize = nlatsubs * nlonsubs;
    total_segment = mapSsize/npoi; //sampling by rowscale and colscale
    printf("mapSsize = %d\n", mapSsize);
    printf("total_segment = %d\n", total_segment);

    for(i=0;i<mapSsize*saveyears;i++){
      invert_aynpptot[i] = ncfill;
    }

    valid_segment_id = -1;
    for(segment_id=0; segment_id<total_segment; segment_id++){
      if(valid_segment_npoi[segment_id] == 0){
        continue;
      }
      valid_segment_id = valid_segment_id + 1;

      start_loc = segment_id*npoi;
      j = valid_segment_id*npoi*saveyears;

      for(i=0;i<npoi*saveyears;i++){
        layerx = i/npoi;
        remx = i%npoi;
        kk = start_loc + remx + layerx*mapSsize;

        invert_aynpptot[kk] = out_11[j];
        j = j + 1;
      }
    }
    printf("finished invert_npp\n");

    array_length = mapSsize * saveyears;

    writeDat(invert_aynpptot,"aynpptot.dat", array_length, 4);     
}

void writeDat(float *var4, char *targetfile, int array_length, int elementsize){
      FILE *fTargetFile;
      if((fTargetFile=fopen(targetfile,"wb")) == NULL){
        printf("Error opening target DAT file\n");
        return;
      }
      fwrite(var4, elementsize, array_length, fTargetFile);
      fclose(fTargetFile);
      //free(var4);

      //printf("          finished writeDat %s\n", targetfile);
}

int errmsg(const char *msg, int retval) {
    //fprintf(stderr, "%s\n", msg);
    printf("%s\n", msg);
    return retval;
}

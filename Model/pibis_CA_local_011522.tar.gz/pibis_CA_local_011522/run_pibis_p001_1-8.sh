cp -p pibis_p001_local ../xibis1
cp -p pibis_p001_local ../xibis2
cp -p pibis_p001_local ../xibis3
cp -p pibis_p001_local ../xibis4
cp -p pibis_p001_local ../xibis5
cp -p pibis_p001_local ../xibis6
cp -p pibis_p001_local ../xibis7
cp -p pibis_p001_local ../xibis8

cd ../xibis1/
rm global0.nc
pibis_p001_local
sleep 5s

cd ../xibis2/
rm global0.nc
pibis_p001_local
sleep 5s

cd ../xibis3/
rm global0.nc
pibis_p001_local
sleep 5s

cd ../xibis4/
rm global0.nc
pibis_p001_local
sleep 5s

cd ../xibis5/
rm global0.nc
pibis_p001_local
sleep 5s

cd ../xibis6/
rm global0.nc
pibis_p001_local
sleep 5s

cd ../xibis7/
rm global0.nc
pibis_p001_local
sleep 5s

cd ../xibis8/
rm global0.nc
pibis_p001_local
sleep 5s


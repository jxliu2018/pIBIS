cp -p ./stats/tools_3/* .

go_0.sh
SECONDS=0
avg_std_slope_sensitivity_0.sh
now=$(date +"%T")
echo "Current time : $now"
echo "Used time : $SECONDS"

mkdir mean_slope
mkdir sensitivity

mv mean_* mean_slope
mv slope_* mean_slope
mv subset_* mean_slope
mv std_* mean_slope
mv *sensitivity_low* sensitivity


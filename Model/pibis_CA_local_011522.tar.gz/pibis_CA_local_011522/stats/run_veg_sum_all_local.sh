cp -rp ./stats/tools_2/* .

SECONDS=0
go_0.sh
veg_sum_0.sh
now=$(date +"%T")
echo "Current time : $now"
echo "Used time : $SECONDS"

tar czf veg_sum_all.tar.gz sum_*_m.nc.txt*
tar czf veg_mask_all_nc.tar.gz veg_mask*.nc

mkdir veg_sum
mv veg_*.gz veg_sum

cp -p ./stats/tools_4/* .

#### convert netcdf_m.data to raw binery_m.data
go fips_m.nc fips fips.dat
go ecoreg_m.nc ecoreg ecoreg.dat
go xcovmax_m.nc xcovmax xcovmax.dat
go fu_m.nc fu fu.dat

#### for calibration purpose

cp -p cgrain_m.nc cgrain_m_calib.nc
cp -p aynpptot_m.nc aynpptot_m_calib.nc
cp -p totbiou_m.nc totbiou_m_calib.nc
cp -p stddown_m.nc stddown_m_calib.nc

fipsum_ibis_pct_123120 cgrain_m_calib.nc cgrain fips.dat float 33 20 1 115 xcovmax.dat 2 2 ca_clip_nlcd_2006_agr_pct_960m_schar.nc_x.dat 11 100
fipsum_ibis_biom_123120 totbiou_m_calib.nc totbiou fips.dat float 33 20 1 115 fu.dat 0.5 1.0
fipsum_ibis_biom_123120 stddown_m_calib.nc stddown fips.dat float 33 20 1 115 fu.dat 0.5 1.0

fipsum_ibis_123120 aynpptot_m_calib.nc aynpptot fips.dat float 33 20 1 115 fu.dat 0.5 1.0
mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.f
fipsum_ibis_123120 aynpptot_m_calib.nc aynpptot fips.dat float 33 20 1 115 xcovmax.dat 3 3
mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.s
fipsum_ibis_123120 aynpptot_m_calib.nc aynpptot fips.dat float 33 20 1 115 xcovmax.dat 4 4
mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.g
fipsum_ibis_123120 aynpptot_m_calib.nc aynpptot fips.dat float 33 20 1 115 xcovmax.dat 2 2
mv sum_aynpptot_m_calib.nc.txt sum_aynpptot_m_calib.nc.txt.c

cp -p paramsx.scl CONUS_scalers.txt
scalers_ibis.120216 p_list_scalers_all_fips.asc
tar czf calib_fips_all.tar.gz *_temp.txt *_m_calib.nc.txt* *.scl p_list_scalers_*

mkdir calib
#mv calib_fips_all.tar.gz calib


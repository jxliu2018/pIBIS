Parallel IBIS simulation
Machine         ALCF/Theta
sim date        070819
codebase        062019 modified, not affecting previous calibrations
new updates     Mainly turn of N2O calculation in GHG.f and change to use county thinning scaler:
                paramsx.luc (paramsx.luc.fips).
                add option of constant CO2 after 1970
C code last     061819, changed sub_region_N_blocks_segment_comp_dyn_cray.c for minimum 128 nodes
                        changed main_p.c, maino_p000_cray.c, main_p001_cray.c to turn-off arraya
                        changed readpara.c to use ibis_common_p.h 
                062019, changed ncvar_p.c to use county scalers 
Fortran last    060919, biogeochem.f, initial.f 
                061919, ibislib.f, GHGasE.f
                *Note*  old physiology.f used (090717), removed "stressd" addition
                070719, ibislib.f -- modified option of constant CO2 after 1970, for reference run
                        if (isimco2 .eq. 4 .and. iyear .gt. 1970) then
geo scope       CONUS
sampling        3x
start mode      warm
climate         yes
fire            yes
LCC             yes
Ndep            use dynamic ndep 
GHG             CH4
CO2             ramped CO2
calibration     x20 all inclusive, scaler: scaler_temp_x6_all.txt 
other notes     nfips=1000
                This run used the x6_all scaler (NPP, biomass and deadwood scalers all calibration 6 times).
                Need manually change ibis.infile, warm_start, biomass reset in 1968, no climate, fire, dist.
                Need manually copy new pibis_ build to xibisx folder ...... 
                cp -p pibis_*_cray ../xibis1
Step-by-step
                ssh -Y jxliu@theta.alcf.anl.gov

		module swap PrgEnv-intel PrgEnv-cray
		module load cray-netcdf

                cd /lus/theta-fs0/projects/CONUS-Carbon/pibis_pnetcdf_theta/ibis
                compile_crayftn_savebin.rc

                cd /lus/theta-fs0/projects/CONUS-Carbon/pibis_pnetcdf_theta/
                make_pibis_p001_cray.rc
                make_pibis_p000_cray.rc
                make_pibis_p_cray.rc
           *    cp -p paramsx.scl.conus84.base paramsx.scl (only for first ecoreg level calib run)
           *    cp -p CONUS_scalers_base.txt paramsx.scl (only for first county level calib run)

           *    cp -p paramsx.scl ../xibis1 (only for second and later calib runs, update paramsx.scl)
           *    cp -p paramsx.scl ../xibis2
           *    cp -p paramsx.scl ../xibis3
           *    cp -p paramsx.scl ../xibis4
           *    cp -p paramsx.scl ../xibis5
           *    cp -p paramsx.scl ../xibis6
           *    cp -p paramsx.scl ../xibis7
           *    clean_global.sh             (only if want to update global0.nc)
           *    run_pibis_p001_cray_1-7.sh  (only if want to update global0.nc)

                seg_p_cray_3km_1-7.rc
                (minimum 128 nodes)
                submit_all_cray_7.sh
                (for 3k run, qsub need to use default queue instead of debug queue!)

                run_invert.40_cray.sh
                run_Dat2NC_x_40_cray.sh
                run_merge.40_1km_cray.sh.tmp1
                run_merge.40_1km_cray.sh.tmp2
                control_tmp1.sh (archive some parameter and control files)

                run_ecosum_3x_1.sh (if only want overall fu0010 summary, region_tools.061019)
                run_ecosum_3x_allx.sh (if want summary by land cover type, region_tools.061019)

           *    cp -p scaler_temp.txt paramsx.scl (if prepare for next county or ecoregion calibration)
                run_calib_ecoreg_3x_CONUSx.sh
                run_calib_fips_3x_CONUSx.sh

archive gz      /lus/theta-fs0/projects/CONUS-Carbon/ecosum/conus3k/sim_062019_3k_x20

ISSUES          
 

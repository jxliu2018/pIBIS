pIO_invert outfile1 valid_segments.txt
rm outfile1
pIO_invert outfile2 valid_segments.txt
rm outfile2
pIO_invert outfile3 valid_segments.txt
rm outfile3
pIO_invert outfile4 valid_segments.txt
rm outfile4
pIO_invert outfile5 valid_segments.txt
rm outfile5
pIO_invert outfile6 valid_segments.txt
rm outfile6
pIO_invert outfile7 valid_segments.txt
rm outfile7
pIO_invert outfile8 valid_segments.txt
rm outfile8
pIO_invert outfile9 valid_segments.txt
rm outfile9
pIO_invert outfile10 valid_segments.txt
rm outfile10
pIO_invert outfile11 valid_segments.txt
rm outfile11
pIO_invert outfile12 valid_segments.txt
rm outfile12
pIO_invert outfile13 valid_segments.txt
rm outfile13
pIO_invert outfile14 valid_segments.txt
rm outfile14
pIO_invert outfile15 valid_segments.txt
rm outfile15
pIO_invert outfile16 valid_segments.txt
rm outfile16
pIO_invert outfile17 valid_segments.txt
rm outfile17
pIO_invert outfile18 valid_segments.txt
rm outfile18
pIO_invert outfile19 valid_segments.txt
rm outfile19
pIO_invert outfile20 valid_segments.txt
rm outfile20
pIO_invert outfile21 valid_segments.txt
rm outfile21
pIO_invert outfile22 valid_segments.txt
rm outfile22
pIO_invert outfile23 valid_segments.txt
rm outfile23
pIO_invert outfile24 valid_segments.txt
rm outfile24
pIO_invert outfile25 valid_segments.txt
rm outfile25
pIO_invert outfile26 valid_segments.txt
rm outfile26
pIO_invert outfile27 valid_segments.txt
rm outfile27
pIO_invert outfile28 valid_segments.txt
rm outfile28
pIO_invert outfile29 valid_segments.txt
rm outfile29
pIO_invert outfile30 valid_segments.txt
rm outfile30
pIO_invert outfile31 valid_segments.txt
rm outfile31
pIO_invert outfile32 valid_segments.txt
rm outfile32
pIO_invert outfile33 valid_segments.txt
rm outfile33
pIO_invert outfile34 valid_segments.txt
rm outfile34
pIO_invert outfile35 valid_segments.txt
rm outfile35
pIO_invert outfile36 valid_segments.txt
rm outfile36
pIO_invert outfile37 valid_segments.txt
rm outfile37
pIO_invert outfile38 valid_segments.txt
rm outfile38
pIO_invert outfile39 valid_segments.txt
rm outfile39
pIO_invert outfile40 valid_segments.txt
rm outfile40

mv outfile1_x fips.dat
mv outfile2_x ecoreg.dat
mv outfile3_x xcovmax.dat

mv outfile4_x cbiotot.dat
mv outfile5_x totbiou.dat
mv outfile6_x rawlitc.dat
mv outfile7_x totlit.dat
mv outfile8_x stdwdc.dat
mv outfile9_x deadwdc.dat
mv outfile10_x totcsoi.dat

mv outfile11_x aynpptot.dat
mv outfile12_x ayneetot.dat
mv outfile13_x aynbp.dat

mv outfile14_x fallw.dat
mv outfile15_x livc2std.dat
mv outfile16_x livc2down.dat
mv outfile17_x stdwcloss.dat
mv outfile18_x down2lit.dat
mv outfile19_x lit2co2.dat
mv outfile20_x lit2soc.dat
mv outfile21_x soc2co2.dat
mv outfile22_x yrleach.dat

mv outfile23_x cdisturb.dat
mv outfile24_x logging.dat
mv outfile25_x soilcomb.dat
mv outfile26_x vegcomb.dat

mv outfile27_x cgrain.dat
mv outfile28_x strawc.dat

mv outfile29_x fu.dat
mv outfile30_x vegtype0.dat
mv outfile31_x cfruit.dat
mv outfile32_x totwdl.dat
mv outfile33_x xdist.dat
mv outfile34_x deadcrem.dat
mv outfile35_x livecrem.dat

mv outfile36_x totceco.dat
mv outfile37_x csoipas.dat
mv outfile38_x csoislow.dat
mv outfile39_x ayCH4.dat
mv outfile40_x ayn2oflux.dat


c param_global.h
c Jinxun Liu
c jxliu@usgs.gov
c
      integer totnpoi,totyears,anomyears,lccyears,fireyears,saveyears
      parameter (totnpoi   = 20,
     >           totyears  = 115,
     >           anomyears = 45,
     >           lccyears  = 45,
     >           fireyears  = 32,
     >           saveyears  = 115)

      integer totalyear
c
      integer istep,         ! timestep counter (per day)
     >        iday,          ! daily loop counter
     >        imonth,        ! monthly loop counter
     >        istyrd,        ! first yr daily means exist (from precip file)
     >        istyrm,        ! first yr monthly anoms exist (from file)
     >        iwest,         ! 1st lon index for subset
     >        iy1,           ! first year for year loop
     >        iy2,           ! last year for year loop
     >        iyear,         ! yearly loop counter
     >        iyear0,        ! first year of simulation
     >        ilccyr,        ! first year of lcc data
     >        iyranom,       ! year to start reading monthly anomalies
     >        iyrdaily,      ! year to start reading daily means
     >        iyrlast,       ! last year of previous run (for restart)
     >        idiag,         ! number of diagnostic files requested
     >        idailyout,     ! 0: no daily output 1: daily output
     >        imonthout,     ! 0: no monthly output 1: monthly output
     >        iyearout,      ! 0: no yearly output 1: yearly output
     >        irestart,      ! 0: normal mode 1: restart mode
     >        isimveg,       ! 0: static veg 1: dynam veg initialized w/ fixed
     >                       ! 2: dynam veg initialized w/ cold start
     >        isimfire,      ! 0: fixed fire  1: dynamic fire
     >        isimco2,       ! 0: fixed co2   1: changing co2
     >        isimlcc,       ! -1: single lc map 0: lcc maps, 1: land cover interpolation
     >        jday,          ! julian day of the simulation
     >        jnorth,        ! 1st lat index for subset
     >        nanom,         ! # of years in the anomaly files
     >        niter,         ! total number of time iterations per day
     >        nday,          ! number of days since the start of the simulation
     >        nrun,          ! # of years in this run
     >        nspinsoil,     ! year of simulation that soil c reaches equilibrium 
     >        plen,          ! length of precipitation event in timesteps (see plens)
     >        plenmax,       ! upper bound on plen
     >        plenmin,       ! lower bound on plen
     >        spin,          ! counter for iterations used to spin up soilbgc
     >        spinmax,       ! maximum iterations used to spin up soilbgc
     >        eqyears,       !
     >        soilcspin,     ! 0: no spinup procedure for soil c  1: acceleration procedure used
     >        lun, ifile,    ! file indices
     >        n, ivar,       ! loop indices
     >        iii, tmpint    ! a temp int value
c
      real    co2init,       ! initial co2 concentration in mol/mol
     >        o2init,        ! initial o2 concentration in mol/mol
     >        dran,          ! random number from generator
     >        plens,         ! length of precipitation event in seconds
     >        startp,        ! time to start precipitation event (seconds since midnight)
     >        endp,          ! time to end precipitation event (seconds since midnight)
     >        spincons,      ! # times soil gbc called each day during spinup
     >        spinfrac,      ! fraction of nspinsoil time with max iteration spinmax
     >        slope,         ! rate of decrease of number of iteration for soil C spinup 
     >        snorth,        ! north latitude for subsetting std grid
     >        ssouth,        ! south latitude for subsetting std grid
     >        swest,         ! west longitude for subsetting std grid
     >        seast,         ! east longitude for subsetting std grid
     >        test,          ! test on timestep 
     >        time           ! time of day since midnight (in seconds)
c
      real    co2old,
     >        co2adj,
     >        exp_dec
      integer restyr         !restart year (for overwriting output files)
c
      common /globalp/
     >        totalyear,     ! ending year of simulation, i.e. 2050
     >        istep,         ! timestep counter (per day)
     >        iday,          ! daily loop counter
     >        imonth,        ! monthly loop counter
     >        istyrd,        ! first yr daily means exist (from precip file)
     >        istyrm,        ! first yr monthly anoms exist (from file)
     >        iwest,         ! 1st lon index for subset
     >        iy1,           ! first year for year loop
     >        iy2,           ! last year for year loop
     >        iyear,         ! yearly loop counter
     >        iyear0,        ! first year of simulation
     >        ilccyr,        ! first year of lcc data
     >        iyranom,       ! year to start reading monthly anomalies
     >        iyrdaily,      ! year to start reading daily means
     >        iyrlast,       ! last year of previous run (for restart)
     >        idiag,         ! number of diagnostic files requested
     >        idailyout,     ! 0: no daily output 1: daily output
     >        imonthout,     ! 0: no monthly output 1: monthly output
     >        iyearout,      ! 0: no yearly output 1: yearly output
     >        irestart,      ! 0: normal mode 1: restart mode
     >        isimveg,       ! 0: static veg 1: dynam veg initialized w/ fixed
     >                       ! 2: dynam veg initialized w/ cold start
     >        isimfire,      ! 0: fixed fire  1: dynamic fire
     >        isimco2,       ! 0: fixed co2   1: changing co2
     >        isimlcc,       ! -1: single lc map 0: lcc maps, 1: land cover interpolation
     >        jday,          ! julian day of the simulation
     >        jnorth,        ! 1st lat index for subset
     >        nanom,         ! # of years in the anomaly files
     >        niter,         ! total number of time iterations per day
     >        nday,          ! number of days since the start of the simulation
     >        nrun,          ! # of years in this run
     >        nspinsoil,     ! year of simulation that soil c reaches equilibrium 
     >        plen,          ! length of precipitation event in timesteps (see plens)
     >        plenmax,       ! upper bound on plen
     >        plenmin,       ! lower bound on plen
     >        spin,          ! counter for iterations used to spin up soilbgc
     >        spinmax,       ! maximum iterations used to spin up soilbgc
     >        eqyears,       !
     >        soilcspin,     ! 0: no spinup procedure for soil c  1: acceleration procedure used
     >        lun, ifile,    ! file indices
     >        n, ivar,       ! loop indices
     >        iii, tmpint,   ! a temp int value
c
     >        co2init,       ! initial co2 concentration in mol/mol
     >        o2init,        ! initial o2 concentration in mol/mol
     >        dran,          ! random number from generator
     >        plens,         ! length of precipitation event in seconds
     >        startp,        ! time to start precipitation event (seconds since midnight)
     >        endp,          ! time to end precipitation event (seconds since midnight)
     >        spincons,      ! # times soil gbc called each day during spinup
     >        spinfrac,      ! fraction of nspinsoil time with max iteration spinmax
     >        slope,         ! rate of decrease of number of iteration for soil C spinup 
     >        snorth,        ! north latitude for subsetting std grid
     >        ssouth,        ! south latitude for subsetting std grid
     >        swest,         ! west longitude for subsetting std grid
     >        seast,         ! east longitude for subsetting std grid
     >        test,          ! test on timestep 
     >        time,          ! time of day since midnight (in seconds)
c
     >        co2old,
     >        co2adj,
     >        exp_dec,
     >        restyr         !restart year (for overwriting output files)
c



c * comghg.h
c *
c *  Created on: 2010-5-31
c *      Author: RickyChu
c */

c      real  Theta,RBOX,FD,EFFAC_D,MUEMAX,AMAX,AMAXX, KNI ,
c     >       MUE_NO3 ,MUE_NO2 , MUE_NO , MUE_N2O , MNO3 , MNO2 ,
c     >       MNO , MN2O ,  EFF_NO3 , EFF_NO2, EFF_NO, EFF_N2O, KICE ,KCI,
c     >       D_O2,LH,SD,F_aerenchyma,Atm_CH4
c      parameter (Theta = 0.0000001,
c     >	         RBOX = 0.14,
c     >           FD = 0.01,
c     >           EFFAC_D = 0.5,
c     >           NMAX = 3.85,
c     >           MUEMAX = 0.102,
c     >           AMAX = 0.06,
c     >           AMAXX = 0.036,
c     >           KCI = 0.017,
c     >           KNI = 0.083,
c     >           MUE_NO3 = 0.67,
c     >           MUE_NO2 = 0.67,
c     >           MUE_NO = 0.47,
c     >           MUE_N2O = 0.47,
c     >           MNO3 = 0.09,
c     >           MNO2 = 0.035,
c     >           MNO = 0.0792,
c     >           MN2O = 0.0792,
c     >           EFF_NO3 = 0.501,
c     >           EFF_NO2 = 0.428,
c     >           EFF_NO = 0.151,
c     >           EFF_N2O = 0.075,
c     >           KICE = 0.75,
c     >           D_O2 = 0.07236,          ! O2 diffusion in air, m?h from Beisecker 1994
c     >           Atm_CH4 = 0.00009,       ! 0.076umold/L =0.00009 kg/ha/cm
c     >           SD = 1.2,
c     >           LH = 0.021,
c     >           F_aerenchyma = 0.5)      ! here it is set as constant, it is calculated in DNDC
c     >           F_em = 0.2)


c      integer OrgLayers
      real Theta
      parameter (Theta = 0.0000001)    !OrgLayers = 0,
c
c
c parameters for nitrification and denitrificaiton
      real  RBOX,FD,EFFAC_D,MUEMAX,AMAX,AMAXX, KNI ,
     >       MUE_NO3 ,MUE_NO2 , MUE_NO , MUE_N2O , MNO3 , MNO2 ,
     >       MNO, MN2O,  EFF_NO3 , EFF_NO2, EFF_NO, EFF_N2O, KICE ,KCI,
     >       D_O2,LH,SD,F_aerenchyma,Atm_CH4,rcnb
c
      common /comghg01/ RBOX,FD,EFFAC_D,MUEMAX,AMAX,AMAXX, KNI ,
     >       MUE_NO3 ,MUE_NO2 , MUE_NO , MUE_N2O , MNO3 , MNO2 ,
     >       MNO, MN2O,  EFF_NO3 , EFF_NO2, EFF_NO, EFF_N2O, KICE ,KCI,
     >       D_O2,LH,SD,F_aerenchyma,Atm_CH4,rcnb


      real
     > rcvl_N(npoi),       !bio_925
     > rcl_N(npoi),        !bio_927
     > rcr_N(npoi),        !bio_928
     > rcvl_C(npoi),       !bio_944
     > rcl_C(npoi),        !bio_945
     > rcr_C(npoi),        !bio_946
     > crb12_N(npoi),      !bio_948
     > crb12_C(npoi),      !
     > crhrl_N(npoi),      !bio_949
     > crhrl_C(npoi),      !
     > hum2mic_N(npoi),    !bio_950
     > hum2mic_C(npoi),    !
     > DailyMicCO2(npoi),  !bio_950
     > TotCSoil(npoi),     !bio_1199
c
     > NH4_arg(npoi),
     > NH4_manure(npoi),
     > NH4_add(npoi),
     > CNratio(npoi),      !zhangkr soil C/N
     > yndep(npoi),        !
     > parnno(npoi)        !zhangkr nitrification rate coefficient
c	
      common /comghg02/rcvl_N,rcl_N,rcr_N,rcvl_C,rcl_C,
     >  rcr_C,crb12_N,crb12_C,crhrl_N,crhrl_C,hum2mic_N,hum2mic_C,
     >  DailyMicCO2,TotCSoil,
     > NH4_arg, NH4_manure, NH4_add, CNratio, yndep, parnno
c
      real
     >microN(npoi,nsoilay),
     >micro(npoi,nsoilay),
     >lay_C_Bio(npoi,nsoilay),
     >day_wfps(npoi,nsoilay),
c
     >SoilDensi(npoi,nsoilay),
     >SoilT(npoi,nsoilay),
     >Soil_Ice(npoi,nsoilay),
     >SoilDepth(nsoilay),
     >SoilPoros(npoi,nsoilay),
     >SoilWater(npoi,nsoilay),
     >SoilClay(npoi,nsoilay),
c
     > NH4(npoi,nsoilay),
     > NH3(npoi,nsoilay),
     > clay_NH4(npoi,nsoilay),
     > NO3(npoi,nsoilay),
     > an_NO3(npoi,nsoilay),
     > N2O(npoi,nsoilay),
     > an_N2O(npoi,nsoilay),
     > NO(npoi,nsoilay),
     > an_NO(npoi,nsoilay),
     > NO2(npoi,nsoilay),
     > NO2_w(npoi,nsoilay),
     > N2(npoi,nsoilay),
     > N2_w(npoi,nsoilay),
     > DOC(npoi,nsoilay),
     > an_DOC(npoi,nsoilay),
     > O2(npoi,nsoilay),
     > pH(npoi,nsoilay),
     > mi_akt(npoi,nsoilay),
     > SOC(npoi,nsoilay),
c
     > anvf(npoi,nsoilay),         !Volumetric fraction of anaerobic microsites
c     variables for denitrification
     > denitrifier(npoi,nsoilay),
c
     > mi_den_akt(npoi,nsoilay),
     > O2_cons(npoi,nsoilay),
     > O2_old(npoi,nsoilay),
     > D_soil_effect(npoi,nsoilay),
     > SoilWilt(npoi,nsoilay)
c
      common /comghg03/ microN, micro,lay_C_Bio,day_wfps,
     >  SoilDensi, SoilT, Soil_Ice, SoilDepth,
     > SoilPoros, SoilWater, SoilClay, NH4, NH3, clay_NH4, NO3,
     > an_NO3, N2O,
     > an_N2O, NO, an_NO, NO2, NO2_w, N2, N2_w, DOC, an_DOC, O2,
     > pH, mi_akt,SOC, anvf,
     > denitrifier, mi_den_akt, O2_cons, O2_old, D_soil_effect,SoilWilt
c
      real
     > day_floor_no,
     > day_floor_n2o,
     > day_floor_n2,
     > day_nh3,
     > day_CH4up,
     > day_CH4,
     > day_CH4_plant,
     > day_CH4_ebullition,
     > day_CH4_diffusion
c
      common /comghg04/ day_floor_no,day_floor_n2o,day_floor_n2,day_nh3,
     > day_CH4up,day_CH4,
     > day_CH4_plant,day_CH4_ebullition,day_CH4_diffusion
c
c
c    CH4 module
c     > F_aerenchyma(npoi,nsoilay),
      real
     > WaterT(npoi),    ! water table, unit cm, from ground suface, should be converted to "m" in program  !initialization ???
c                          -: below ground; +: above ground
c
     > B_RiceWet(npoi),    ! bool variable to identify the grid is rice paddy, wetland or not
c                            we constructe an input layer to initialize this variable
c                            0: not rice paddy or wetland, 1: rice paddy (one season),
c                            2: rice paddy (two seasons) 3: rice paddy (three seasons)
c                            4: wetland
c     > AccumuDrainage(npoi), ! In wetland, Drainage process is not considered and the water is
c                            ! accumulated in soil profile
c
     > WetlandFra(npoi),              ! wetland fraction in each pixel
     > IWetlandFra(npoi),             ! input wetland fraction in each pixel
     > EH(npoi,nsoilay),  ! initialized as 600.00
     > flood_days(npoi,nsoilay), ! day number of continually submerging for each soil layer
     > Mn4(npoi,nsoilay),        ! ion Mn4
     > Mn2(npoi,nsoilay),
     > Fe3(npoi,nsoilay),
     > Fe2(npoi,nsoilay),
     > SO4(npoi,nsoilay),
     > H2S(npoi,nsoilay),
c
     > CH4UP(npoi),
     > CH4(npoi,nsoilay),  !initialize
     > WaterT_i(npoi),               ! water table located in i layer

     > Q10(npoi),                     ! add two variables for methane production 2012-10-05
     > r_CH4CO2(npoi)

c
      common /comghg05/ WaterT,B_RiceWet,WetlandFra,IWetlandFra,
     >    EH,flood_days,
     >    Mn4,Mn2,Fe3,Fe2,SO4,H2S,CH4UP,CH4,WaterT_i,Q10,r_CH4CO2
c
c    daily statistic for Nitrification and denitrification
c
      real
     >  adnoflux(npoi),           ! daily total NO flux
     >  adn2oflux(npoi),          ! daily total N2O flux
     >  adn2flux(npoi),           ! daily total N2 flux
     >  adnh3flux(npoi),          ! daily total NH3 flux
c
     >  adCH4uptake(npoi),        ! daily total CH4 uptake
     >  adCH4(npoi),               ! daily total CH4
     >  adCH4_plant(npoi),         ! daily CH4 by plant
     >  adCH4_ebullition(npoi),    ! daily CH4 by ebullition
     >  adCH4_diffusion(npoi),     ! daily CH4 by diffusion
     >  adWaterT(npoi),             ! daily water table
     >  adNH4(npoi),
     >  adNO3(npoi)

      common /comghgfluxd/ adnoflux,adn2oflux,adn2flux,adnh3flux,
     >                   adCH4uptake,adCH4,
     >                   adCH4_plant,adCH4_ebullition,adCH4_diffusion,   !daily trace gas flux
     >                   adWaterT,adNH4,adNO3
c
c    monthly statistic for Nitrification and denitrification
c
      real
     >  amnoflux(npoi),           ! monthly total NO flux
     >  amn2oflux(npoi),          ! monthly total N2O flux
     >  amn2flux(npoi),           ! monthly total N2 flux
     >  amnh3flux(npoi),          ! monthly total NH3 flux
c
     >  amCH4uptake(npoi),         ! monthly total CH4 uptake
     >  amCH4(npoi),               ! monthly total CH4
     >  amCH4_plant(npoi),         ! monthly CH4 by plant
     >  amCH4_ebullition(npoi),    ! monthly CH4 by ebullition
     >  amCH4_diffusion(npoi),     ! monthly CH4 by diffusion
     >  amWaterT(npoi),            ! monthly mean water table for Wetland
     >  amNH4(npoi),
     >  amNO3(npoi)
      common /comghgfluxm/ amnoflux,amn2oflux,amn2flux,amnh3flux,
     >                   amCH4uptake,amCH4,
     >                   amCH4_plant,amCH4_ebullition,amCH4_diffusion,   !monthly trace gas flux
     >                   amWaterT,amNH4,amNO3
c
c    yearly statistic for Nitrification and denitrification
c
      real
     >  aynoflux(npoi),           ! yearly total NO flux
     >  ayn2oflux(npoi),          ! yearly total N2O flux
     >  ayn2flux(npoi),           ! yearly total N2 flux
     >  aynh3flux(npoi),          ! yearly total NH3 flux
c
     >  ayCH4uptake(npoi),         ! yearly total CH4 uptake
     >  ayCH4(npoi),               ! yearly total CH4
     >  ayCH4_plant(npoi),         ! yearly CH4 by plant
     >  ayCH4_ebullition(npoi),    ! yearly CH4 by ebullition
     >  ayCH4_diffusion(npoi),     ! yearly CH4 by diffusion
     >  ayWaterT(npoi),             ! yearly mean water table for Wetland
     >  ayNH4(npoi),
     >  ayNO3(npoi)
      common /comghgfluxy/ aynoflux,ayn2oflux,ayn2flux,aynh3flux,
     >                   ayCH4uptake,ayCH4,
     >                   ayCH4_plant,ayCH4_ebullition,ayCH4_diffusion,   !yearly trace gas flux
     >                   ayWaterT,ayNH4,ayNO3
c
      real
     >  NPlantUp(npoi),         !bio_1117
     >  N_Imm(npoi),            !bio_1025
     >  GHG_fleach(npoi),       !bio_1902
     >  WT_Factors,             !physiology_317   !effects of Water table on photosynthesis
     >  rprd(npoi),             !wetland biomass production adjust ratio
     >  rltr(npoi),             !wetland litter production adjust ratio
     >  rrh(npoi),              !wetland soil respiration adjust ratio
     >  rsed(npoi)              !wetland soil sediment adjust ratio
      common /comghgAppend/ NPlantUp,N_Imm,GHG_fleach,WT_Factors,
     > rprd, rltr, rrh, rsed


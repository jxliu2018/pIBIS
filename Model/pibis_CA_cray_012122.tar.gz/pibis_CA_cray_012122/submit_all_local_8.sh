rm -rf ../xibis*
sub_region_N_blocks_segment_comp_dyn_local p_list_tmp.asc 50 CONUS-Carbon

cd ../xibis1
#qsub myscript_cray.sh
pibis_p000_local
sleep 5
mpirun -np 4 pibis_p_local

cd ../xibis2
#qsub myscript_cray.sh
pibis_p000_local
sleep 5
mpirun -np 4 pibis_p_local

cd ../xibis3
#qsub myscript_cray.sh
pibis_p000_local
sleep 5
mpirun -np 4 pibis_p_local

cd ../xibis4
#qsub myscript_cray.sh
pibis_p000_local
sleep 5
mpirun -np 4 pibis_p_local

cd ../xibis5
#qsub myscript_cray.sh
pibis_p000_local
sleep 5
mpirun -np 4 pibis_p_local

cd ../xibis6
#qsub myscript_cray.sh
pibis_p000_local
sleep 5
mpirun -np 4 pibis_p_local

cd ../xibis7
#qsub myscript_cray.sh
pibis_p000_local
sleep 5
mpirun -np 4 pibis_p_local

cd ../xibis8
#qsub myscript_cray.sh
pibis_p000_local
sleep 5
mpirun -np 4 pibis_p_local


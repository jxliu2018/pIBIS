#!/bin/bash
sleep_time1=10s
block=1
while [ $block -le 8 ]; do
  echo
  echo current block: ibis$block

  cp -p ./invert.40.sh ../xibis$block/invert.sh
  cp -p ./pIO_invert ../xibis$block/pIO_invert
  let block=block+1
  echo
  sleep $sleep_time1
done

block=1
while [ $block -le 8 ]; do
  echo
  echo current block: ibis$block

  cd ../xibis$block
  invert.sh > /dev/null &
  let block=block+1
  echo
  sleep $sleep_time1
done

exit



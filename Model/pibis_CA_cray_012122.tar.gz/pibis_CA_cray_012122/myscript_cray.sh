#!/bin/bash
#COBALT -t 50
#COBALT -n 128
#COBALT -q default
#COBALT --attrs mcdram=cache:numa=quad
#COBALT -A CONUS-Carbon
echo "Starting Cobalt job script"
export n_nodes=$COBALT_JOBSIZE
export n_mpi_ranks_per_node=64
export n_mpi_ranks=7376
export n_openmp_threads_per_rank=0
export n_hardware_threads_per_core=1
export n_hardware_threads_skipped_between_ranks=1
aprun -n $n_mpi_ranks -N $n_mpi_ranks_per_node \
  --env OMP_NUM_THREADS=$n_openmp_threads_per_rank -cc depth \
  -d $n_hardware_threads_skipped_between_ranks \
  -j $n_hardware_threads_per_core \
  pibis_p_cray

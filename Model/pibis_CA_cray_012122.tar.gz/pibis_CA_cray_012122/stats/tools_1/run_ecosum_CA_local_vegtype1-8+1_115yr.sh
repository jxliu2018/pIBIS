#### convert netcdf_m.data to raw binery_m.data
go xcovmax_m.nc xcovmax xcovmax.dat
go ecoreg_m.nc ecoreg ecoreg.dat
go fips_m.nc fips fips.dat
go fu_m.nc fu fu.dat
go vegtype0_m.nc vegtype0 vegtype0_m.dat
extract_original_mask p_list_extract_mask1-8+1.asc
Dat2NC_x ibis.infile.dat2nc veg_mask1-8+1.dat veg veg_mask1-8+1.nc

#### do region summary
fipsum_ibis xcovmax_m.nc xcovmax veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis fu_m.nc fu veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis cbiotot_m.nc cbiotot veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis totbiou_m.nc totbiou veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis totcsoi_m.nc totcsoi veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis stddown_m.nc stddown veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis cgrain_m.nc cgrain veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis vegtype0_m.nc vegtype0 veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis aynpptot_m.nc aynpptot veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0 

fipsum_ibis totlit_m.nc totlit veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis ayneetot_m.nc ayneetot veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis aynbp_m.nc aynbp veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0 
fipsum_ibis ayCH4_m.nc ayCH4 veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0 
fipsum_ibis ayn2oflux_m.nc ayn2oflux veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0 
fipsum_ibis gdd5this_m.nc gdd5this veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis ayprcp_m.nc ayprcp veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis totceco_m.nc totceco veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis yrleach_m.nc yrleach veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0

fipsum_ibis xdist_m.nc xdist veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis logging_m.nc logging veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis soilcomb_m.nc soilcomb veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis vegcomb_m.nc vegcomb veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis strawc_m.nc strawc veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis deadcrem_m.nc deadcrem veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis livecrem_m.nc livecrem veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis cdisturb_m.nc cdisturb veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis totwdl_m.nc totwdl veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis stdwdc_m.nc stdwdc veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0

fipsum_ibis rawlitc_m.nc rawlitc veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis fallw_m.nc fallw veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis livc2std_m.nc livc2std veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis livc2down_m.nc livc2down veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis stdwcloss_m.nc stdwcloss veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis down2lit_m.nc down2lit veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis lit2co2_m.nc lit2co2 veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis lit2soc_m.nc lit2soc veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis soc2co2_m.nc soc2co2 veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis raw2lit_m.nc raw2lit veg_mask1-8+1.dat float 33 20 1 115 fu.dat 0.0 1.0

sum_all_10000 p_list_sum_all_veg1-8+1.asc
tar czf sum_vegtype1-8+1_fu0010.tar.gz sum_*.txt 


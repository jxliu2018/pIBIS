echo aynbp_m.nc!
cp -p p_list_avg_std_aynbp_m.asc p_list_avg_std.asc
avg_std p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc std.dat std std_aynbp_m.nc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_aynbp_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_aynbp_m.nc
mv subset.dat subset_aynbp_m.dat
mv mean.dat mean_aynbp_m.dat

xy_slope p_list_xy_slope_prec_aynbp.asc
Dat2NC_x ibis.infile.dat2nc slope_aynbp_m.dat slope slope_prec_aynbp_m.nc
xy_slope p_list_xy_slope_temp_aynbp.asc
Dat2NC_x ibis.infile.dat2nc slope_aynbp_m.dat slope slope_temp_aynbp_m.nc
xy_slope_dummy p_list_xy_slope_dummy_aynbp.asc 
Dat2NC_x ibis.infile.dat2nc slope_aynbp_dummy.dat slope slope_aynbp_dummy.nc

echo ayneetot_m.nc!
cp -p p_list_avg_std_ayneetot_m.asc p_list_avg_std.asc
avg_std p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc std.dat std std_ayneetot_m.nc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_ayneetot_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_ayneetot_m.nc
mv subset.dat subset_ayneetot_m.dat
mv mean.dat mean_ayneetot_m.dat

xy_slope p_list_xy_slope_prec_ayneetot.asc
Dat2NC_x ibis.infile.dat2nc slope_ayneetot_m.dat slope slope_prec_ayneetot_m.nc
xy_slope p_list_xy_slope_temp_ayneetot.asc
Dat2NC_x ibis.infile.dat2nc slope_ayneetot_m.dat slope slope_temp_ayneetot_m.nc
xy_slope_dummy p_list_xy_slope_dummy_ayneetot.asc 
Dat2NC_x ibis.infile.dat2nc slope_ayneetot_dummy.dat slope slope_ayneetot_dummy.nc

echo aynpptot_m.nc!
cp -p p_list_avg_std_aynpptot_m.asc p_list_avg_std.asc
avg_std p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc std.dat std std_aynpptot_m.nc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_aynpptot_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_aynpptot_m.nc
mv subset.dat subset_aynpptot_m.dat
mv mean.dat mean_aynpptot_m.dat

xy_slope p_list_xy_slope_prec_aynpptot.asc
Dat2NC_x ibis.infile.dat2nc slope_aynpptot_m.dat slope slope_prec_aynpptot_m.nc
xy_slope p_list_xy_slope_temp_aynpptot.asc
Dat2NC_x ibis.infile.dat2nc slope_aynpptot_m.dat slope slope_temp_aynpptot_m.nc
xy_slope_dummy p_list_xy_slope_dummy_aynpptot.asc 
Dat2NC_x ibis.infile.dat2nc slope_aynpptot_dummy.dat slope slope_aynpptot_dummy.nc

echo vegtype0_m.nc!
cp -p p_list_avg_std_vegtype0_m.asc p_list_avg_std.asc
avg_std p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_vegtype0_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_vegtype0_m.nc

echo lit2co2_m.nc!
cp -p p_list_avg_std_lit2co2_m.asc p_list_avg_std.asc
avg_std p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc std.dat std std_lit2co2_m.nc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_lit2co2_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_lit2co2_m.nc
mv subset.dat subset_lit2co2_m.dat
mv mean.dat mean_lit2co2_m.dat

xy_slope p_list_xy_slope_prec_lit2co2.asc
Dat2NC_x ibis.infile.dat2nc slope_lit2co2_m.dat slope slope_prec_lit2co2_m.nc
xy_slope p_list_xy_slope_temp_lit2co2.asc
Dat2NC_x ibis.infile.dat2nc slope_lit2co2_m.dat slope slope_temp_lit2co2_m.nc
xy_slope_dummy p_list_xy_slope_dummy_lit2co2.asc
Dat2NC_x ibis.infile.dat2nc slope_lit2co2_dummy.dat slope slope_lit2co2_dummy.nc

echo soc2co2_m.nc!
cp -p p_list_avg_std_soc2co2_m.asc p_list_avg_std.asc
avg_std p_list_avg_std.asc
Dat2NC_x ibis.infile.dat2nc std.dat std std_soc2co2_m.nc
Dat2NC_x ibis.infile.dat2nc mean.dat mean mean_soc2co2_m.nc
Dat2NC_x ibis.infile.dat2nc.sub subset.dat subset subset_soc2co2_m.nc
mv subset.dat subset_soc2co2_m.dat
mv mean.dat mean_soc2co2_m.dat

xy_slope p_list_xy_slope_prec_soc2co2.asc
Dat2NC_x ibis.infile.dat2nc slope_soc2co2_m.dat slope slope_prec_soc2co2_m.nc
xy_slope p_list_xy_slope_temp_soc2co2.asc
Dat2NC_x ibis.infile.dat2nc slope_soc2co2_m.dat slope slope_temp_soc2co2_m.nc
xy_slope_dummy p_list_xy_slope_dummy_soc2co2.asc
Dat2NC_x ibis.infile.dat2nc slope_soc2co2_dummy.dat slope slope_soc2co2_dummy.nc

echo sensitivity_low!
sensitivity.low p_list_npp_sensitivity.asc
sensitivity.low p_list_nbp_sensitivity.asc
sensitivity.low p_list_nee_sensitivity.asc
sensitivity.low p_list_lit2co2_sensitivity.asc
sensitivity.low p_list_soc2co2_sensitivity.asc
mv npp_sensitivity.dat npp_sensitivity_low.dat
mv nbp_sensitivity.dat nbp_sensitivity_low.dat
mv nee_sensitivity.dat nee_sensitivity_low.dat
mv lit2co2_sensitivity.dat lit2co2_sensitivity_low.dat
mv soc2co2_sensitivity.dat soc2co2_sensitivity_low.dat
Dat2NC_x ibis.infile.dat2nc npp_sensitivity_low.dat npp_sl npp_sensitivity_low.nc
Dat2NC_x ibis.infile.dat2nc nbp_sensitivity_low.dat nbp_sl nbp_sensitivity_low.nc
Dat2NC_x ibis.infile.dat2nc nee_sensitivity_low.dat nee_sl nee_sensitivity_low.nc
Dat2NC_x ibis.infile.dat2nc lit2co2_sensitivity_low.dat lit2co2_sl lit2co2_sensitivity_low.nc
Dat2NC_x ibis.infile.dat2nc soc2co2_sensitivity_low.dat soc2co2_sl soc2co2_sensitivity_low.nc

echo Finished!

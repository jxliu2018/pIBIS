echo 1
tar -xzf fips_m.nc.tar.gz
echo 2
tar -xzf ecoreg_m.nc.tar.gz
echo 3
tar -xzf xcovmax_m.nc.tar.gz
echo 4
tar -xzf fu_m.nc.tar.gz
echo 5
tar -xzf vegtype0_m.nc.tar.gz
echo 6
tar -xzf cbiotot_m.nc.tar.gz
echo 7
tar -xzf totbiou_m.nc.tar.gz
echo 8
tar -xzf totcsoi_m.nc.tar.gz
echo 9
tar -xzf stddown_m.nc.tar.gz
echo 10
tar -xzf cgrain_m.nc.tar.gz
echo 11
tar -xzf aynpptot_m.nc.tar.gz
echo 12
tar -xzf totlit_m.nc.tar.gz
echo 13
tar -xzf ayneetot_m.nc.tar.gz
echo 14
tar -xzf aynbp_m.nc.tar.gz
echo 15
tar -xzf ayCH4_m.nc.tar.gz
echo 16
tar -xzf ayn2oflux_m.nc.tar.gz
echo 17
tar -xzf gdd5this_m.nc.tar.gz
echo 18
tar -xzf ayprcp_m.nc.tar.gz
echo 19
tar -xzf totceco_m.nc.tar.gz
echo 20
tar -xzf yrleach_m.nc.tar.gz
echo 21
tar -xzf xdist_m.nc.tar.gz
echo 22
tar -xzf logging_m.nc.tar.gz
echo 23
tar -xzf soilcomb_m.nc.tar.gz
echo 24
tar -xzf vegcomb_m.nc.tar.gz
echo 25
tar -xzf strawc_m.nc.tar.gz
echo 26
tar -xzf deadcrem_m.nc.tar.gz
echo 27
tar -xzf livecrem_m.nc.tar.gz
echo 28
tar -xzf cdisturb_m.nc.tar.gz
echo 29
tar -xzf totwdl_m.nc.tar.gz
echo 30
tar -xzf stdwdc_m.nc.tar.gz
echo 31
tar -xzf rawlitc_m.nc.tar.gz
echo 32
tar -xzf fallw_m.nc.tar.gz
echo 33
tar -xzf livc2std_m.nc.tar.gz
echo 34
tar -xzf livc2down_m.nc.tar.gz
echo 35
tar -xzf stdwcloss_m.nc.tar.gz
echo 36
tar -xzf down2lit_m.nc.tar.gz
echo 37
tar -xzf lit2co2_m.nc.tar.gz
echo 38
tar -xzf lit2soc_m.nc.tar.gz
echo 39
tar -xzf soc2co2_m.nc.tar.gz
echo 40
tar -xzf raw2lit_m.nc.tar.gz


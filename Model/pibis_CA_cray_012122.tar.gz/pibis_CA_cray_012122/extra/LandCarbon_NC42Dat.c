//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h> 

#include "netcdf.h"
#define arr_size 200

#pragma hdrstop

//---------------------------------------------------------------------------

#pragma argsused

char sourcefile[arr_size], targetfile[arr_size], variablename[arr_size];
void NC2DatAll(char *ncsource, char *nctarget, char *varname);

int main(int argc, char* argv[])
{
    if(argc < 4){
      printf("\nThis program converts netcdf file to binary dat file.\n");
      printf("Usage: a.out sourcefile varname targetfile\n");
      return 0;
    }
    strcpy( sourcefile, argv[1]);
    strcpy( variablename, argv[2]);
    strcpy( targetfile, argv[3]);

    NC2DatAll(sourcefile, targetfile, variablename);
    printf("Finished Netcdf to dat Conversion! %s \n", targetfile);

    return 0;
}
//---------------------------------------------------------------------------
void NC2DatAll(char *ncsource, char *dattarget, char *varname)
{
  int nc_id, var_id, dim, dimids[4], var_natts;
  nc_type var_type;
  size_t array_length, dim_len[4];
  int elementsize;
  int i;

  if(nc_open(ncsource,NC_NOWRITE,&nc_id) != NC_NOERR) {
    printf("Error opening source NETCDF file");
    return;
  }
  nc_inq_varid (nc_id, varname, &var_id);
  nc_inq_var(nc_id, var_id, 0, &var_type, &dim, dimids, &var_natts);
  array_length = 1;
  for(i=0; i<dim; i++){
    nc_inq_dimlen(nc_id, dimids[i], &dim_len[i]);
    array_length = array_length * dim_len[i];
  }

  FILE *fTargetFile;
  if((fTargetFile=fopen(dattarget,"wb")) == NULL){
    printf("Error opening target DAT file");
    return;
  }

  {
    if(var_type == NC_BYTE) {/*byte data type is signed-char*/
      elementsize = sizeof(signed char);
      signed char *yArray = (signed char *) malloc(array_length * elementsize);
      nc_get_var_schar(nc_id, var_id, yArray);
      fwrite(yArray, elementsize, array_length, fTargetFile);
      free(yArray);
    }
    if(var_type == NC_CHAR) {/*this is for text*/
      elementsize = sizeof(char);
      char *yArray = (char *) malloc(array_length * elementsize);
      nc_get_var_schar(nc_id, var_id, yArray);
      fwrite(yArray, elementsize, array_length, fTargetFile);
      free(yArray);
    }
    if(var_type == NC_SHORT) {
      elementsize = sizeof(short);
      short *yArray = (short *) malloc(array_length * elementsize);
      nc_get_var_short(nc_id, var_id, yArray);
      fwrite(yArray, elementsize, array_length, fTargetFile);
      free(yArray);
    }
    if(var_type == NC_INT) {
      elementsize = sizeof(int);
      int *yArray = (int *) malloc(array_length * elementsize);
      nc_get_var_int(nc_id, var_id, yArray);
      fwrite(yArray, elementsize, array_length, fTargetFile);
      free(yArray);
    }
    if(var_type== NC_FLOAT) {
      elementsize = sizeof(float);
      float *yArray = (float *) malloc(array_length * elementsize);
      nc_get_var_float(nc_id, var_id, yArray);
      fwrite(yArray, elementsize, array_length, fTargetFile);
      free(yArray);
    }
    if(var_type== NC_DOUBLE) {
      elementsize = sizeof(double);
      double *yArray = (double *) malloc(array_length * elementsize);
      nc_get_var_double(nc_id, var_id, yArray);
      fwrite(yArray, elementsize, array_length, fTargetFile);
      free(yArray);
    }

    /*new netcdf4 types*/
/*
    if(var_type== NC_UBYTE) {
      elementsize = sizeof(unsigned char);
      unsigned char *yArray = (unsigned char *) malloc(array_length * elementsize);
      nc_get_var_uchar(nc_id, var_id, yArray);
      fwrite(yArray, elementsize, array_length, fTargetFile);
      free(yArray);
    }
    if(var_type == NC_USHORT) {
      elementsize = sizeof(unsigned short);
      unsigned short *yArray = (unsigned short *) malloc(array_length * elementsize);
      nc_get_var_ushort(nc_id, var_id, yArray);

        //int i;
        //elementsize = sizeof(short);
        //short *yyArray = (short *) malloc(array_length * elementsize);
        //for(i=0; i<array_length; i++){
        //  yyArray[i] = (short)yArray[i];
        //}
        int i;
        elementsize = sizeof(int);
        int *yyArray = (int *) malloc(array_length * elementsize);
        for(i=0; i<array_length; i++){
          yyArray[i] = (int)yArray[i];
        }

      fwrite(yyArray, elementsize, array_length, fTargetFile);
      free(yArray);
      free(yyArray);
    }
    if(var_type == NC_UINT) {
      elementsize = sizeof(unsigned int);
      unsigned int *yArray = (unsigned int *) malloc(array_length * elementsize);
      nc_get_var_uint(nc_id, var_id, yArray);

        int i;
        elementsize = sizeof(int);
        int *yyArray = (int *) malloc(array_length * elementsize);
        for(i=0; i<array_length; i++){
          yyArray[i] = (int)yArray[i];
        }

      fwrite(yyArray, elementsize, array_length, fTargetFile);
      free(yArray);
      free(yyArray);
    }
*/
  }
  fclose(fTargetFile);
  nc_close(nc_id);
}
//---------------------------------------------------------------------------

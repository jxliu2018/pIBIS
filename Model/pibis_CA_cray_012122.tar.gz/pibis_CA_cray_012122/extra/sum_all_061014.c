//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 

#define buf_size 10000
#define str_size 200

int main(int argc, char* argv[])
{
  FILE *fp1, *fp2, *fp[100];
  char plistfile[str_size], sumfile[str_size], buffer[buf_size], S[str_size];
  int i, j, line;

  if(argc < 2){
    printf("  This program extract one line from all sum_*.txt files\n");
    printf("  usage: sum_extract p_list_sum_all.asc\n");
    printf("  note: maximum line length is 10000 in sum_*.txt\n");
  }

//open p_list file
  strcpy(plistfile, argv[1]);
  if ((fp1 = fopen(plistfile, "rt"))==NULL){
    printf("no p_list file found! \n");
    return 0;
  }

//get the number for skip lines
  fscanf(fp1, "%d", &line);
  fgets(buffer, str_size, fp1);

//get the output file name 
  fscanf(fp1, "%s", sumfile);
  fgets(buffer, str_size, fp1);
  if ((fp2 = fopen(sumfile, "wt"))==NULL){
    printf("can not create output file! \n");
    return 0;
  }

//read each sum_txt file and write output sum_all file
  for(i=0; i<1000; i++){
    fscanf(fp1, "%s", S);
    if(!strcmp(S, "-999"))
      break;

    fp[i] = fopen(S, "rt");
    if ((fp[i] = fopen(S, "rt"))==NULL){
      printf("cannot open file %d, %s, set value to NAN!\n", i+1, S);
      fprintf(fp2, "%s\t", S);
      fputs("NAN\n", fp2);
    }
    else{
      for(j=0; j<line; j++){ //skip those lines
        fgets(buffer, buf_size, fp[i]);
      }

      fprintf(fp2, "%s\t", S);
      fputs(buffer, fp2);
      fclose(fp[i]);
      printf("processed file %d, %s\n", i+1, S);
    }
  }
  fclose(fp2);

  return 0;
}

//---------------------------------------------------------------------------

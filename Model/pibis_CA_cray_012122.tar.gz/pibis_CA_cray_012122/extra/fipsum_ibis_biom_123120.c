//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sys/stat.h> 

#include "netcdf.h"
#define arr_size 200
#define year_max 300
#define ecoreg_max 3200
#define max_value 10000
#define min_value -1000

float** Make2DFloatArray(int, int);
int** Make2DIntArray(int, int);

#pragma hdrstop

//---------------------------------------------------------------------------

#pragma argsused

int main(int argc, char* argv[])
{
  int nc_id, var_id, dim, dimids[4], var_natts;
  nc_type var_type;
  size_t array_length, dim_len[4];

  FILE *fp1, *fpMaskGrid, *fpCoverGrid;
  char sourcefile[arr_size], variablename[arr_size];
  char mask_filename[100], out_filename[100], cover_filename[100], S[10];
  int row, col, start_year, end_year, year;
  int i, j, k;
  int elementsize, elementsize1;
  int total_ecoreg, ecoreg_id[ecoreg_max];
  double ecosum_tot[year_max], ecoavg_tot[year_max], ecoavg_tot_rate[year_max];
  int count1_tot[year_max];
  int tmp_int, tmp;
  float tmp_float;
  double tmp_floatx;
  short tmp_short;
  char tmp_char;
  unsigned char tmp_uchar;
  int index1, index2, index3;
  char mask_type[20];
  float cover1, cover2;
  float p, se_agg[year_max];

  if(argc < 9){
    printf("  This program sumarize model nc3/nc4 output by region and by cover\n");
    printf("  usage: ecosum nc_file variable mask_file mask_type total_row total_col start_yr end_yr cover_file cover_low cover_high\n");
    printf("  example: ecosum aynpptot.nc aynpptot ecoreg.dat float 1526 2412 1 70 fu.dat 0.5 1.0\n");
    printf("  the output is sum_aynpptot.nc.txt\n");
    printf("  cover and variable are float type ...\n");
    printf("  year_max 300\n");
    printf("  ecoreg_max 3200\n");
    printf("  max_value 10000\n");
    printf("  min_value -1000\n");
    printf("  pIBIS post_processing program: fipsum_ibis_biom\n");
    printf("  Jinxun Liu, USGS\n");
    printf("  Last updated: 123120\n");

    return 0;
  }

  strcpy(sourcefile, argv[1]);
  strcpy(variablename, argv[2]);
  strcpy(mask_filename, argv[3]);
  strcpy(mask_type, argv[4]);
  strcpy(S, argv[5]);
  row = atoi(S);
  strcpy(S, argv[6]);
  col = atoi(S);
  strcpy(S, argv[7]);
  start_year = atoi(S)-1;
  strcpy(S, argv[8]);
  end_year = atoi(S)-1;
  year = end_year - start_year + 1;

//netcdf reading portion
  if(nc_open(sourcefile,NC_NOWRITE,&nc_id) != NC_NOERR) {
    printf("Error opening source NETCDF file");
    return 0;
  }

  nc_inq_varid (nc_id, variablename, &var_id);
  nc_inq_var(nc_id, var_id, 0, &var_type, &dim, dimids, &var_natts);
  array_length = 1;
  for(i=0; i<dim; i++){
    nc_inq_dimlen(nc_id, dimids[i], &dim_len[i]);
    array_length = array_length * dim_len[i];
  }

  elementsize = sizeof(float);
  float *yArray = (float *) malloc(array_length * elementsize);
  nc_get_var_float(nc_id, var_id, yArray);
  nc_close(nc_id);

//sum_avg portion
  if(argc >= 12){
    strcpy(cover_filename, argv[9]);
    strcpy(S, argv[10]);
    cover1 = atof(S);
    strcpy(S, argv[11]);
    cover2 = atof(S);
  }

  float** ecosum = Make2DFloatArray(ecoreg_max, year_max);
  float** ecoavg = Make2DFloatArray(ecoreg_max, year_max);
  float** ecoavg_rate = Make2DFloatArray(ecoreg_max, year_max);
  int** count = Make2DIntArray(ecoreg_max, year_max);
  int** count1 = Make2DIntArray(ecoreg_max, year_max);
  float** x2 = Make2DFloatArray(ecoreg_max, year_max);
  float** std = Make2DFloatArray(ecoreg_max, year_max);
  float** var = Make2DFloatArray(ecoreg_max, year_max);
  float** se = Make2DFloatArray(ecoreg_max, year_max);

  int** MaskGrid = Make2DIntArray(row, col);
  float** CoverGrid = Make2DFloatArray(row, col);
  for (i=0;i<ecoreg_max;i++){
    ecoreg_id[i] = -1;
    for (j=0;j<year_max;j++){
      count[i][j] = 0;
      count1[i][j] = 0;
      ecosum[i][j] = 0;
      ecoavg[i][j] = 0;
      x2[i][j] = 0;
      std[i][j] = 0;
      var[i][j] = 0;
      se[i][j] = 0;
    }
  }
  for (i=0;i<row;i++){
    for (j=0;j<col;j++){
      MaskGrid[i][j] = -1;
      CoverGrid[i][j] = 0.0;
    }
  }
  for (j=0;j<year_max;j++){
    ecosum_tot[j] = 0;
    ecoavg_tot[j] = 0;
    count1_tot[j] = 0;
    se_agg[j] = 0;
  }

  if ((fpMaskGrid = fopen(mask_filename, "rb"))==NULL){
    printf("no mask file found! \n");
    return 0;
  }
  printf("reading mask file %s and cover file %s\n", mask_filename, cover_filename);
  if(strcmp(mask_type, "int") == 0){
    elementsize = sizeof(int);
    for (i=0;i<row;i++){
      for (j=0;j<col;j++){
        fread(&tmp_int, elementsize, 1, fpMaskGrid);
        if (tmp_int >= 0 && tmp_int < 60000)
          MaskGrid[i][j] = tmp_int;
      }
    }
  }
  if(strcmp(mask_type, "float") == 0){
    elementsize = sizeof(float);
    for (i=0;i<row;i++){
      for (j=0;j<col;j++){
        fread(&tmp_float, elementsize, 1, fpMaskGrid);
        tmp_int = (int)tmp_float;
        if (tmp_int >= 0 && tmp_int < 60000)
          MaskGrid[i][j] = tmp_int;
      }
    }
  }
  if(strcmp(mask_type, "short") == 0){
    elementsize = sizeof(short);
    for (i=0;i<row;i++){
      for (j=0;j<col;j++){
        fread(&tmp_short, elementsize, 1, fpMaskGrid);
        tmp_int = (int)tmp_short;
        if (tmp_int >= 0 && tmp_int < 60000)
          MaskGrid[i][j] = tmp_int;
      }
    }
  }
  if(strcmp(mask_type, "uchar") == 0){
    elementsize = sizeof(unsigned char);
    for (i=0;i<row;i++){
      for (j=0;j<col;j++){
        fread(&tmp_uchar, elementsize, 1, fpMaskGrid);
        tmp_int = (int)tmp_uchar;
        if (tmp_int >= 0 && tmp_int < 60000)
          MaskGrid[i][j] = tmp_int;
      }
    }
  }
  if(strcmp(mask_type, "char") == 0){
    elementsize = sizeof(char);
    for (i=0;i<row;i++){
      for (j=0;j<col;j++){
        fread(&tmp_char, elementsize, 1, fpMaskGrid);
        tmp_int = (int)tmp_char;
        if (tmp_int >= 0 && tmp_int < 60000)
          MaskGrid[i][j] = tmp_int;
      }
    }
  }

  printf("rearrange mask id ... to serial numbers 1, 2, 3 ...\n");
  total_ecoreg = 0;
  for (i=0;i<row;i++){
    for (j=0;j<col;j++){
      if(MaskGrid[i][j] >= 0){
        for(k=0;k<ecoreg_max;k++){
          if(ecoreg_id[k] == -1){
            ecoreg_id[k] = MaskGrid[i][j];
            MaskGrid[i][j] = k + 1;
            total_ecoreg = total_ecoreg + 1;
            break;
          }
          else{
            if(ecoreg_id[k] == MaskGrid[i][j]){
              MaskGrid[i][j] = k + 1;
              break;
            }
          }
        }
      }
    }
  }

  if(argc < 12){/*no summary by land cover type*/
    printf("skip %d years and read next %d years.\n", start_year, year);
    for (k=0;k<year;k++){
      index1 = (start_year + k)*row*col;
      for (i=0;i<row;i++){
        index2 = index1 + i*col;
        for (j=0;j<col;j++){
          index3 = index2 + j;
          tmp_floatx = yArray[index3]; //this is the variable to sum
          tmp = MaskGrid[i][j]-1;     //this is the region id
          if(tmp >= 0){
            count[tmp][k] = count[tmp][k] + 1;//this is count of valid land
            if(tmp_floatx > min_value && tmp_floatx < max_value){
              ecosum[tmp][k] = ecosum[tmp][k] + tmp_floatx;
              count1[tmp][k] = count1[tmp][k] + 1;//this is count of land with valid variable
              ecosum_tot[k] = ecosum_tot[k] + tmp_floatx;
              count1_tot[k] = count1_tot[k] + 1;
              //x2[tmp][k] = x2[tmp][k] + tmp_floatx * tmp_floatx;
              p = (count1[tmp][k] - 1)/count1[tmp][k];
              x2[tmp][k] = x2[tmp][k]*p + (tmp_floatx * tmp_floatx)*(1.0-p);
            }
          }
        }
      }
      printf("finished reading %d of %d years\n", k+1, year);
    }
  }
  else{/*summary by land cover type*/
    if ((fpCoverGrid = fopen(cover_filename, "rb"))==NULL){
      printf("no cover file found! \n");
      return 0;
    }
    elementsize = sizeof(float);
    fseek(fpCoverGrid, start_year*row*col*elementsize, SEEK_SET);

    printf("reading input file %s \n", sourcefile);
    printf("skip %d years and read next %d years.\n", start_year, year);
    for (k=0;k<year;k++){
      //index1 = k*row*col;
      index1 = (start_year + k)*row*col;
      for (i=0;i<row;i++){
        index2 = index1 + i*col;
        for (j=0;j<col;j++){
          fread(&tmp_float, elementsize, 1, fpCoverGrid);
          CoverGrid[i][j] = tmp_float; //e.g. fu 0~1

          index3 = index2 + j;
          tmp_floatx = yArray[index3];  //e.g NPP maps
          tmp = MaskGrid[i][j]-1;      //e.g ecoreg 1~84
          if(tmp >= 0){
            count[tmp][k] = count[tmp][k] + 1;
            if(CoverGrid[i][j] >=cover1 && CoverGrid[i][j]<= cover2 && tmp_floatx > min_value && tmp_floatx < max_value){
              tmp_floatx = tmp_floatx/CoverGrid[i][j]; //for calibration, adjust biomass by fractional cover
              ecosum[tmp][k] = ecosum[tmp][k] + tmp_floatx;
              count1[tmp][k] = count1[tmp][k] + 1;
              ecosum_tot[k] = ecosum_tot[k] + tmp_floatx;
              count1_tot[k] = count1_tot[k] + 1;
              //x2[tmp][k] = x2[tmp][k] + tmp_floatx * tmp_floatx;
              p = (count1[tmp][k] - 1.0)/count1[tmp][k];
              x2[tmp][k] = x2[tmp][k]*p + (tmp_floatx * tmp_floatx)*(1.0-p);
            }
          }
        }
      }
      printf("finished reading %d of %d years\n", k+1, year);
    }
  }

  free(yArray);
  for (i = 0; i < row; i++){
    free(MaskGrid[i]);
  }
  free(MaskGrid);
  fclose(fpMaskGrid);
  if(argc >= 12){
    fclose(fpCoverGrid);
  }

  strcpy(out_filename, "sum_");
  strcat(out_filename, sourcefile);
  if(argc == 13){
    strcat(out_filename, "_");
    strcat(out_filename, argv[12]);
  }
  strcat(out_filename, ".txt");
  if ((fp1 = fopen(out_filename, "wt"))==NULL){
    printf("no output file can be written!\n");
    return 0;
  }

  //printf("model output summary\n");
  //fprintf(fp1, "model output summary\n");
  printf("stats_category");
  fprintf(fp1, "stats_category");
  printf("\tserial_id");
  fprintf(fp1, "\tserial_id");
  printf("\tregion_id");
  fprintf(fp1, "\tregion_id");
  printf("\tregion_area");
  fprintf(fp1, "\tregion_area");
  for (j=0;j<year;j++){
    printf("\t%d", j+start_year+1);
    fprintf(fp1, "\t%d", j+start_year+1);
  }
  printf("\n");
  fprintf(fp1, "\n");

  //printf("\nland cover type -- count1\n");
  //fprintf(fp1, "\nland cover type -- count1\n");
  for (i=0;i<total_ecoreg;i++){
    printf("region_area");
    fprintf(fp1, "region_area");
    printf("\tregion_%d", i+1);
    fprintf(fp1, "\tregion_%d", i+1);
    printf("\t%d", ecoreg_id[i]);
  //print summary
    fprintf(fp1, "\t%d", ecoreg_id[i]);
    printf("\t%d", count[i][0]);
    fprintf(fp1, "\t%d", count[i][0]);
    for (j=0;j<year;j++){
      printf("\t%d", count1[i][j]);
      fprintf(fp1, "\t%d", count1[i][j]);
    }
    printf("\n");
    fprintf(fp1, "\n");
  }

  //printf("\nsum by land cover type -- ecosum\n");
  //fprintf(fp1, "\nsum by land cover type -- ecosum\n");
  for (i=0;i<total_ecoreg;i++){
    printf("region_sum");
    fprintf(fp1, "region_sum");
    printf("\tregion_%d", i+1);
    fprintf(fp1, "\tregion_%d", i+1);
    printf("\t%d", ecoreg_id[i]);
    fprintf(fp1, "\t%d", ecoreg_id[i]);
    printf("\t%d", count[i][0]);
    fprintf(fp1, "\t%d", count[i][0]);
    for (j=0;j<year;j++){
      printf("\t%f", ecosum[i][j]);
      fprintf(fp1, "\t%f", ecosum[i][j]);
    }
    printf("\n");
    fprintf(fp1, "\n");
  }

  //printf("\navg by land cover type -- ecoavg\n");
  //fprintf(fp1, "\navg by land cover type -- ecoavg\n");
  for (i=0;i<total_ecoreg;i++){
    printf("region_avg");
    fprintf(fp1, "region_avg");
    printf("\tregion_%d", i+1);
    fprintf(fp1, "\tregion_%d", i+1);
    printf("\t%d", ecoreg_id[i]);
    fprintf(fp1, "\t%d", ecoreg_id[i]);
    printf("\t%d", count[i][0]);
    fprintf(fp1, "\t%d", count[i][0]);
    for (j=0;j<year;j++){
      if(count1[i][j] > 0){
        ecoavg[i][j] = ecosum[i][j] / count1[i][j];
        var[i][j] = x2[i][j] - ecoavg[i][j]*ecoavg[i][j];
        std[i][j] = sqrt(var[i][j]);
        se[i][j] = std[i][j]/sqrt(count1[i][j]);
      }
      else{
        ecoavg[i][j] = 0;
        var[i][j] = 0;
        std[i][j] = 0;
        se[i][j] = 0;
      }
      printf("\t%f", ecoavg[i][j]);
      fprintf(fp1, "\t%f", ecoavg[i][j]);
    }
    printf("\n");
    fprintf(fp1, "\n");
  }

  //printf("\nstandard deviation by region/type\n");
  //fprintf(fp1, "\nstandard deviation by region/type\n");
  for (i=0;i<total_ecoreg;i++){
    printf("region_std");
    fprintf(fp1, "region_std");
    printf("\tregion_%d", i+1);
    fprintf(fp1, "\tregion_%d", i+1);
    printf("\t%d", ecoreg_id[i]);
    fprintf(fp1, "\t%d", ecoreg_id[i]);
    printf("\t%d", count[i][0]);
    fprintf(fp1, "\t%d", count[i][0]);
    for (j=0;j<year;j++){
      printf("\t%f", std[i][j]);
      fprintf(fp1, "\t%f", std[i][j]);
    }
    printf("\n");
    fprintf(fp1, "\n");
  }
/*
  //printf("\nchange rate by land cover type -- ecoavg_rate\n");
  //fprintf(fp1, "\nchange rate by land cover type -- ecoavg_rate\n");
  for (i=0;i<total_ecoreg;i++){
    printf("region_change");
    fprintf(fp1, "region_change");
    printf("\tregion_%d", i+1);
    fprintf(fp1, "\tregion_%d", i+1);
    printf("\t%d", ecoreg_id[i]);
    fprintf(fp1, "\t%d", ecoreg_id[i]);
    printf("\t%d", count[i][0]);
    fprintf(fp1, "\t%d", count[i][0]);
    for (j=0;j<year;j++){
      if(j==0){
        ecoavg_rate[i][j] = 0;
      }
      else{
        ecoavg_rate[i][j] = ecoavg[i][j] - ecoavg_rate[i][j-1];
      }
      printf("\t%f", ecoavg_rate[i][j]);
      fprintf(fp1, "\t%f", ecoavg_rate[i][j]);
    }
    printf("\n");
    fprintf(fp1, "\n");
  }
*/
  //print overall summary
  printf("total_area");
  fprintf(fp1, "total_area");
  printf("\ttotal_count1");
  fprintf(fp1, "\ttotal_count1");
  printf("\t%d", -9999);
  fprintf(fp1, "\t%d", -9999);
  printf("\t%d", -9999);
  fprintf(fp1, "\t%d", -9999);
  for (j=0;j<year;j++){
    printf("\t%d", count1_tot[j]);
    fprintf(fp1, "\t%d", count1_tot[j]);
  }
  printf("\ntotal_sum");
  fprintf(fp1, "\ntotal_sum");
  printf("\ttotal_count1");
  fprintf(fp1, "\ttotal_count1");
  printf("\t%d", -9999);
  fprintf(fp1, "\t%d", -9999);
  printf("\t%d", -9999);
  fprintf(fp1, "\t%d", -9999);
  for (j=0;j<year;j++){
    printf("\t%f", ecosum_tot[j]);
    fprintf(fp1, "\t%f", ecosum_tot[j]);
  }
  printf("\ntotal_avg");
  fprintf(fp1, "\ntotal_avg");
  printf("\ttotal_count1");
  fprintf(fp1, "\ttotal_count1");
  printf("\t%d", -9999);
  fprintf(fp1, "\t%d", -9999);
  printf("\t%d", -9999);
  fprintf(fp1, "\t%d", -9999);
  for (j=0;j<year;j++){
    if(count1_tot[j] > 0)
      ecoavg_tot[j] = ecosum_tot[j] / count1_tot[j];
    else
      ecoavg_tot[j] = 0;
    printf("\t%f", ecoavg_tot[j]);
    fprintf(fp1, "\t%f", ecoavg_tot[j]);
  }
/*
  printf("\ntotal_change");
  fprintf(fp1, "\ntotal_change");
  printf("\ttotal_count1");
  fprintf(fp1, "\ttotal_count1");
  printf("\t%d", -9999);
  fprintf(fp1, "\t%d", -9999);
  printf("\t%d", -9999);
  fprintf(fp1, "\t%d", -9999);
  for (j=0;j<year;j++){
    if(j==0){
      ecoavg_tot_rate[j] = 0;
    }
    else{
      ecoavg_tot_rate[j] = ecoavg_tot[j] - ecoavg_tot[j-1];
    }
    printf("\t%f", ecoavg_tot_rate[j]);
    fprintf(fp1, "\t%f", ecoavg_tot_rate[j]);
  }
*/
  for (j=0;j<year;j++){
    for (i=0;i<total_ecoreg;i++){
      se_agg[j] = se_agg[j] + se[i][j]*se[i][j];
    }
  }
  printf("\ntotal_se");
  fprintf(fp1, "\ntotal_se");
  printf("\ttotal_count1");
  fprintf(fp1, "\ttotal_count1");
  printf("\t%d", -9999);
  fprintf(fp1, "\t%d", -9999);
  printf("\t%d", -9999);
  fprintf(fp1, "\t%d", -9999);
  for (j=0;j<year;j++){
    se_agg[j] = sqrt(se_agg[j]);
    printf("\t%f", se_agg[j]);
    fprintf(fp1, "\t%f", se_agg[j]);
  }

  fclose(fp1);
  printf("\n\nFinished netcdf summary by region and type! %s \n", sourcefile);

  return 0;
}

float** Make2DFloatArray(int arraySizeX, int arraySizeY) {
  float** theArray;
  int i;
  theArray = (float**) malloc(arraySizeX*sizeof(float*));
  for (i = 0; i < arraySizeX; i++)
   theArray[i] = (float*) malloc(arraySizeY*sizeof(float));
  return theArray;
}
int** Make2DIntArray(int arraySizeX, int arraySizeY) {
  int** theArray;
  int i;
  theArray = (int**) malloc(arraySizeX*sizeof(int*));
  for (i = 0; i < arraySizeX; i++)
   theArray[i] = (int*) malloc(arraySizeY*sizeof(int));
  return theArray;
}

//---------------------------------------------------------------------------

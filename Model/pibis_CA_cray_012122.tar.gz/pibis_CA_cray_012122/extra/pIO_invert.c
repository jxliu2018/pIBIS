#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define arr_size 200

void writeDat(float *, char *, int, int);

int main(int argc, char* argv[])
{
  FILE *fpx;
  char msg[200], S[50], file_list[200]; //has to use x[], not *x

  FILE *fpInGrid, *fpOutGrid;
  char filename[arr_size], filename2[arr_size];

  int nlatsubs, nlonsubs, npoi, mapSsize, arraylength,
      valid_segment, total_segment, totyears;
  int callocerror, callocsize, elementsize;

  float *out_1, *invert_1;
 
  int i, j, kk, array_length;
  float ncfill = 9.9692099683868690e+36;

  if(argc < 2){
    printf("  This program calculate invert values from collective I/O output\n");
    printf("  usage example: pIO_invert outfile1 valid_segments.txt\n");
    printf("  the output outfile1_x is a reformated data (maps).\n");
    return 0;
  }

  strcpy(filename, argv[1]);
  if((fpInGrid = fopen(filename, "rb")) == NULL){
    printf("can not open input binary data\n");
    return 0;
  }

  strcpy(filename2, filename);
  strcat(filename2, "_x");

  strcpy(file_list, argv[2]);
  if((fpx = fopen(file_list, "rt")) == NULL){
    printf("can not open segment list\n");
    return 0;
  }


  fscanf(fpx, "%d", &nlatsubs); 
  fscanf(fpx, "%d", &nlonsubs);
  fscanf(fpx, "%d", &npoi);
  fscanf(fpx, "%d", &valid_segment);
  fscanf(fpx, "%d", &totyears);

  mapSsize = nlatsubs * nlonsubs;
  total_segment = mapSsize/npoi;

  callocerror = 0;
  callocsize = sizeof(float);
  elementsize = sizeof(float);

  arraylength = npoi*valid_segment*totyears;
  if((out_1 = calloc(arraylength,callocsize)) == NULL)
    printf("can not alloc memory for out_1\n");

  arraylength = npoi*total_segment*totyears;
  if((invert_1 = calloc(arraylength,callocsize)) == NULL)
    printf("can not alloc memory for invert_1\n");

////
  int valid_segment_id, segment_id, start_loc, layerx, remx;
  int tmp_int;
  float tmp_float;

    for(i=0;i<mapSsize*totyears;i++){
      invert_1[i] = ncfill;
    }

    valid_segment_id = -1;
    for(segment_id=0; segment_id<total_segment; segment_id++){
      fscanf(fpx, "%d", &tmp_int);//this is valid_segment_npoi[segment_id]
      //if(valid_segment_npoi[segment_id] == 0){
      if(tmp_int == 0){
        continue;
      }
      valid_segment_id = valid_segment_id + 1;

      start_loc = segment_id*npoi;
      j = valid_segment_id*npoi*totyears;

      for(i=0;i<npoi*totyears;i++){
        fread(&tmp_float, elementsize, 1, fpInGrid);//e.g. biomass
        out_1[j] = tmp_float;

        layerx = i/npoi;
        remx = i%npoi;
        kk = start_loc + remx + layerx*mapSsize;

        invert_1[kk] = out_1[j];
        j = j + 1;
      }
    }
    printf("finished invert\n");

    array_length = mapSsize * totyears;

    writeDat(invert_1, filename2, array_length, 4);

////


  return 0;
}

////////////////////////////////////////////////

void writeDat(float *var4, char *targetfile, int array_length, int elementsize){
      FILE *fTargetFile;
      if((fTargetFile=fopen(targetfile,"wb")) == NULL){
        printf("Error opening target DAT file\n");
        return;
      }
      fwrite(var4, elementsize, array_length, fTargetFile);
      fclose(fTargetFile);
}







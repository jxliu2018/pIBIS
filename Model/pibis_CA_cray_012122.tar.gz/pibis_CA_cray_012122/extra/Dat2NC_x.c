//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h> 

#include "netcdf.h"
#define arr_size1 20
#define arr_size2 200
/*
#define NC_BYTE 1
#define NC_CHAR 2
#define NC_SHORT 3
#define NC_INT 4
#define NC_FLOAT 5
#define NC_DOUBLE 6
*/
#pragma hdrstop

//---------------------------------------------------------------------------

#pragma argsused
  char * ncfilename;
  int ndims;

  char dim_name[arr_size1][arr_size2], notes[arr_size2];
  int var_id;
  int var_natts[arr_size1];
  nc_type var_type, nctype;

  char att_txt[arr_size1][arr_size1][arr_size2];
  char att_names[arr_size1][arr_size1][arr_size2];
  nc_type att_type[arr_size1][arr_size1];
  double att_val[arr_size1][arr_size1];
  int *dim1,*dim2,*dim3,*dim4;

  int ncvar_dimids[4];

  char sourcefile[arr_size2], targetfile[arr_size2], variablenamet[arr_size2];

void CreateNCFile(char *ncfilename, char dim_names[][arr_size2], size_t *start, size_t *count, int *dim_data[]);
void CreateNCVar(char *ncfilename, char *ncvarname, nc_type nctype, int ndims, char ncvar_dimnames[][arr_size2]);
void WriteNCVara(char *ncfilename, char *ncvarname, nc_type nctype, size_t *start, size_t *count, void *tp);

int main(int argc, char* argv[])
{
    int *dim_data[4];
    size_t start[4];
    size_t count[4];
    int i, j, k, l;
    char buffer[arr_size2];
    unsigned int array_length;
    int elementsize;
    FILE *stream;
    float scale_factor, add_offset;

    int snorth, ssouth, swest, seast, row_samp, col_samp; //from ibis.infile
 
    FILE *fpx, *fpy;
    char msg[200], S[200];

    if(argc < 2){
      printf("\nThis program converts binary dat file to netcdf file.\n");
      printf("Usage: a.out ibis.infile sourcefile varname targetfile\n");
      return 0;
    }

    strcpy(sourcefile, argv[2]);
    strcpy(variablenamet, argv[3]);
    strcpy(targetfile, argv[4]);

    if ((stream = fopen(sourcefile, "rb"))== NULL){
      printf("can not open input dat file\n");
      return;
    }

    if((fpx = fopen(argv[1], "rt")) == NULL){
      printf("\n Error openning nc_shape.txt.\n");
      return 0;
    }
    strcpy(dim_name[0], "time");
    strcpy(dim_name[1], "level");
    strcpy(dim_name[2], "latitude");
    strcpy(dim_name[3], "longitude");
    ndims = 4;
    var_type = 5;
    scale_factor = 1.0;
    add_offset = 0.0;
    strcpy(notes, "universal dat2nc");

    if((fpy = fopen(argv[1], "rt")) == NULL){
      printf("\n Error openning ibis.infile.\n");
      return 0;
    }
    for(i=0;i<2;i++){
      fgets(msg, 200, fpy);//skip 2 lines in ibis.infile
    }
    fscanf(fpy, "%s", S);
    fgets(msg, 200, fpy);
    count[0] = atoi(S);

    for(i=0;i<17;i++){
      fgets(msg, 200, fpy);//skip another 17 lines in ibis.infile
    }

    fscanf(fpy, "%s", S);
    fgets(msg, 200, fpy);
    snorth = atof(S);

    fscanf(fpy, "%s", S);
    fgets(msg, 200, fpy);
    ssouth = atof(S);

    fscanf(fpy, "%s", S);
    fgets(msg, 200, fpy);
    swest = atof(S);

    fscanf(fpy, "%s", S);
    fgets(msg, 200, fpy);
    seast = atof(S);

    fscanf(fpy, "%s", S);
    fgets(msg, 200, fpy);
    row_samp = atof(S);

    fscanf(fpy, "%s", S);
    fgets(msg, 200, fpy);
    col_samp = atof(S);

    count[1] = 1;
    count[2] = (ssouth-snorth)/row_samp + 1;
    count[3] = (seast-swest)/col_samp + 1;

    start[0] = 0;
    start[1] = 0;
    start[2] = 0;
    start[3] = 0;
    array_length = count[0]*count[1]*count[2]*count[3];

    dim1 = NULL;
    dim2 = NULL;
    dim3 = NULL;
    dim4 = NULL;
    dim1 = (int *)malloc(sizeof(int) * count[0]);
    dim2 = (int *)malloc(sizeof(int) * count[1]);
    dim3 = (int *)malloc(sizeof(int) * count[2]);
    dim4 = (int *)malloc(sizeof(int) * count[3]);

    dim4[0]= 1;
    for(i=1;i<count[3];i++){
      dim4[i]=dim4[i-1]+1;
    }
    dim3[0]= count[2];
    for(i=1;i<count[2];i++){
      dim3[i]=dim3[i-1]-1;
    }
    dim2[0]= 1;
    for(i=1;i<count[1];i++){
      dim2[i]=dim2[i-1]+1;
    }
    dim1[0]= 1;
    for(i=1;i<count[0];i++){
      dim1[i]=dim1[i-1]+1;
    }

    dim_data[0] = dim1;
    dim_data[1] = dim2;
    dim_data[2] = dim3;
    dim_data[3] = dim4;

    CreateNCFile(targetfile, dim_name, start, count, dim_data);
    CreateNCVar(targetfile, variablenamet, var_type, ndims, dim_name);

    //if ((stream = fopen(sourcefile, "rb"))== NULL){
    //  printf("can not open input dat file\n");
    //}
    if(var_type == 1) {//byte data type is signed-char or unsigned-char
      elementsize = sizeof(unsigned char);
      unsigned char *yArray = (unsigned char *) malloc(array_length * elementsize);
      fread(yArray, elementsize, array_length, stream);
      WriteNCVara(targetfile, variablenamet, var_type, start, count, yArray);
      free(yArray);
    }
    if(var_type == 2) {
      elementsize = sizeof(signed char);
      signed char *yArray = (signed char *) malloc(array_length * elementsize);
      fread(yArray, elementsize, array_length, stream);
      WriteNCVara(targetfile, variablenamet, var_type, start, count, yArray);
      free(yArray);
    }
    if(var_type == 3) {
      elementsize = sizeof(short);
      short *yArray = (short *) malloc(array_length * elementsize);
      fread(yArray, elementsize, array_length, stream);
      WriteNCVara(targetfile, variablenamet, var_type, start, count, yArray);
      free(yArray);
    }
    if(var_type == 4) {
      elementsize = sizeof(int);
      int *yArray = (int *) malloc(array_length * elementsize);
      fread(yArray, elementsize, array_length, stream);
      WriteNCVara(targetfile, variablenamet, var_type, start, count, yArray);
      free(yArray);
    }
    if(var_type== 5) {
      elementsize = sizeof(float);
      float *yArray = (float *) malloc(array_length * elementsize);
      fread(yArray, elementsize, array_length, stream);
      WriteNCVara(targetfile, variablenamet, var_type, start, count, yArray);
      free(yArray);
    }
    if(var_type== 6) {
      elementsize = sizeof(double);
      double *yArray = (double *) malloc(array_length * elementsize);
      fread(yArray, elementsize, array_length, stream);
      WriteNCVara(targetfile, variablenamet, var_type, start, count, yArray);
      free(yArray);
    }

    printf("finished conversion! \n");
 
    return 0;
}
//---------------------------------------------------------------------------
void CreateNCFile(char *ncfilename, char dim_names[][arr_size2], size_t *start, size_t *count, int *dim_data[])
{
  int tmp_nc_id;
  int time_dimid, level_dimid, lat_dimid, lon_dimid, jfd_dimid;
  int time_id, level_id, lat_id, lon_id, jfd_id;
  int ndim = 0, ndim_id[5];
  int dim_id[4];
  int status, tmp_dim_id;
  int i;
  char buffer[arr_size2];
  for(i=0; i<4; i++){
    if(dim_name[i] != "") ndim++;
  }
  strcpy(buffer, "rm ");
  strcat(buffer, ncfilename);
  system(buffer);

    nc_create(ncfilename,NC_CLOBBER,&tmp_nc_id);
    for(i=0; i<ndim; i++){
      nc_def_dim(tmp_nc_id, dim_names[i], count[i], &ndim_id[i]);
      nc_def_var(tmp_nc_id, dim_names[i], NC_INT, 1, &ndim_id[i], &dim_id[i]);
    }
    nc_enddef(tmp_nc_id);

    for(i=0; i<ndim; i++){
      nc_put_var_int(tmp_nc_id,dim_id[i],dim_data[i]);
    }

  nc_close(tmp_nc_id);
}
//---------------------------------------------------------------------------
void CreateNCVar(char *ncfilename, char *ncvarname, nc_type nctype,
                         int ndims, char ncvar_dimnames[][arr_size2])
{
  int tmp_nc_id;
  int tmp_var_id;
  int i,j;
  int str_length;

  nc_open(ncfilename,NC_WRITE,&tmp_nc_id);
  for(i=0; i<ndims; i++){
    int status = nc_inq_dimid(tmp_nc_id, ncvar_dimnames[i], &ncvar_dimids[i]);
  }
  nc_redef(tmp_nc_id);
  nc_def_var(tmp_nc_id, ncvarname, nctype, ndims, ncvar_dimids, &tmp_var_id);

  for(j=0;j<var_natts[var_id];j++){
    if(att_type[var_id][j] == NC_CHAR){
      str_length = strlen(att_txt[var_id][j]);
      nc_put_att_text(tmp_nc_id, tmp_var_id, att_names[var_id][j], str_length, att_txt[var_id][j]);
    }
    else{
      nc_put_att_double(tmp_nc_id, tmp_var_id, att_names[var_id][j], NC_DOUBLE, 1, &att_val[var_id][j]);
    }
  }

  double att_val_tmp;
  att_val_tmp = 1.0;
  nc_put_att_double(tmp_nc_id, tmp_var_id, "scale_factor", NC_DOUBLE, 1, &att_val_tmp);
  att_val_tmp = 0.0;
  nc_put_att_double(tmp_nc_id, tmp_var_id, "add_offset", NC_DOUBLE, 1, &att_val_tmp);
  //nc_put_att_text(tmp_nc_id, tmp_var_id, "notes", 200, &notes[0]);
  nc_put_att_text(tmp_nc_id, NC_GLOBAL, "title", 200, &notes[0]);
  nc_enddef(tmp_nc_id);
  nc_close(tmp_nc_id);
}
//---------------------------------------------------------------------------
void WriteNCVara(char *ncfilename, char *ncvarname, nc_type nctype, size_t *start, size_t *count, void *tp)
{
  int tmp_nc_id, tmp_var_id;
  nc_type xtype;

  nc_open(ncfilename,NC_NOWRITE,&tmp_nc_id);
  nc_inq_varid(tmp_nc_id, ncvarname, &tmp_var_id);
  nc_inq_vartype(tmp_nc_id, tmp_var_id, &xtype);
  nc_close(tmp_nc_id);

  nc_open(ncfilename,NC_WRITE,&tmp_nc_id);

  if(xtype == NC_BYTE && nctype == 1){
    unsigned char * tpp = (unsigned char *) tp;
    nc_put_vara_uchar(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_BYTE && nctype == 2){ //add this for animating signed char data
    const signed char * tpp = (const signed char *) tp;
    nc_put_vara_schar(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_CHAR){//this char data can not be animated with its 'char nc type'
    const signed char * tpp = (const signed char *) tp;
    nc_put_vara_schar(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_SHORT){
    short * tpp = (short *) tp;
    nc_put_vara_short(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_INT){
    int * tpp = (int *) tp;
    nc_put_vara_int(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_FLOAT){
    float * tpp = (float *) tp;
    nc_put_vara_float(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else if(xtype == NC_DOUBLE){
    double * tpp = (double *) tp;
    nc_put_vara_double(tmp_nc_id, tmp_var_id, start, count, tpp);
  }
  else{
    printf("Wrong data type (not a nc_type 1~6)");
  }
  nc_close(tmp_nc_id);
}

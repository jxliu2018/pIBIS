rm *.o
rm outfile*
rm *.dat
rm *.nc

rm sum_*txt*
rm p_list_extract*
rm p_list_sum_all.asc
rm p_list_xy_slope*
rm p_list_avg_std*
rm p_list_*_sensitivity.asc
rm p_list_sum_all_*.asc
rm *_temp.txt

rm go_0.sh
rm veg_sum_0.sh

ls -lrt


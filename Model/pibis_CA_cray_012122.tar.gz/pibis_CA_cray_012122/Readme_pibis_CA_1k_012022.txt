-- Only brief steps here. For questions, you can reach me via jxliu@usgs.gov --

Parallel IBIS simulation
Machine         ALCF/Theta
sim date        011822
codebase        pibis_CA_local_011522.tar.gz, modified to 1km (in ibis.infile), npoi=20
new updates     none
C code last     121622
Fortran last    120122
                012221: ibislib.f
                        ibis.infile (only for ibislib.f 012221):
                        isimco2 = 0 fixed co2, spatial 
                        isimco2 = 1 ramp co2 spatial
                        isimco2 = 2 ramp co2 non-spatial
                        isimco2 = 3 ramp co2 spatial, ndep1
                        isimco2 = 1970 ramp co2 1971 spatial
                        isimco2 = 26 ramp co2 spatial, rcp2.6
                        isimco2 = 45 ramp co2 spatial, rcp4.5
                        isimco2 = 85 ramp co2 spatial, rcp8.5

geo scope       CA 1-1200 row, 1-740 col
sampling        1X (1-km), 
iyranom         1971, use of climate anom data
nanom           45, anom data read in but not used  
isimveg         1, start mode dynamic vegetation turned on
isimfire        1984 fire start year
isimlcc         1971, lcc start year
isimco2         1, ramped CO2
idiag           1969, biomass reset year
Ndep            isimco2=3, use static ndep, if isimco2=1, dynamic 
GHG             CH4

calibration     skipped! only used previous local 37X calibration for testing 

Step-by-step
                ssh -Y jxliu@theta.alcf.anl.gov
                cd /lus/theta-fs0/projects/CONUS-Carbon/pibis_CA
		module swap PrgEnv-intel PrgEnv-cray
		module load cray-netcdf
		module load cray-parallel-netcdf
		module load cray-fftw
		(Theta default to static linking, so use -static to link)

                cd /lus/theta-fs0/projects/CONUS-Carbon/pibis_CA/ibis
                compile_crayftn_savebin.rc (this will compile and build the libibis.a)

                cd /lus/theta-fs0/projects/CONUS-Carbon/pibis_CA/
                make_pibis_p001_cray.rc
                make_pibis_p000_cray.rc
                make_pibis_p_cray.rc

                (sub_region_N_blocks_segment_comp_dyn_cray p_list_tmp.asc 50 CONUS-Carbon)
                submit_all_cary.sh
                run_invert.40_cray.sh
                run_Dat2NC_x_40_cray.sh
                run_merge.40_cray.sh
                run_ecosum_CA_1k_all.sh

Note: This is only an example to show the command line process. The scalers/scalars are actually
      not good because they were derived from 37km X 37km smapling simulations. Better scalers
      should use 1km to 5km simulations. Calibration process are described in pibis_CA_local code.
Note: Some post-processing codes are in "extra" and "c_code" folders. Local laptop built programs
      can also run on Theta because I have locally installed NetCDF 4.2.11 under my home folder
      on Theta.



rm -rf ../xibis*
sub_region_N_blocks_segment_comp_dyn_cray p_list_tmp.asc 50 CONUS-Carbon

cd ../xibis1
pibis_p000_cray
chmod 774 myscript_cray.sh
sleep 5

cd ../xibis2
pibis_p000_cray
chmod 774 myscript_cray.sh
sleep 5

cd ../xibis1
qsub myscript_cray.sh

cd ../xibis2
qsub myscript_cray.sh

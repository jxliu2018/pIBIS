cp -p ./stats/tools_1/go .
cp -p ./stats/tools_1/fipsum_ibis .
cp -p ./stats/tools_1/sum_all_10000 .
cp -p ./stats/tools_1/extract_original_mask .
cp -p ./stats/tools_1/run_ecosum_CA_local_*_115yr.sh .
cp -p ./stats/tools_1/p_list_*.asc .

run_ecosum_CA_local_fu0010_115yr.sh
sleep 5s
run_ecosum_CA_local_covmax1_115yr.sh
sleep 5s
run_ecosum_CA_local_covmax2_115yr.sh
sleep 5s
run_ecosum_CA_local_covmax3_115yr.sh
sleep 5s
run_ecosum_CA_local_covmax4_115yr.sh
sleep 5s
run_ecosum_CA_local_covmax5_115yr.sh
sleep 5s
run_ecosum_CA_local_covmax6_115yr.sh
sleep 5s
run_ecosum_CA_local_vegtype1-8-1_115yr.sh
sleep 5s
run_ecosum_CA_local_vegtype1-8+1_115yr.sh
sleep 5s
run_ecosum_CA_local_vegtype1-16-1_115yr.sh

mkdir ecoreg_sum
mv sum_*gz ecoreg_sum


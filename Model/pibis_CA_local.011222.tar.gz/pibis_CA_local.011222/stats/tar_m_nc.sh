echo 1
tar czf fips_m.nc.tar.gz fips_m.nc
echo 2
tar czf ecoreg_m.nc.tar.gz ecoreg_m.nc
echo 3
tar czf xcovmax_m.nc.tar.gz xcovmax_m.nc
echo 4
tar czf fu_m.nc.tar.gz fu_m.nc
echo 5
tar czf vegtype0_m.nc.tar.gz vegtype0_m.nc
echo 6
tar czf cbiotot_m.nc.tar.gz cbiotot_m.nc
echo 7
tar czf totbiou_m.nc.tar.gz totbiou_m.nc
echo 8
tar czf totcsoi_m.nc.tar.gz totcsoi_m.nc
echo 9
tar czf stddown_m.nc.tar.gz stddown_m.nc
echo 10
tar czf cgrain_m.nc.tar.gz cgrain_m.nc
echo 11
tar czf aynpptot_m.nc.tar.gz aynpptot_m.nc
echo 12
tar czf totlit_m.nc.tar.gz totlit_m.nc
echo 13
tar czf ayneetot_m.nc.tar.gz ayneetot_m.nc
echo 14
tar czf aynbp_m.nc.tar.gz aynbp_m.nc
echo 15
tar czf ayCH4_m.nc.tar.gz ayCH4_m.nc
echo 16
tar czf ayn2oflux_m.nc.tar.gz ayn2oflux_m.nc
echo 17
tar czf gdd5this_m.nc.tar.gz gdd5this_m.nc
echo 18
tar czf ayprcp_m.nc.tar.gz ayprcp_m.nc
echo 19
tar czf totceco_m.nc.tar.gz totceco_m.nc
echo 20
tar czf yrleach_m.nc.tar.gz yrleach_m.nc
echo 21
tar czf xdist_m.nc.tar.gz xdist_m.nc
echo 22
tar czf logging_m.nc.tar.gz logging_m.nc
echo 23
tar czf soilcomb_m.nc.tar.gz soilcomb_m.nc
echo 24
tar czf vegcomb_m.nc.tar.gz vegcomb_m.nc
echo 25
tar czf strawc_m.nc.tar.gz strawc_m.nc
echo 26
tar czf deadcrem_m.nc.tar.gz deadcrem_m.nc
echo 27
tar czf livecrem_m.nc.tar.gz livecrem_m.nc
echo 28
tar czf cdisturb_m.nc.tar.gz cdisturb_m.nc
echo 29
tar czf totwdl_m.nc.tar.gz totwdl_m.nc
echo 30
tar czf stdwdc_m.nc.tar.gz stdwdc_m.nc
echo 31
tar czf rawlitc_m.nc.tar.gz rawlitc_m.nc
echo 32
tar czf fallw_m.nc.tar.gz fallw_m.nc
echo 33
tar czf livc2std_m.nc.tar.gz livc2std_m.nc
echo 34
tar czf livc2down_m.nc.tar.gz livc2down_m.nc
echo 35
tar czf stdwcloss_m.nc.tar.gz stdwcloss_m.nc
echo 36
tar czf down2lit_m.nc.tar.gz down2lit_m.nc
echo 37
tar czf lit2co2_m.nc.tar.gz lit2co2_m.nc
echo 38
tar czf lit2soc_m.nc.tar.gz lit2soc_m.nc
echo 39
tar czf soc2co2_m.nc.tar.gz soc2co2_m.nc
echo 40
tar czf raw2lit_m.nc.tar.gz raw2lit_m.nc

mkdir m_nc
mv *_m.nc.tar.gz m_nc


extract_original_ending_mask p_list_extract_mask1-9+1.asc
fipsum_ibis aynpptot_m.nc aynpptot veg_mask1-9+1.dat float 33 20 1 115 fu.dat 0.0 1.0 
fipsum_ibis ayneetot_m.nc ayneetot veg_mask1-9+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis aynbp_m.nc aynbp veg_mask1-9+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis lit2co2_m.nc lit2co2 veg_mask1-9+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis soc2co2_m.nc soc2co2 veg_mask1-9+1.dat float 33 20 1 115 fu.dat 0.0 1.0
mv sum_aynpptot_m.nc.txt sum_aynpptot_m.nc.txt.1-9+1
mv sum_ayneetot_m.nc.txt sum_ayneetot_m.nc.txt.1-9+1
mv sum_aynbp_m.nc.txt sum_aynbp_m.nc.txt.1-9+1
mv sum_lit2co2_m.nc.txt sum_lit2co2_m.nc.txt.1-9+1
mv sum_soc2co2_m.nc.txt sum_soc2co2_m.nc.txt.1-9+1

extract_original_ending_mask p_list_extract_mask10-10+1.asc
fipsum_ibis aynpptot_m.nc aynpptot veg_mask10-10+1.dat float 33 20 1 115 fu.dat 0.0 1.0 
fipsum_ibis ayneetot_m.nc ayneetot veg_mask10-10+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis aynbp_m.nc aynbp veg_mask10-10+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis lit2co2_m.nc lit2co2 veg_mask1-10+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis soc2co2_m.nc soc2co2 veg_mask1-10+1.dat float 33 20 1 115 fu.dat 0.0 1.0
mv sum_aynpptot_m.nc.txt sum_aynpptot_m.nc.txt.10-10+1
mv sum_ayneetot_m.nc.txt sum_ayneetot_m.nc.txt.10-10+1
mv sum_aynbp_m.nc.txt sum_aynbp_m.nc.txt.10-10+1
mv sum_lit2co2_m.nc.txt sum_lit2co2_m.nc.txt.10-10+1
mv sum_soc2co2_m.nc.txt sum_soc2co2_m.nc.txt.10-10+1

extract_original_ending_mask p_list_extract_mask11-12+1.asc
fipsum_ibis aynpptot_m.nc aynpptot veg_mask11-12+1.dat float 33 20 1 115 fu.dat 0.0 1.0 
fipsum_ibis ayneetot_m.nc ayneetot veg_mask11-12+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis aynbp_m.nc aynbp veg_mask11-12+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis lit2co2_m.nc lit2co2 veg_mask11-12+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis soc2co2_m.nc soc2co2 veg_mask11-12+1.dat float 33 20 1 115 fu.dat 0.0 1.0
mv sum_aynpptot_m.nc.txt sum_aynpptot_m.nc.txt.11-12+1
mv sum_ayneetot_m.nc.txt sum_ayneetot_m.nc.txt.11-12+1
mv sum_aynbp_m.nc.txt sum_aynbp_m.nc.txt.11-12+1
mv sum_lit2co2_m.nc.txt sum_lit2co2_m.nc.txt.11-12+1
mv sum_soc2co2_m.nc.txt sum_soc2co2_m.nc.txt.11-12+1

extract_original_ending_mask p_list_extract_mask10-12+1.asc
fipsum_ibis aynpptot_m.nc aynpptot veg_mask10-12+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis ayneetot_m.nc ayneetot veg_mask10-12+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis aynbp_m.nc aynbp veg_mask10-12+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis lit2co2_m.nc lit2co2 veg_mask10-12+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis soc2co2_m.nc soc2co2 veg_mask10-12+1.dat float 33 20 1 115 fu.dat 0.0 1.0
mv sum_aynpptot_m.nc.txt sum_aynpptot_m.nc.txt.10-12+1
mv sum_ayneetot_m.nc.txt sum_ayneetot_m.nc.txt.10-12+1
mv sum_aynbp_m.nc.txt sum_aynbp_m.nc.txt.10-12+1
mv sum_lit2co2_m.nc.txt sum_lit2co2_m.nc.txt.10-12+1
mv sum_soc2co2_m.nc.txt sum_soc2co2_m.nc.txt.10-12+1

extract_original_ending_mask p_list_extract_mask13-15+1.asc
fipsum_ibis aynpptot_m.nc aynpptot veg_mask13-15+1.dat float 33 20 1 115 fu.dat 0.0 1.0 
fipsum_ibis ayneetot_m.nc ayneetot veg_mask13-15+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis aynbp_m.nc aynbp veg_mask13-15+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis lit2co2_m.nc lit2co2 veg_mask13-15+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis soc2co2_m.nc soc2co2 veg_mask13-15+1.dat float 33 20 1 115 fu.dat 0.0 1.0
mv sum_aynpptot_m.nc.txt sum_aynpptot_m.nc.txt.13-15+1
mv sum_ayneetot_m.nc.txt sum_ayneetot_m.nc.txt.13-15+1
mv sum_aynbp_m.nc.txt sum_aynbp_m.nc.txt.13-15+1
mv sum_lit2co2_m.nc.txt sum_lit2co2_m.nc.txt.13-15+1
mv sum_soc2co2_m.nc.txt sum_soc2co2_m.nc.txt.13-15+1

extract_original_ending_mask p_list_extract_mask16-16+1.asc
fipsum_ibis aynpptot_m.nc aynpptot veg_mask16-16+1.dat float 33 20 1 115 fu.dat 0.0 1.0 
fipsum_ibis ayneetot_m.nc ayneetot veg_mask16-16+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis aynbp_m.nc aynbp veg_mask16-16+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis lit2co2_m.nc lit2co2 veg_mask16-16+1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis soc2co2_m.nc soc2co2 veg_mask16-16+1.dat float 33 20 1 115 fu.dat 0.0 1.0
mv sum_aynpptot_m.nc.txt sum_aynpptot_m.nc.txt.16-16+1
mv sum_ayneetot_m.nc.txt sum_ayneetot_m.nc.txt.16-16+1
mv sum_aynbp_m.nc.txt sum_aynbp_m.nc.txt.16-16+1
mv sum_lit2co2_m.nc.txt sum_lit2co2_m.nc.txt.16-16+1
mv sum_soc2co2_m.nc.txt sum_soc2co2_m.nc.txt.16-16+1

extract_original_ending_mask p_list_extract_mask1-9-1.asc
fipsum_ibis aynpptot_m.nc aynpptot veg_mask1-9-1.dat float 33 20 1 115 fu.dat 0.0 1.0 
fipsum_ibis ayneetot_m.nc ayneetot veg_mask1-9-1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis aynbp_m.nc aynbp veg_mask1-9-1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis lit2co2_m.nc lit2co2 veg_mask1-9-1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis soc2co2_m.nc soc2co2 veg_mask1-9-1.dat float 33 20 1 115 fu.dat 0.0 1.0
mv sum_aynpptot_m.nc.txt sum_aynpptot_m.nc.txt.1-9-1
mv sum_ayneetot_m.nc.txt sum_ayneetot_m.nc.txt.1-9-1
mv sum_aynbp_m.nc.txt sum_aynbp_m.nc.txt.1-9-1
mv sum_lit2co2_m.nc.txt sum_lit2co2_m.nc.txt.1-9-1
mv sum_soc2co2_m.nc.txt sum_soc2co2_m.nc.txt.1-9-1

extract_original_ending_mask p_list_extract_mask1-16-1.asc
fipsum_ibis aynpptot_m.nc aynpptot veg_mask1-16-1.dat float 33 20 1 115 fu.dat 0.0 1.0 
fipsum_ibis ayneetot_m.nc ayneetot veg_mask1-16-1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis aynbp_m.nc aynbp veg_mask1-16-1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis lit2co2_m.nc lit2co2 veg_mask1-16-1.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis soc2co2_m.nc soc2co2 veg_mask1-16-1.dat float 33 20 1 115 fu.dat 0.0 1.0
mv sum_aynpptot_m.nc.txt sum_aynpptot_m.nc.txt.1-16-1
mv sum_ayneetot_m.nc.txt sum_ayneetot_m.nc.txt.1-16-1
mv sum_aynbp_m.nc.txt sum_aynbp_m.nc.txt.1-16-1
mv sum_lit2co2_m.nc.txt sum_lit2co2_m.nc.txt.1-16-1
mv sum_soc2co2_m.nc.txt sum_soc2co2_m.nc.txt.1-16-1

Dat2NC_x ibis.infile.dat2nc veg_mask1-9+1.dat veg_mask veg_mask1-9+1.nc
Dat2NC_x ibis.infile.dat2nc veg_mask10-10+1.dat veg_mask veg_mask10-10+1.nc
Dat2NC_x ibis.infile.dat2nc veg_mask11-12+1.dat veg_mask veg_mask11-12+1.nc
Dat2NC_x ibis.infile.dat2nc veg_mask10-12+1.dat veg_mask veg_mask10-12+1.nc
Dat2NC_x ibis.infile.dat2nc veg_mask13-15+1.dat veg_mask veg_mask13-15+1.nc
Dat2NC_x ibis.infile.dat2nc veg_mask16-16+1.dat veg_mask veg_mask16-16+1.nc
Dat2NC_x ibis.infile.dat2nc veg_mask1-9-1.dat veg_mask veg_mask1-9-1.nc
Dat2NC_x ibis.infile.dat2nc veg_mask1-16-1.dat veg_mask veg_mask1-16-1.nc

extract_original_mask p_list_extract_mask1-9-1x.asc
fipsum_ibis aynpptot_m.nc aynpptot veg_mask1-9-1x.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis ayneetot_m.nc ayneetot veg_mask1-9-1x.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis aynbp_m.nc aynbp veg_mask1-9-1x.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis lit2co2_m.nc lit2co2 veg_mask1-9-1x.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis soc2co2_m.nc soc2co2 veg_mask1-9-1x.dat float 33 20 1 115 fu.dat 0.0 1.0
mv sum_aynpptot_m.nc.txt sum_aynpptot_m.nc.txt.1-9-1x
mv sum_ayneetot_m.nc.txt sum_ayneetot_m.nc.txt.1-9-1x
mv sum_aynbp_m.nc.txt sum_aynbp_m.nc.txt.1-9-1x
mv sum_lit2co2_m.nc.txt sum_lit2co2_m.nc.txt.1-9-1x
mv sum_soc2co2_m.nc.txt sum_soc2co2_m.nc.txt.1-9-1x

extract_original_mask p_list_extract_mask1-16-1x.asc
fipsum_ibis aynpptot_m.nc aynpptot veg_mask1-16-1x.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis ayneetot_m.nc ayneetot veg_mask1-16-1x.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis aynbp_m.nc aynbp veg_mask1-16-1x.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis lit2co2_m.nc lit2co2 veg_mask1-16-1x.dat float 33 20 1 115 fu.dat 0.0 1.0
fipsum_ibis soc2co2_m.nc soc2co2 veg_mask1-16-1x.dat float 33 20 1 115 fu.dat 0.0 1.0
mv sum_aynpptot_m.nc.txt sum_aynpptot_m.nc.txt.1-16-1x
mv sum_ayneetot_m.nc.txt sum_ayneetot_m.nc.txt.1-16-1x
mv sum_aynbp_m.nc.txt sum_aynbp_m.nc.txt.1-16-1x
mv sum_lit2co2_m.nc.txt sum_lit2co2_m.nc.txt.1-16-1x
mv sum_soc2co2_m.nc.txt sum_soc2co2_m.nc.txt.1-16-1x

Dat2NC_x ibis.infile.dat2nc veg_mask1-9-1x.dat veg_mask veg_mask1-9-1x.nc
Dat2NC_x ibis.infile.dat2nc veg_mask1-16-1x.dat veg_mask veg_mask1-16-1x.nc


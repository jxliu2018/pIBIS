tar -xzf fu_m.nc.tar.gz
tar -xzf aynbp_m.nc.tar.gz
tar -xzf ayneetot_m.nc.tar.gz
tar -xzf aynpptot_m.nc.tar.gz
tar -xzf vegtype0_m.nc.tar.gz
tar -xzf lit2co2_m.nc.tar.gz
tar -xzf soc2co2_m.nc.tar.gz

go fu_m.nc fu fu.dat
go aynbp_m.nc aynbp aynbp_m.dat
go ayneetot_m.nc ayneetot ayneetot_m.dat
go aynpptot_m.nc aynpptot aynpptot_m.dat
go vegtype0_m.nc vegtype0 vegtype0_m.dat
go lit2co2_m.nc lit2co2 lit2co2_m.dat
go soc2co2_m.nc soc2co2 soc2co2_m.dat


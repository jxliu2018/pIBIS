#!/bin/bash
sleep_time1=10s
block=1
while [ $block -le 9 ]; do
            echo current block: $block
            if [ $block -gt 9 ]; then
               break          # all blocks allocated.
            fi
            cp -p ./Dat2NC_x ../xibis$block/Dat2NC_x
            cd ../xibis$block
# corresponding to ibislib.f yearly outputp1~outputp40
# 1~11
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/fips.dat fips ../xibis$block/fips.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/ecoreg.dat ecoreg ../xibis$block/ecoreg.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/xcovmax.dat xcovmax ../xibis$block/xcovmax.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/fu.dat fu ../xibis$block/fu.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/cbiotot.dat cbiotot ../xibis$block/cbiotot.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/totbiou.dat totbiou ../xibis$block/totbiou.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/totcsoi.dat totcsoi ../xibis$block/totcsoi.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/stddown.dat stddown ../xibis$block/stddown.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/cgrain.dat cgrain ../xibis$block/cgrain.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/vegtype0.dat vegtype0 ../xibis$block/vegtype0.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/aynpptot.dat aynpptot ../xibis$block/aynpptot.nc > /dev/null &
# 12~20
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/totlit.dat totlit ../xibis$block/totlit.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/ayneetot.dat ayneetot ../xibis$block/ayneetot.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/aynbp.dat aynbp ../xibis$block/aynbp.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/ayCH4.dat ayCH4 ../xibis$block/ayCH4.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/ayn2oflux.dat ayn2oflux ../xibis$block/ayn2oflux.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/gdd5this.dat gdd5this ../xibis$block/gdd5this.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/ayprcp.dat ayprcp ../xibis$block/ayprcp.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/totceco.dat totceco ../xibis$block/totceco.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/yrleach.dat yrleach ../xibis$block/yrleach.nc > /dev/null &
# 21~30
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/xdist.dat xdist ../xibis$block/xdist.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/logging.dat logging ../xibis$block/logging.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/soilcomb.dat soilcomb ../xibis$block/soilcomb.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/vegcomb.dat vegcomb ../xibis$block/vegcomb.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/strawc.dat strawc ../xibis$block/strawc.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/deadcrem.dat deadcrem ../xibis$block/deadcrem.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/livecrem.dat livecrem ../xibis$block/livecrem.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/cdisturb.dat cdisturb ../xibis$block/cdisturb.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/totwdl.dat totwdl ../xibis$block/totwdl.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/stdwdc.dat stdwdc ../xibis$block/stdwdc.nc > /dev/null &
# 31~40
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/rawlitc.dat rawlitc ../xibis$block/rawlitc.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/fallw.dat fallw ../xibis$block/fallw.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/livc2std.dat livc2std ../xibis$block/livc2std.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/livc2down.dat livc2down ../xibis$block/livc2down.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/stdwcloss.dat stdwcloss ../xibis$block/stdwcloss.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/down2lit.dat down2lit ../xibis$block/down2lit.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/lit2co2.dat lit2co2 ../xibis$block/lit2co2.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/lit2soc.dat lit2soc ../xibis$block/lit2soc.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/soc2co2.dat soc2co2 ../xibis$block/soc2co2.nc > /dev/null &
            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/raw2lit.dat raw2lit ../xibis$block/raw2lit.nc > /dev/null &
# others
#            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/cfruit.dat cfruit ../xibis$block/cfruit.nc > /dev/null &
#            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/csoislow.dat csoislow ../xibis$block/csoislow.nc > /dev/null &
#            Dat2NC_x ../xibis$block/ibis.infile ../xibis$block/deadwdc.dat deadwdc ../xibis$block/deadwdc.nc > /dev/null &
            sleep $sleep_time1
            let block=block+1
done
exit


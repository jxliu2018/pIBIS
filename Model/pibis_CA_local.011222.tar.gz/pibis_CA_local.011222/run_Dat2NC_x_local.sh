# 1~11
            Dat2NC_x ibis.infile fips.dat fips fips.nc 
            Dat2NC_x ibis.infile ecoreg.dat ecoreg ecoreg.nc 
            Dat2NC_x ibis.infile xcovmax.dat xcovmax xcovmax.nc 
            Dat2NC_x ibis.infile fu.dat fu fu.nc 
            Dat2NC_x ibis.infile cbiotot.dat cbiotot cbiotot.nc 
            Dat2NC_x ibis.infile totbiou.dat totbiou totbiou.nc 
            Dat2NC_x ibis.infile totcsoi.dat totcsoi totcsoi.nc 
            Dat2NC_x ibis.infile stddown.dat stddown stddown.nc 
            Dat2NC_x ibis.infile cgrain.dat cgrain cgrain.nc 
            Dat2NC_x ibis.infile vegtype0.dat vegtype0 vegtype0.nc 
            Dat2NC_x ibis.infile aynpptot.dat aynpptot aynpptot.nc 
# 12~20
            Dat2NC_x ibis.infile totlit.dat totlit totlit.nc 
            Dat2NC_x ibis.infile ayneetot.dat ayneetot ayneetot.nc 
            Dat2NC_x ibis.infile aynbp.dat aynbp aynbp.nc 
            Dat2NC_x ibis.infile ayCH4.dat ayCH4 ayCH4.nc 
            Dat2NC_x ibis.infile ayn2oflux.dat ayn2oflux ayn2oflux.nc 
            Dat2NC_x ibis.infile gdd5this.dat gdd5this gdd5this.nc 
            Dat2NC_x ibis.infile ayprcp.dat ayprcp ayprcp.nc 
            Dat2NC_x ibis.infile totceco.dat totceco totceco.nc 
            Dat2NC_x ibis.infile yrleach.dat yrleach yrleach.nc 
# 21~30
            Dat2NC_x ibis.infile xdist.dat xdist xdist.nc 
            Dat2NC_x ibis.infile logging.dat logging logging.nc 
            Dat2NC_x ibis.infile soilcomb.dat soilcomb soilcomb.nc 
            Dat2NC_x ibis.infile vegcomb.dat vegcomb vegcomb.nc 
            Dat2NC_x ibis.infile strawc.dat strawc strawc.nc 
            Dat2NC_x ibis.infile deadcrem.dat deadcrem deadcrem.nc 
            Dat2NC_x ibis.infile livecrem.dat livecrem livecrem.nc 
            Dat2NC_x ibis.infile cdisturb.dat cdisturb cdisturb.nc 
            Dat2NC_x ibis.infile totwdl.dat totwdl totwdl.nc 
            Dat2NC_x ibis.infile stdwdc.dat stdwdc stdwdc.nc 
# 31~40
            Dat2NC_x ibis.infile rawlitc.dat rawlitc rawlitc.nc 
            Dat2NC_x ibis.infile fallw.dat fallw fallw.nc 
            Dat2NC_x ibis.infile livc2std.dat livc2std livc2std.nc 
            Dat2NC_x ibis.infile livc2down.dat livc2down livc2down.nc 
            Dat2NC_x ibis.infile stdwcloss.dat stdwcloss stdwcloss.nc 
            Dat2NC_x ibis.infile down2lit.dat down2lit down2lit.nc 
            Dat2NC_x ibis.infile lit2co2.dat lit2co2 lit2co2.nc 
            Dat2NC_x ibis.infile lit2soc.dat lit2soc lit2soc.nc 
            Dat2NC_x ibis.infile soc2co2.dat soc2co2 soc2co2.nc 
            Dat2NC_x ibis.infile raw2lit.dat raw2lit raw2lit.nc 


mkdir ../xibis1/tmp
mkdir ../xibis2/tmp
mkdir ../xibis3/tmp
mkdir ../xibis4/tmp
mkdir ../xibis5/tmp
mkdir ../xibis6/tmp
mkdir ../xibis7/tmp
mkdir ../xibis8/tmp
mkdir ../xibis9/tmp

cd ../xibis1
mv global* tmp
rm *.nc
rm *.dat
rm outfile*
mv tmp/* .

cd ../xibis2
mv global* tmp
rm *.nc
rm *.dat
rm outfile*
mv tmp/* .

cd ../xibis3
mv global* tmp
rm *.nc
rm *.dat
rm outfile*
mv tmp/* .

cd ../xibis4
mv global* tmp
rm *.nc
rm *.dat
rm outfile*
mv tmp/* .

cd ../xibis5
mv global* tmp
rm *.nc
rm *.dat
rm outfile*
mv tmp/* .

cd ../xibis6
mv global* tmp
rm *.nc
rm *.dat
rm outfile*
mv tmp/* .

cd ../xibis7
mv global* tmp
rm *.nc
rm *.dat
rm outfile*
mv tmp/* .

cd ../xibis8
mv global* tmp
rm *.nc
rm *.dat
rm outfile*
mv tmp/* .

cd ../xibis9
mv global* tmp
rm *.nc
rm *.dat
rm outfile*
mv tmp/* .


~                                                                                                                                   

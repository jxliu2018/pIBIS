/*
                    _
 _ __ ___  __ _  __| |_ __   __ _ _ __ ___   ___
| '__/ _ \/ _` |/ _` | '_ \ / _` | '__/ __| / __|
| | |  __/ (_| | (_| | |_) | (_| | |  \__ \| (__
|_|  \___|\__,_|\__,_| .__/ \__,_|_|  |___(_)___|
                     |_|

*/
//readpars.c
//Jinxun Liu, recently updated 6/18/2019
//jxliu@usgs.gov

#include <stdio.h>
#include <stdlib.h>
#include "ibis_common_p.h"

void rdinfile(){
  FILE *fp1;
  char msg[200];
  int k;

  /* read ibis.infile */
  if ((fp1 = fopen("ibis.infile", "rt"))==NULL){
    fprintf(stderr,"ibis.infile not found! \n");
    return;
  }
  fscanf(fp1,"%d", &irestart);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &iyear0);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &nrun);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &iyranom);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &nanom);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &iyrdaily);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &soilcspin);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &iyearout);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &imonthout);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &idailyout);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &isimveg);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &isimfire);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &isimlcc);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &isimco2);  fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &co2init);  fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &o2init);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &dtime);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &idiag);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &cluster);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &events);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &snorth);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &ssouth);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &swest);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &seast);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &rowscale);  fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &colscale);  fgets(msg, 200, fp1);

  k=0;
  vectorp[0] = irestart;
  vectorp[1] = iyear0;
  vectorp[2] = nrun;
  vectorp[3] = iyranom;
  vectorp[4] = nanom;
  vectorp[5] = iyrdaily;
  vectorp[6] = soilcspin;
  vectorp[7] = iyearout;
  vectorp[8] = imonthout;
  vectorp[9] = idailyout;
  vectorp[10] = isimveg;
  vectorp[11] = isimfire;
  vectorp[12] = isimlcc;
  vectorp[13] = isimco2;
  vectorp[14] = co2init;
  vectorp[15] = o2init;
  vectorp[16] = dtime;
  vectorp[17] = idiag;
  vectorp[18] = cluster;
  vectorp[19] = events;
  vectorp[20] = snorth;
  vectorp[21] = ssouth;
  vectorp[22] = swest;
  vectorp[23] = seast;
  vectorp[24] = rowscale;
  vectorp[25] = colscale;
  vectorp[26] = 0; //reserved for future use
  vectorp[27] = 0; //reserved for future use
  vectorp[28] = 0; //reserved for future use
  vectorp[29] = 0; //reserved for future use
  k = k + 29; //k = 29 now

  fclose(fp1);

  totrows = ssouth - snorth + 1;
  totcols = seast - swest + 1;
}

void rdparam(){
  FILE *fp1;
  char msg[200];
  int i,j,k;
  float dummyvar;

  /* after reading ibis.infile */
  k = 29;

  /* read paramsx.can */
  if ((fp1 = fopen("paramsx.can", "rt"))==NULL){
    fprintf(stderr,"paramsx.can file not found! \n");
    return;
  }
  for(i=0; i<2; i++) fgets(msg, 200, fp1);//skip one line

  fscanf(fp1,"%f", &tau15); fgets(msg, 200, fp1);//from compft.h
  fscanf(fp1,"%f", &kc15);  fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &ko15);  fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cimax); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = tau15;
  vectorp[k+2] = kc15;
  vectorp[k+3] = ko15;
  vectorp[k+4] = cimax;

  fscanf(fp1,"%f", &alpha3); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &theta3); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &beta3);  fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &alpha4); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &theta4); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &beta4);  fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+5] = alpha3;
  vectorp[k+6] = theta3;
  vectorp[k+7] = beta3;
  vectorp[k+8] = alpha4;
  vectorp[k+9] = theta4;
  vectorp[k+10] = beta4;
  k = k + 10;

  fscanf(fp1,"%f%f%f%f", &gammaub,&coefmub,&coefbub,&gsubmin); fgets(msg, 200, fp1);
  vectorp[k+1] = gammaub;
  vectorp[k+2] = coefmub;
  vectorp[k+3] = coefbub;
  vectorp[k+4] = gsubmin;
  k = k + 4;

  fscanf(fp1,"%f%f%f%f", &gammauc,&coefmuc,&coefbuc,&gsucmin); fgets(msg, 200, fp1);
  vectorp[k+1] = gammauc;
  vectorp[k+2] = coefmuc;
  vectorp[k+3] = coefbuc;
  vectorp[k+4] = gsucmin;
  k = k + 4;

  fscanf(fp1,"%f%f%f%f", &gammals,&coefmls,&coefbls,&gslsmin); fgets(msg, 200, fp1);
  vectorp[k+1] = gammals;
  vectorp[k+2] = coefmls;
  vectorp[k+3] = coefbls;
  vectorp[k+4] = gslsmin;
  k = k + 4;

  fscanf(fp1,"%f%f%f%f", &gammal4,&coefml4,&coefbl4,&gsl4min); fgets(msg, 200, fp1);
  vectorp[k+1] = gammal4;
  vectorp[k+2] = coefml4;
  vectorp[k+3] = coefbl4;
  vectorp[k+4] = gsl4min;
  k = k + 4;

  fscanf(fp1,"%f%f%f%f", &gammal3,&coefml3,&coefbl3,&gsl3min); fgets(msg, 200, fp1);
  vectorp[k+1] = gammal3;
  vectorp[k+2] = coefml3;
  vectorp[k+3] = coefbl3;
  vectorp[k+4] = gsl3min;
  k = k + 4;

  fscanf(fp1,"%f%f%f%f", &gammac4,&coefmc4,&coefbc4,&gsc4min); fgets(msg, 200, fp1);
  vectorp[k+1] = gammac4;
  vectorp[k+2] = coefmc4;
  vectorp[k+3] = coefbc4;
  vectorp[k+4] = gsc4min;
  k = k + 4;

  fscanf(fp1,"%f%f%f%f", &gammac3,&coefmc3,&coefbc3,&gsc3min); fgets(msg, 200, fp1);
  vectorp[k+1] = gammac3;
  vectorp[k+2] = coefmc3;
  vectorp[k+3] = coefbc3;
  vectorp[k+4] = gsc3min;
  fgets(msg, 200, fp1);//skip one line
  k = k + 4;

  fscanf(fp1,"%f", &chifuz); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &chiflz); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = chifuz;
  vectorp[k+2] = chiflz;
  k = k + 2;

  for(j=0; j<npft; j++){//npft = 15
    fscanf(fp1,"%f%f%f%f%f%f%f%f", &vmax_pft[j],&specla[j],&tauleaf[j],//most from comveg.h
           &tauroot[j],&tauwood0[j],&aleaf[0][j],&aroot[0][j],&awood[0][j]);
    fgets(msg, 200, fp1);
    vectorp[k+1] = vmax_pft[j];
    vectorp[k+2] = specla[j];
    vectorp[k+3] = tauleaf[j];
    vectorp[k+4] = tauroot[j];
    vectorp[k+5] = tauwood0[j];
    vectorp[k+6] = aleaf[0][j];
    vectorp[k+7] = aroot[0][j];
    vectorp[k+8] = awood[0][j];
    k = k + 8;
  }
  fgets(msg, 200, fp1);//skip one line

  fscanf(fp1,"%f", &woodnorm); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = woodnorm;
  k = k + 1;

  for(j=0; j<nband; j++){//nband = 2
    fscanf(fp1,"%f%f", &rhoveg[j][0],&rhoveg[j][1]); fgets(msg, 200, fp1);
    vectorp[k+1] = rhoveg[j][0];
    vectorp[k+2] = rhoveg[j][1];
    k = k + 2;
  }
  for(j=0; j<nband; j++){
    fscanf(fp1,"%f%f", &tauveg[j][0],&tauveg[j][1]); fgets(msg, 200, fp1);
    vectorp[k+1] = tauveg[j][0];
    vectorp[k+2] = tauveg[j][1];
    k = k + 2;
  }
  fgets(msg, 200, fp1);//skip one line

  fscanf(fp1,"%f%f", &dleaf[0],&dleaf[1]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f%f", &dstem[0],&dstem[1]); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = dleaf[0];
  vectorp[k+2] = dleaf[1];
  vectorp[k+3] = dstem[0];
  vectorp[k+4] = dstem[1];

  fscanf(fp1,"%f", &alaimu); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &alaiml); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+5] = alaimu;
  vectorp[k+6] = alaiml;

  fscanf(fp1,"%f", &cleaf);  fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cstem);  fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cgrass); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+7] = cleaf;
  vectorp[k+8] = cstem;
  vectorp[k+9] = cgrass;

  fscanf(fp1,"%f", &chs); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &chu); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &chl); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+10] = chs;
  vectorp[k+11] = chu;
  vectorp[k+12] = chl;

  fscanf(fp1,"%f", &wliqumax); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &wliqsmax); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &wliqlmax); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+13] = wliqumax;
  vectorp[k+14] = wliqsmax;
  vectorp[k+15] = wliqlmax;

  fscanf(fp1,"%f", &wsnoumax); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &wsnosmax); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &wsnolmax); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+16] = wsnoumax;
  vectorp[k+17] = wsnosmax;
  vectorp[k+18] = wsnolmax;

  fscanf(fp1,"%f", &tdripu); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &tdrips); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &tdripl); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+19] = tdripu;
  vectorp[k+20] = tdrips;
  vectorp[k+21] = tdripl;

  fscanf(fp1,"%f", &tblowu); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &tblows); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &tblowl); fgets(msg, 200, fp1);
  vectorp[k+22] = tblowu;
  vectorp[k+23] = tblows;
  vectorp[k+24] = tblowl;
  k = k + 24; //k = 222 now

  fclose(fp1);

  /* read paramsx.veg */
  if ((fp1 = fopen("paramsx.veg", "rt"))==NULL){
    fprintf(stderr,"paramsx.veg file not found! \n");
    return;
  }
  for(i=0; i<39; i++) fgets(msg, 200, fp1);//skip one line

  for(j=0; j<npft; j++){//from compft.h
    fscanf(fp1,"%f%f%f%f", &TminL[j],&TminU[j],&Twarm[j],&GDD[j]);
    fgets(msg, 200, fp1);
    vectorp[k+1] = TminL[j];
    vectorp[k+2] = TminU[j];
    vectorp[k+3] = Twarm[j];
    vectorp[k+4] = GDD[j];
    k = k + 4;
  }
  fgets(msg, 200, fp1);//skip one line

  for(j=0; j<npft; j++){
    fscanf(fp1,"%f%f%f%f", &plai_init[0][j],&plai_init[1][j],&plai_init[2][j],&plai_init[3][j]);
    fgets(msg, 200, fp1);
    vectorp[k+1] = plai_init[0][j];
    vectorp[k+2] = plai_init[1][j];
    vectorp[k+3] = plai_init[2][j];
    vectorp[k+4] = plai_init[3][j];
    k = k + 4;
  }
  fgets(msg, 200, fp1);//skip one line

  fscanf(fp1,"%f", &plaiupper); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &plailower); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &xminlai); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &sapfrac_init); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &beta1); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &beta2); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = plaiupper;
  vectorp[k+2] = plailower;
  vectorp[k+3] = xminlai;
  vectorp[k+4] = sapfrac_init;
  vectorp[k+5] = beta1;
  vectorp[k+6] = beta2;
  k = k + 6;

  for(j=0; j<npft; j++){//from comveg.h
    fscanf(fp1,"%f%f%f%f%f%f", &cnmnpl[j],&cnmnpw[j],&cnmnpr[j],&cnmxpl[j],&cnmxpw[j],&cnmxpr[j]);
    fgets(msg, 200, fp1);
    vectorp[k+1] = cnmnpl[j];
    vectorp[k+2] = cnmnpw[j];
    vectorp[k+3] = cnmnpr[j];
    vectorp[k+4] = cnmxpl[j];
    vectorp[k+5] = cnmxpw[j];
    vectorp[k+6] = cnmxpr[j];
    k = k + 6;
  }
  fgets(msg, 200, fp1);//skip one line

  for(j=0; j<npft; j++){
    fscanf(fp1,"%f%f%f%f%f%f", &cnmnll[j],&cnmnlw[j],&cnmnlr[j],&cnmxll[j],&cnmxlw[j],&cnmxlr[j]);
    fgets(msg, 200, fp1);
    vectorp[k+1] = cnmnll[j];
    vectorp[k+2] = cnmnlw[j];
    vectorp[k+3] = cnmnlr[j];
    vectorp[k+4] = cnmxll[j];
    vectorp[k+5] = cnmxlw[j];
    vectorp[k+6] = cnmxlr[j];
    k = k + 6;
  }
  fgets(msg, 200, fp1);//skip one line

  for(j=0; j<npft; j++){
    fscanf(fp1,"%f%f%f%f%f%f%f%f", &r1pstore[j],&r1rstore[j],&r2pstore[j],&r2rstore[j],
           &remroot[j],&remshoot[j],&rthining[j],&ferttree[j]);
    fgets(msg, 200, fp1);
    vectorp[k+1] = r1pstore[j];
    vectorp[k+2] = r1rstore[j];
    vectorp[k+3] = r2pstore[j];
    vectorp[k+4] = r2rstore[j];
    vectorp[k+5] = remroot[j];
    vectorp[k+6] = remshoot[j];
    vectorp[k+7] = rthining[j];
    vectorp[k+8] = ferttree[j];
    k = k + 8;
  }
  // k = 648 now
  fclose(fp1);

  /* read paramsx.soi */
  if((fp1 = fopen("paramsx.soi", "rt"))==NULL){
    fprintf(stderr,"paramsx.soi file not found! \n");
    return;
  }
  for(i=0; i<2; i++) fgets(msg, 200, fp1);//skip one line

  for(j=0; j<nsoilay; j++){//from comsoi.h
    fscanf(fp1,"%f", &hsoi[j]);
    fgets(msg, 200, fp1);
    vectorp[k+1] = hsoi[j];
    k = k + 1;
  }
  fgets(msg, 200, fp1);//skip one line

  fscanf(fp1,"%f", &bperm); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &wpudmax); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &zwpmax); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = bperm;
  vectorp[k+2] = wpudmax;
  vectorp[k+3] = zwpmax;
  k = k + 3;

  for(j=0; j<ndat; j++){//from comtex.h
    fscanf(fp1,"%f%f%f%f%f%f%f%f%f", &texdat[0][j],&texdat[1][j],&texdat[2][j],
           &porosdat[j],&sfielddat[j],&swiltdat[j],&bexdat[j],&suctiondat[j],&hydrauldat[j]);
    fgets(msg, 200, fp1);
    vectorp[k+1] = texdat[0][j];
    vectorp[k+2] = texdat[1][j];
    vectorp[k+3] = texdat[2][j];
    vectorp[k+4] = porosdat[j];
    vectorp[k+5] = sfielddat[j];
    vectorp[k+6] = swiltdat[j];
    vectorp[k+7] = bexdat[j];
    vectorp[k+8] = suctiondat[j];
    vectorp[k+9] = hydrauldat[j];
    k = k + 9;
  }
  fgets(msg, 200, fp1);//skip one line

  fscanf(fp1,"%f", &lig_frac); fgets(msg, 200, fp1);//from combgc.h
  fscanf(fp1,"%f", &fbsom); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &effac); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = lig_frac;
  vectorp[k+2] = fbsom;
  vectorp[k+3] = effac;
  k = k + 3;

  fscanf(fp1,"%f%f%f%f%f%f%f%f", &cnr[0],&cnr[1],&cnr[2],&cnr[3],&cnr[4],&cnr[5],&cnr[6],&cnr[7]);
  fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = cnr[0];
  vectorp[k+2] = cnr[1];
  vectorp[k+3] = cnr[2];
  vectorp[k+4] = cnr[3];
  vectorp[k+5] = cnr[4];
  vectorp[k+6] = cnr[5];
  vectorp[k+7] = cnr[6];
  vectorp[k+8] = cnr[7];
  k = k + 8;

  fscanf(fp1,"%f%f%f%f%f", &ffmax,&rconst,&cnleaf[0],&cnroot[0],&cnwood[0]);//cnleaf,cnroot,cnwood from comveg.h, seems not necessary
  fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = ffmax;
  vectorp[k+2] = rconst;
  vectorp[k+3] = cnleaf[0];
  vectorp[k+4] = cnroot[0];
  vectorp[k+5] = cnwood[0];
  k = k + 5;

  fscanf(fp1,"%f%f%f%f%f%f%f%f%f", &klm,&kls,&kll,&krm,&krs,&krl,&kwm,&kws,&kwl);
  fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = klm;
  vectorp[k+2] = kls;
  vectorp[k+3] = kll;
  vectorp[k+4] = krm;
  vectorp[k+5] = krs;
  vectorp[k+6] = krl;
  vectorp[k+7] = kwm;
  vectorp[k+8] = kws;
  vectorp[k+9] = kwl;
  k = k + 9;

  fscanf(fp1,"%f%f%f%f%f%f%f", &kbn,&kbp,&knb,&kns,&kpb,&kps,&ksb);
  fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = kbn;
  vectorp[k+2] = kbp;
  vectorp[k+3] = knb;
  vectorp[k+4] = kns;
  vectorp[k+5] = kpb;
  vectorp[k+6] = kps;
  vectorp[k+7] = ksb;
  k = k + 7;

  fscanf(fp1,"%f%f%f%f%f%f%f%f%f", &ylm,&yrm,&ywm,&yls,&yrs,&yws,&yll,&yrl,&ywl);
  fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = ylm;
  vectorp[k+2] = yrm;
  vectorp[k+3] = ywm;
  vectorp[k+4] = yls;
  vectorp[k+5] = yrs;
  vectorp[k+6] = yws;
  vectorp[k+7] = yll;
  vectorp[k+8] = yrl;
  vectorp[k+9] = ywl;
  k = k + 9;

  fscanf(fp1,"%f%f%f%f%f%f%f", &ybn,&ybp,&yps,&yns,&ysb,&ypb,&ynb);
  fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = ybn;
  vectorp[k+2] = ybp;
  vectorp[k+3] = yps;
  vectorp[k+4] = yns;
  vectorp[k+5] = ysb;
  vectorp[k+6] = ypb;
  vectorp[k+7] = ynb;
  k = k + 7;

  fscanf(fp1,"%f", &nmmax); fgets(msg, 200, fp1);//from comveg.h
  fscanf(fp1,"%f", &kp[0]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &kl[0]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &ks[0]); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = nmmax;
  vectorp[k+2] = kp[0];
  vectorp[k+3] = kl[0];
  vectorp[k+4] = ks[0];
  k = k + 4;

  fscanf(fp1,"%f", &cnrmax[0]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cnrmax[1]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cnrmax[2]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cnrmax[3]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cnrmax[4]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cnrmax[5]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cnrmax[6]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cnrmax[7]); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = cnrmax[0];
  vectorp[k+2] = cnrmax[1];
  vectorp[k+3] = cnrmax[2];
  vectorp[k+4] = cnrmax[3];
  vectorp[k+5] = cnrmax[4];
  vectorp[k+6] = cnrmax[5];
  vectorp[k+7] = cnrmax[6];
  vectorp[k+8] = cnrmax[7];
  k = k + 8;

  fscanf(fp1,"%f", &cnrmin[0]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cnrmin[1]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cnrmin[2]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cnrmin[3]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cnrmin[4]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cnrmin[5]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cnrmin[6]); fgets(msg, 200, fp1);
  fscanf(fp1,"%f", &cnrmin[7]); fgets(msg, 200, fp1);
  vectorp[k+1] = cnrmin[0];
  vectorp[k+2] = cnrmin[1];
  vectorp[k+3] = cnrmin[2];
  vectorp[k+4] = cnrmin[3];
  vectorp[k+5] = cnrmin[4];
  vectorp[k+6] = cnrmin[5];
  vectorp[k+7] = cnrmin[6];
  vectorp[k+8] = cnrmin[7];
  k = k + 8; //k = 833 now
  fclose(fp1);

  /* read paramsx.crp */
  if ((fp1 = fopen("paramsx.crp", "rt"))==NULL){
    fprintf(stderr,"paramsx.crp file not found! \n");
    return;
  }
  for(i=0; i<3; i++) fgets(msg, 200, fp1);//skip one line

  fscanf(fp1,"%f%f%f%f%f%f%f%f%f%f", &cropcomp[0],&cropcomp[1],&cropcomp[2],&cropcomp[3],//from comveg.h
         &cropcomp[4],&cropcomp[5],&cropcomp[6],&cropcomp[7],&cropcomp[8],&cropcomp[9]);
  fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = cropcomp[0];
  vectorp[k+2] = cropcomp[1];
  vectorp[k+3] = cropcomp[2];
  vectorp[k+4] = cropcomp[3];
  vectorp[k+5] = cropcomp[4];
  vectorp[k+6] = cropcomp[5];
  vectorp[k+7] = cropcomp[6];
  vectorp[k+8] = cropcomp[7];
  vectorp[k+9] = cropcomp[8];
  vectorp[k+10] = cropcomp[9];
  k = k + 10;

  fscanf(fp1,"%f%f%f%f%f%f%f%f%f%f", &gindex[0],&gindex[1],&gindex[2],&gindex[3],
         &gindex[4],&gindex[5],&gindex[6],&gindex[7],&gindex[8],&gindex[9]);
  fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = gindex[0];
  vectorp[k+2] = gindex[1];
  vectorp[k+3] = gindex[2];
  vectorp[k+4] = gindex[3];
  vectorp[k+5] = gindex[4];
  vectorp[k+6] = gindex[5];
  vectorp[k+7] = gindex[6];
  vectorp[k+8] = gindex[7];
  vectorp[k+9] = gindex[8];
  vectorp[k+10] = gindex[9];
  k = k + 10;

  fscanf(fp1,"%f%f%f%f%f%f%f%f%f%f", &hindex[0],&hindex[1],&hindex[2],&hindex[3],
         &hindex[4],&hindex[5],&hindex[6],&hindex[7],&hindex[8],&hindex[9]);
  fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = hindex[0];
  vectorp[k+2] = hindex[1];
  vectorp[k+3] = hindex[2];
  vectorp[k+4] = hindex[3];
  vectorp[k+5] = hindex[4];
  vectorp[k+6] = hindex[5];
  vectorp[k+7] = hindex[6];
  vectorp[k+8] = hindex[7];
  vectorp[k+9] = hindex[8];
  vectorp[k+10] = hindex[9];
  k = k + 10;

  fscanf(fp1,"%f%f%f%f%f%f%f%f%f%f", &strawrem[0],&strawrem[1],&strawrem[2],&strawrem[3],
         &strawrem[4],&strawrem[5],&strawrem[6],&strawrem[7],&strawrem[8],&strawrem[9]);
  fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = strawrem[0];
  vectorp[k+2] = strawrem[1];
  vectorp[k+3] = strawrem[2];
  vectorp[k+4] = strawrem[3];
  vectorp[k+5] = strawrem[4];
  vectorp[k+6] = strawrem[5];
  vectorp[k+7] = strawrem[6];
  vectorp[k+8] = strawrem[7];
  vectorp[k+9] = strawrem[8];
  vectorp[k+10] = strawrem[9];
  k = k + 10;

  fscanf(fp1,"%f%f%f%f%f%f%f%f%f%f", &fertcrop[0],&fertcrop[1],&fertcrop[2],&fertcrop[3],
         &fertcrop[4],&fertcrop[5],&fertcrop[6],&fertcrop[7],&fertcrop[8],&fertcrop[9]);
  vectorp[k+1] = fertcrop[0];
  vectorp[k+2] = fertcrop[1];
  vectorp[k+3] = fertcrop[2];
  vectorp[k+4] = fertcrop[3];
  vectorp[k+5] = fertcrop[4];
  vectorp[k+6] = fertcrop[5];
  vectorp[k+7] = fertcrop[6];
  vectorp[k+8] = fertcrop[7];
  vectorp[k+9] = fertcrop[8];
  vectorp[k+10] = fertcrop[9];
  k = k + 10; //k = 883 now

  fclose(fp1);

  /* read paramsx.dis */
  if ((fp1 = fopen("paramsx.dis", "rt"))==NULL){
    fprintf(stderr,"paramsx.dis file not found! \n");
    return;
  }
  for(i=0; i<2; i++) fgets(msg, 200, fp1);//skip one line

  for(i=0; i<5; i++){//from comfire.h 
    fscanf(fp1,"%f%f%f%f", &combsoil[i][0],&combsoil[i][1],&combsoil[i][2],&combsoil[i][3]);
    fgets(msg, 200, fp1);
    vectorp[k+1] = combsoil[i][0];
    vectorp[k+2] = combsoil[i][1];
    vectorp[k+3] = combsoil[i][2];
    vectorp[k+4] = combsoil[i][3];
    k = k + 4;
  }
  for(i=0; i<6; i++){
    fscanf(fp1,"%f%f%f%f", &comblev[i][0],&comblev[i][1],&comblev[i][2],&comblev[i][3]);
    fgets(msg, 200, fp1);
    vectorp[k+1] = comblev[i][0];
    vectorp[k+2] = comblev[i][1];
    vectorp[k+3] = comblev[i][2];
    vectorp[k+4] = comblev[i][3];
    k = k + 4;
  }
  fgets(msg, 200, fp1);//skip one line

  for(i=0; i<4; i++){
    fscanf(fp1,"%f%f%f%f", &mortlev[i][0],&mortlev[i][1],&mortlev[i][2],&mortlev[i][3]);
    fgets(msg, 200, fp1);
    vectorp[k+1] = mortlev[i][0];
    vectorp[k+2] = mortlev[i][1];
    vectorp[k+3] = mortlev[i][2];
    vectorp[k+4] = mortlev[i][3];
    k = k + 4;
  }
  fgets(msg, 200, fp1);//skip one line

  for(i=0; i<12; i++){
    fscanf(fp1,"%f%f%f%f%f", &forharv[i][0],&forharv[i][1],&forharv[i][2],&forharv[i][3],&forharv[i][4]);
    fgets(msg, 200, fp1);
    vectorp[k+1] = forharv[i][0];
    vectorp[k+2] = forharv[i][1];
    vectorp[k+3] = forharv[i][2];
    vectorp[k+4] = forharv[i][3];
    vectorp[k+5] = forharv[i][4];
    k = k + 5;
  }
  fgets(msg, 200, fp1);//skip one line

  for(i=0; i<12; i++){
    fscanf(fp1,"%f%f%f%f%f", &defor[i][0],&defor[i][1],&defor[i][2],&defor[i][3],&defor[i][4]);
    fgets(msg, 200, fp1);
    vectorp[k+1] = defor[i][0];
    vectorp[k+2] = defor[i][1];
    vectorp[k+3] = defor[i][2];
    vectorp[k+4] = defor[i][3];
    vectorp[k+5] = defor[i][4];
    k = k + 5;
  }
  // k = 1063 now
  fclose(fp1);

  /* read paramsx.ghg */
  if ((fp1 = fopen("paramsx.ghg", "rt"))==NULL){
    fprintf(stderr,"paramsx.ghg file not found! \n");
    return;
  }
  for(i=0; i<2; i++) fgets(msg, 200, fp1);//skip one line

  fscanf(fp1,"%f%f%f%f%f%f%f%f", &RBOX,&FD,&MUEMAX,&AMAX,&AMAXX,&KNI,&EFFAC_D,&rcnb);//from comghg.h
  fgets(msg, 200, fp1);
  vectorp[k+1] = RBOX;
  vectorp[k+2] = FD;
  vectorp[k+3] = MUEMAX;
  vectorp[k+4] = AMAX;
  vectorp[k+5] = AMAXX;
  vectorp[k+6] = KNI;
  vectorp[k+7] = EFFAC_D;
  vectorp[k+8] = rcnb;
  k = k + 8;
  fgets(msg, 200, fp1);//skip one line

  fscanf(fp1,"%f%f%f%f%f%f", &MUE_NO3,&MUE_NO2,&MUE_NO,&MUE_N2O,&MNO3,&MNO2);
  fgets(msg, 200, fp1);
  vectorp[k+1] = MUE_NO3;
  vectorp[k+2] = MUE_NO2;
  vectorp[k+3] = MUE_NO;
  vectorp[k+4] = MUE_N2O;
  vectorp[k+5] = MNO3;
  vectorp[k+6] = MNO2;
  k = k + 6;
  fgets(msg, 200, fp1);//skip one line

  fscanf(fp1,"%f%f%f%f%f%f%f%f", &MNO,&MN2O,&EFF_NO3,&EFF_NO2,&EFF_NO,&EFF_N2O,&KICE,&KCI);
  fgets(msg, 200, fp1);
  vectorp[k+1] = MNO;
  vectorp[k+2] = MN2O;
  vectorp[k+3] = EFF_NO3;
  vectorp[k+4] = EFF_NO2;
  vectorp[k+5] = EFF_NO;
  vectorp[k+6] = EFF_N2O;
  vectorp[k+7] = KICE;
  vectorp[k+8] = KCI;
  k = k + 8;
  fgets(msg, 200, fp1);//skip one line

  fscanf(fp1,"%f%f%f%f%f", &D_O2,&LH,&SD,&F_aerenchyma,&Atm_CH4);
  fgets(msg, 200, fp1);
  vectorp[k+1] = D_O2;
  vectorp[k+2] = LH;
  vectorp[k+3] = SD;
  vectorp[k+4] = F_aerenchyma;
  vectorp[k+5] = Atm_CH4;
  k = k + 5; //k = 1090 now

  fclose(fp1);

  /* read paramsx.map */
  if ((fp1 = fopen("paramsx.map", "rt"))==NULL){
    fprintf(stderr,"paramsx.map file not found! \n");
    return;
  }
  for(i=0; i<2; i++) fgets(msg, 200, fp1);//skip one line

  fscanf(fp1,"%d", &map1ncol); fgets(msg, 200, fp1);//from compar.h
  fscanf(fp1,"%d", &map1nrow); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map1res); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map1left); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map1right); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map1upper); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map1lower); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = map1ncol;
  vectorp[k+2] = map1nrow;
  vectorp[k+3] = map1res;
  vectorp[k+4] = map1left;
  vectorp[k+5] = map1right;
  vectorp[k+6] = map1upper;
  vectorp[k+7] = map1lower;
  k = k + 7;

  fscanf(fp1,"%d", &map2ncol); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map2nrow); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map2res); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map2left); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map2right); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map2upper); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map2lower); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = map2ncol;
  vectorp[k+2] = map2nrow;
  vectorp[k+3] = map2res;
  vectorp[k+4] = map2left;
  vectorp[k+5] = map2right;
  vectorp[k+6] = map2upper;
  vectorp[k+7] = map2lower;
  k = k + 7;

  fscanf(fp1,"%d", &map3ncol); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map3nrow); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map3res); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map3left); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map3right); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map3upper); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map3lower); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = map3ncol;
  vectorp[k+2] = map3nrow;
  vectorp[k+3] = map3res;
  vectorp[k+4] = map3left;
  vectorp[k+5] = map3right;
  vectorp[k+6] = map3upper;
  vectorp[k+7] = map3lower;
  k = k + 7;

  fscanf(fp1,"%d", &map4ncol); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map4nrow); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map4res); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map4left); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map4right); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map4upper); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map4lower); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = map4ncol;
  vectorp[k+2] = map4nrow;
  vectorp[k+3] = map4res;
  vectorp[k+4] = map4left;
  vectorp[k+5] = map4right;
  vectorp[k+6] = map4upper;
  vectorp[k+7] = map4lower;
  k = k + 7;

  fscanf(fp1,"%d", &map5ncol); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map5nrow); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map5res); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map5left); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map5right); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map5upper); fgets(msg, 200, fp1);
  fscanf(fp1,"%d", &map5lower); fgets(msg, 200, fp1);
  fgets(msg, 200, fp1);//skip one line
  vectorp[k+1] = map5ncol;
  vectorp[k+2] = map5nrow;
  vectorp[k+3] = map5res;
  vectorp[k+4] = map5left;
  vectorp[k+5] = map5right;
  vectorp[k+6] = map5upper;
  vectorp[k+7] = map5lower;
  k = k + 7; //k = 1125 now

  fclose(fp1);
  return;
}


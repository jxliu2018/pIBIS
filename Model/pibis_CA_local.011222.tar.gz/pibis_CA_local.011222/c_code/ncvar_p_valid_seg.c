/*
 _ __   _____   ____ _ _ __ ___ 
| '_ \ / __\ \ / / _` | '__/ __|
| | | | (__ \ V / (_| | | | (__ 
|_| |_|\___| \_/ \__,_|_|(_)___|

*/
//ncvar.c
//Wanjing Wei, pnetcdf processes
//Jinxun Liu, updated 7/6/2017
//jxliu@usgs.gov

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "netcdf.h"
#include "ibis_common_p.h"

void set_init_value_int(int* array, int value, int len ) {
  int i;
  for(i = 0; i < len; i++) array[i] = value;
}
void set_init_value_char(char* array, char value, int len ) {
  int i;
  for(i = 0; i < len ; i++) array[i] = value;
}
void set_init_value(float* array, float value, int len ) {
  int i;
  for(i = 0; i < len ; i++) array[i] = value;
}
void ncread0(int first){//pre-processing for map readings
  int i, j, k;
  int callocsize = sizeof(float);
  int callocerror = 0;

    if(ssouth >= snorth && seast >= swest){
      nlatsub = ssouth - snorth + 1;       //subregion rows
      nlonsub = seast - swest + 1;         //subregion columns
      nlatsubs = (nlatsub-1)/rowscale + 1; //subregion rows, by sampling
      nlonsubs = (nlonsub-1)/colscale + 1; //subregion columns, by sampling
      startlon = map1left + (swest - 1) * map1res;
      startlat = map1upper - (snorth - 1) * map1res;
      endlon = startlon + nlonsub * map1res - 1;
      endlat = startlat - nlatsub * map1res + 1;

      total_npoi = nlatsub * nlonsub;

      //map1, base resolution, 1 layer maps, e.g mask, veg, biomass, fips
      start_g1[0] = 0;
      start_g1[1] = 0;
      start_g1[2] = snorth - 1;
      start_g1[3] = swest - 1;
      count_g1[0] = 1;
      count_g1[1] = 1;
      count_g1[2] = ssouth - snorth + 1;;
      count_g1[3] = seast - swest + 1;

      time_length1 = count_g1[0];
      layers1 = count_g1[1];
      rows1 = count_g1[2];
      columns1 = count_g1[3];
      array_size1 = count_g1[0]*count_g1[1]*count_g1[2]*count_g1[3];
      offrow1 = map1upper - startlat;
      offrow1x = offrow1/map1res;
      offcol1 = startlon - map1left;
      offcol1x = offcol1/map1res;

      //map2, base resolution, multilayer maps, e.g. soil texture
      start_g2[0] = 0;
      start_g2[1] = 0;
      start_g2[2] = (map2upper - startlat)/map2res;
      start_g2[3] = (startlon - map2left)/map2res;
      count_g2[0] = 1;
      count_g2[1] = nsoilay;
      count_g2[2] = 1 + (int)((map2upper - endlat)/map2res) - (int)((map2upper - startlat)/map2res);
      count_g2[3] = 1 + (int)((endlon - map2left)/map2res) - (int)((startlon - map2left)/map2res);

      time_length2 = count_g2[0];
      layers2 = count_g2[1];
      rows2 = count_g2[2];
      columns2 = count_g2[3];
      array_size2 = count_g2[0]*count_g2[1]*count_g2[2]*count_g2[3];
      offrow2 = map2upper - startlat;
      offrow2x = offrow2/map2res;
      offcol2 = startlon - map2left;
      offcol2x = offcol2/map2res;

      //map3, scaled resolution, multilayer maps, e.g average climate data
      start_g3[0] = 0;
      start_g3[1] = 0;
      start_g3[2] = (map3upper - startlat)/map3res;
      start_g3[3] = (startlon - map3left)/map3res;
      count_g3[0] = 12;
      count_g3[1] = 1;
      count_g3[2] = 1 + (int)((map3upper - endlat)/map3res) - (int)((map3upper - startlat)/map3res);
      count_g3[3] = 1 + (int)((endlon - map3left)/map3res) - (int)((startlon - map3left)/map3res);

      time_length3 = count_g3[0];
      layers3 = count_g3[1];
      rows3 = count_g3[2];
      columns3 = count_g3[3];
      array_size3 = count_g3[0]*count_g3[1]*count_g3[2]*count_g3[3];
      offrow3 = map3upper - startlat;
      offrow3x = offrow3/map3res;
      offcol3 = startlon - map3left;
      offcol3x = offcol3/map3res;

      //map4, scaled resolution, multilayer maps, e.g anormly climate data
      start_g4[0] = 0;
      start_g4[1] = 0;
      start_g4[2] = (map4upper - startlat)/map4res;
      start_g4[3] = (startlon - map4left)/map4res;
      count_g4[0] = anomyears*12;
      count_g4[1] = 1;
      count_g4[2] = 1 + (int)((map4upper - endlat)/map4res) - (int)((map4upper - startlat)/map4res);
      count_g4[3] = 1 + (int)((endlon - map4left)/map4res) - (int)((startlon - map4left)/map4res);

      time_length4 = count_g4[0];
      layers4 = count_g4[1];
      rows4 = count_g4[2];
      columns4 = count_g4[3];
      array_size4 = count_g4[0]*count_g4[1]*count_g4[2]*count_g4[3];
      offrow4 = map4upper - startlat;
      offrow4x = offrow4/map4res;
      offcol4 = startlon - map4left;
      offcol4x = offcol4/map4res;

      //map5, base resolution multilayer maps, e.g lcc maps
      start_g5[0] = 0;
      start_g5[1] = 0;
      start_g5[2] = snorth - 1;
      start_g5[3] = swest - 1;
      count_g5[0] = lccyears;
      count_g5[1] = 1;
      count_g5[2] = ssouth - snorth + 1;;
      count_g5[3] = seast - swest + 1;

      time_length5 = count_g5[0];
      layers5 = count_g5[1];
      rows5 = count_g5[2];
      columns5 = count_g5[3];
      array_size5 = count_g5[0]*count_g5[1]*count_g5[2]*count_g5[3];
      offrow5 = map1upper - startlat;
      offrow5x = offrow1/map1res;
      offcol5 = startlon - map1left;
      offcol5x = offcol1/map1res;

      //arrange relative spatial map_ids
      callocsize = sizeof(int);
      callocerror = 0;
      if((map1_id = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc map1_id.", -1);
      if((map2_id = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc map2_id.", -1);
      if((map3_id = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc map3_id.", -1);
      if((map4_id = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc map4_id.", -1);
      if((map5_id = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc map5_id.", -1);

      int iii, jjj, loc1, loc2, loc3, loc4;
      int remainder_row, remainder_col;
      k = 0;
      for(i=0; i<count_g1[2]; i++){
        remainder_row = i%rowscale;
        for(j=0; j<count_g1[3]; j++){
          remainder_col = j%colscale;

          loc1 = i*count_g1[3] + j;
          map1_id[k] = loc1;
          map5_id[k] = loc1;//map5 has the same spatial reference as map1 

          if(remainder_row==0 && remainder_col==0){
            iii = (i*map1res + offrow2)/map2res - offrow2x;
            jjj = (j*map1res + offcol2)/map2res - offcol2x;
            loc2 = iii*count_g2[3] + jjj;
            map2_id[k] = loc2;

            iii = (i*map1res + offrow3)/map3res - offrow3x;
            jjj = (j*map1res + offcol3)/map3res - offcol3x;
            loc3 = iii*count_g3[3] + jjj;
            map3_id[k] = loc3;

            iii = (i*map1res + offrow4)/map4res - offrow4x;
            jjj = (j*map1res + offcol4)/map4res - offcol4x;
            loc4 = iii*count_g4[3] + jjj;
            map4_id[k] = loc4;
          }
          else{
            map2_id[k] = -1;
            map3_id[k] = -1;
            map4_id[k] = -1;
          }

          k = k + 1;
        }
      }

      //malloc common interpolation and sampling data array (for 2D,3D,4D)
      array_size1_interp = count_g1[0]*count_g1[1]*count_g1[2]*count_g1[3];
      array_size1_samp = nlatsubs * nlonsubs;

      callocsize = sizeof(char);
      if((surta_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc surta_data.", -1);
      if((ecoreg_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc ecoreg_data.", -1);
      ReadNCVara(infilen[0], invarn[0], NC_CHAR, start_g1, count_g1, surta_data);
      ReadNCVara(infilen[5], invarn[5], NC_CHAR, start_g1, count_g1, ecoreg_data);

      callocsize = sizeof(int);
      if((fips_data = calloc(array_size1,callocsize)) == NULL) callocerror = errmsg("failed calloc fips_data.", -1);
      ReadNCVara(infilen[6], invarn[6], NC_INT, start_g1, count_g1, fips_data);

      calc_valid_seg(); //calculate valid segment
    }//if(ssouth >= snorth && seast >= swest){

  return;
}//ncread0()

void ncread1(int first){//read single layer maps
  return;
}//ncread1()


void ncread2(int first){//for 6 layer soil data
  return;
}//ncread2()


void ncread3(int first){//for reading average cliamte data
  return;
}//ncread3()


void ncread4(int first){//for precip anom
  return;
}//ncread4()

void ncread4_1(int first){//for precip anom
  return;
}
void ncread4_2(int first){
  return;
}
void ncread4_3(int first){
  return;
}
void ncread4_4(int first){
  return;
}
void ncread4_5(int first){
  return;
}
void ncread4_6(int first){
  return;
}
void ncread4_7(int first){
  return;
}
void ncread4_8(int first){
  return;
}
void ncread4_9(int first){
  return;
}
void ncread4_10(int first){
  return;
}


void ncread5(int first){//for temprature anom
  return;
}//ncread5()

void ncread5_1(int first){//for temprature anom
  return;
}
void ncread5_2(int first){//for temprature anom
  return;
}
void ncread5_3(int first){//for temprature anom
  return;
}
void ncread5_4(int first){//for temprature anom
  return;
}
void ncread5_5(int first){//for temprature anom
  return;
}
void ncread5_6(int first){
  return;
}
void ncread5_7(int first){
  return;
}
void ncread5_8(int first){
  return;
}
void ncread5_9(int first){
  return;
}

void ncread5_10(int first){
  return;
}


void ncread6(int first){//trange anom
  return;
}//ncread6()

void ncread6_1(int first){//for temprature range
  return;
}
void ncread6_2(int first){//for temprature range
  return;
}
void ncread6_3(int first){//for temprature range
  return;
}
void ncread6_4(int first){//for temprature range
  return;
}
void ncread6_5(int first){//for temprature range
  return;
}
void ncread6_6(int first){
  return;
}
void ncread6_7(int first){
  return;
}
void ncread6_8(int first){
  return;
}
void ncread6_9(int first){
  return;
}
void ncread6_10(int first){
  return;
}

void ncread7(int first){
  return;
}//ncread7()


void ncread8(int first){
  return;
}//ncread8()

void ncread8_1(int first){//for fire data
  return;
}

void ncread8_2(int first){//for fire data
  return;
}

void ncread8_3(int first){//for fire data
  return;
}

void ncread8_4(int first){//for fire data
  return;
}

void ncread8_5(int first){//for fire data
  return;
}

void ncread8_6(int first){//for fire data
  return;
}

void ncread8_7(int first){//for fire data
  return;
}

void ncread8_8(int first){//for fire data
  return;
}

void ncread8_9(int first){//for fire data
  return;
}

void ncread8_10(int first){//for fire data
  return;
}

void ncread9(int first){//for nitrogen deposition data
  return;
}

void ncwrite(){
  return;
}

void writex4(float *var4, char *targetfile, char *title, char *varname, char *units, char dim_name[][10], int *dim_data[], size_t *startx, size_t *countx){
  return;
}

void rdscaler(){
  return;
}

void rdlanduse(){
  return;
}


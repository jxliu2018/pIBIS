/*
 _ __ ___  __ _  __| |_ __   __ _ _ __ ___   ___  ___   ___ 
| '__/ _ \/ _` |/ _` | '_ \ / _` | '_ ` _ \ / _ \/ __| / __|
| | |  __/ (_| | (_| | | | | (_| | | | | | |  __/\__ \| (__ 
|_|  \___|\__,_|\__,_|_| |_|\__,_|_| |_| |_|\___||___(_)___|
                                                            
*/ 
//readnames.c
//Jinxun Liu, updated 8/7/2017
//jxliu@usgs.gov

#include <stdio.h>
#include <stdlib.h>
#include "ibis_common_p.h"

void readnames(){
  FILE *fp1;
  char msg[100];
  int  i;

  /* read pibis netcdf input list */
  if ((fp1 = fopen("pibis_input_list.txt", "rt"))==NULL){
    fprintf(stderr,"pibis_input_list.txt not found! \n");
    return;
  }
  fgets(msg, 100, fp1);//skip one line

  for(i=0;i<51;i++){
    fscanf(fp1,"%10s", &intype[i]);
    fscanf(fp1,"%10s", &invarn[i][0]);
    fscanf(fp1,"%60s", &infilen[i][0]);
    fgets(msg, 100, fp1);//skip line end
    fprintf(stderr,"input file #%d: %s \n", i, infilen[i]);
    fprintf(stderr,"  var: %s \n", invarn[i]);
    fprintf(stderr,"  type: %d \n", intype[i]);
  }

  /* read params.xxx files */
  fgets(msg, 100, fp1);//skip one line
  for(i=0;i<9;i++){
    fscanf(fp1,"%20s", &paramfn[i][0]);
    fgets(msg, 100, fp1);//skip line end
    fprintf(stderr,"parameter file #%d: %s \n", i, paramfn[i]);
  }

  fclose(fp1);
  return;
}

